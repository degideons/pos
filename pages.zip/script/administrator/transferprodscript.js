$('document').ready(function(){
  $('#add').click(function(){
   var html = '<tr>';
   html += '<td><b class="numb">1</b></td>';
   html += '<td><select name="pid[]" id="pid" class="pid form-control" style="width: 100%" required="required"></select><input type="hidden" class="prodname form-control" name="prodname[]" id="prodname" readonly="readonly"  required="required"></td>';
   html += '<td style="width:20%"><input type="text" class="tquantity form-control" name="tquantity[]" id="tquantity" readonly="readonly"  required="required"></td>';
   html += '<td style="width:20%"><input type="text" class="quantity form-control" name="quantity[]" id="quantity" required="required"></td>';
   html += '<td style="width:20%"><input type="text" class="cartonquantity form-control" name="cartonquantity[]" id="cartonquantity" required="required"></td>';
   html += '<td style="text-align: center;"><button class="remove btn btn-danger" data-toggle="tooltip" title="Remove" name="Remove"><span class="glyphicon glyphicon-trash"></span></button></td>';
   html += '</tr>';
   $('#order_table-grid tbody').prepend(html);
   var n = 0;
   $(".numb").each(function(){
   $(this).html(++n); 
   })

   $('.pid').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/administrator/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
  });

  $("#showorderlist").delegate(".pid","change",function(){
    var fromshop = $("#fromshop").val();
    var pid = $(this).val();
    var tr = $(this).parent().parent();
    $.ajax({
      url:'../../production/administrator/neworderitem.php',
      method:'POST',
      dataType: 'json',
      data:{priceqty:1,id:pid,fromshopid:fromshop},
      success: function(data){
        tr.find(".prodname").val(data["Product"]);
        tr.find(".tquantity").val(data["Quantity"]);
        tr.find(".quantity").val(0);
        tr.find(".cartonquantity").val(0);
        /*tr.find(".price").val(data["SellingPrice"]);*/
        tr.find(".amount").html(tr.find(".quantity").val() * tr.find(".price").val());
      }
    })
  });

  $('table tbody').on('click','.remove', function(){
   $(this).closest('tr').remove();
  });

  $('.pid').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/administrator/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
});


 $('.shop').select2({
        placeholder: 'Select Shop',
        ajax: {
          url: '../../production/administrator/shopnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
  $('select[name="fromshop"]').change(function(){
  $("#fromshopname").val($("#fromshop option:selected").text());
 });
  $('select[name="toshop"]').change(function(){
  $("#toshopname").val($("#toshop option:selected").text());
 });