$('document').ready(function(){
  $('#add').click(function(){
   var html = '<tr>';
   html += '<td><b class="numb">1</b></td>';
   html += '<td><select name="pid[]" id="pid" class="pid form-control" style="width: 100%" required="required"></select><input type="hidden" class="prodname form-control" name="prodname[]" id="prodname" readonly="readonly"  required="required"></td>';
   html += '<td style="width:20%"><input type="text" class="quantity form-control" name="quantity[]" id="quantity" required="required"></td>';
   html += '<td style="width:20%"><input type="number" class="price form-control" name="price[]" id="price" required="required"></td>';
   html += '<td style="text-align: center;">&cent; <span class="amount">0.00</span></td>';
   html += '<td style="text-align: center;"><button class="remove btn btn-danger" data-toggle="tooltip" title="Remove" name="Remove"><span class="glyphicon glyphicon-trash"></span></button></td>';
   html += '</tr>';
   $('#order_table-grid tbody').prepend(html);
   var n = 0;
   $(".numb").each(function(){
   $(this).html(++n); 
   })

   $('.pid').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/administrator/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
  });

  $('.vendorname').select2({
        placeholder: 'Please select Vendor',
        ajax: {
          url: '../../production/administrator/vendorname.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });

  $("#showorderlist").delegate(".pid","change",function(){
  	var pid = $(this).val();
  	var tr = $(this).parent().parent();
  	$.ajax({
  		url:'../../production/administrator/purneworderitem.php',
  		method:'POST',
  		dataType: 'json',
  		data:{priceqty:1,id:pid},
  		success: function(data){
        tr.find(".prodname").val(data["Product"]);
  			tr.find(".quantity").val(1);
        tr.find(".price").val(1);
  			tr.find(".amount").html(tr.find(".quantity").val() * tr.find(".price").val());
  			calculate();
  		}
  	})
  });

  $("#showorderlist").delegate(".quantity","keyup",function(){
    var qty = $(this);
    var tr = $(this).parent().parent();
    if(isNaN(qty.val())){
      alert("please enter a number");
      qty.val(1);
    }
     else{
      if(qty.val() < 1){
        alert("Please input a valid number!");
        qty.val(1);
        tr.find(".amount").html(qty.val() * tr.find(".price").val());
      }else{
        tr.find(".amount").html(qty.val() * tr.find(".price").val());
        calculate();
      }
     }
  });

  $("#showorderlist").delegate(".price","keyup",function(){
  	var price = $(this);
  	var tr = $(this).parent().parent();
  	if(isNaN(price.val())){
  		alert("please enter a number");
  		price.val(1);
  	}
  	 else{
  	 	if(price.val() < 1){
  	 		alert("Please input amount!");
  	 		price.val(1);
  	 		tr.find(".amount").html(price.val() * tr.find(".quantity").val());
  	 	}else{
  	 		tr.find(".amount").html(price.val() * tr.find(".quantity").val());
  	 		calculate();
  	 	}
  	 }
  });

  $("#showorderlist").delegate(".price","change",function(){
    var price = $(this);
    var tr = $(this).parent().parent();
    if(isNaN(price.val())){
      alert("please enter an amount");
      price.val(1);
    }
     else{
      if(price.val() < 1){
        alert("Please input amount!");
        price.val(1);
        tr.find(".amount").html(price.val() * tr.find(".quantity").val());
      }else{
        tr.find(".amount").html(price.val() * tr.find(".quantity").val());
        calculate();
      }
     }
  });

  $('table tbody').on('click','.remove', function(){
   $(this).closest('tr').remove();
   calculate(0,0);
  });

  $('.pid').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/administrator/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });

  function calculate(){
  	var subtotal = 0;
  	var nettotal = 0;
  	var due = 0;

  	$(".amount").each(function(){
        subtotal = subtotal + ($(this).html() * 1);
  	})
  	nettotal = subtotal;
  	due = nettotal;
  	$("#subtotal").val(subtotal);
  	$("#discount").val(0);
  	$("#paid").val(0);
  	$("#nettotal").val(nettotal);
  	$("#due").val(due);
  }

  $(document).on("change keyup blur", "#discount", function() {
 $('#paid').val(0); 
  

  var disc = $('#discount').val();
  var subtotal = $('#subtotal').val();
  var perc = (subtotal * (disc/100));
  var calc = (subtotal - perc).toFixed(2);
  $('#nettotal').val(calc);
  $('#due').val(calc);
  });

  $(document).on("change keyup blur", "#paid", function() {
  var nettotal = $('#nettotal').val();
  var amntpaid = $('#paid').val();
 var due = (nettotal - amntpaid).toFixed(2);
  $('#due').val(due);
});
});


$('.paymentmethod').select2({
        placeholder: 'Payment method',
      });