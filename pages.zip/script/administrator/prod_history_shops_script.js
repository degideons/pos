$('document').ready(function()
{

var dataTable = $('#shop_table-grid').DataTable( {
                    "processing": true,
                    "serverSide": true,
                    "ajax":{
                        url :"../../production/administrator/prod_history_shopsdet.php", // json datasource
                        type: "post",  // method  , by default get
                        error: function(){  // error handling
                            $(".shop_table-grid-error").html("");
                            $("#shop_table-grid").append('<tbody class="shop_table-grid-error"><tr><th colspan="3" style="text-align:center">No data found in the server</th></tr></tbody>');
                            $("#shop_table-grid_processing").css("display","none");
                            
                        }
                    }
        });
    
});
function myFunction() {
    location.reload();
}