$('document').ready(function()
{

var dataTable = $('#shop_table-grid').DataTable( {
                    "processing": true,
                    "serverSide": true,
                    "ajax":{
                        url :"../../production/administrator/productsdet.php", // json datasource
                        type: "post",  // method  , by default get
                        error: function(){  // error handling
                            $(".shop_table-grid-error").html("");
                            $("#shop_table-grid").append('<tbody class="shop_table-grid-error"><tr><th colspan="3" style="text-align:center">No data found in the server</th></tr></tbody>');
                            $("#shop_table-grid_processing").css("display","none");
                            
                        }
                    }
        });

    /* insert data */
    $("#register-form").validate({
       
        submitHandler: submitForm
    });
    /* validation */

    /* form submit */
    function submitForm()
    {
        var data = $("#register-form").serialize();

        $.ajax({

            type : 'POST',
            url  : '../../production/administrator/addproduct.php',
            data : data,
            beforeSend: function()
            {
                $("#error").fadeOut();
                $("#btn-submit").html('<span class="glyphicon glyphicon-transfer"></span> &nbsp; sending ...');
            },
            success :  function(data)
            {
                if(data==1){

                    $("#error").fadeIn(1000, function(){
                         $("#success").fadeOut();

                        $("#error").html('<div class="alert alert-danger"> <span class="glyphicon glyphicon-info-sign"></span> &nbsp; Product already exists !</div>');

                        $("#btn-submit").html('<span class="glyphicon glyphicon-log-in"></span> &nbsp; Save');
                    });
                }
                else if(data=="success")
                {
                   $("#error").fadeOut();
                    $("#btn-submit").html('Save');
                    $("#success").html('<div class="alert alert-success"><span class="glyphicon glyphicon-info-sign"></span> &nbsp; Records successfully saved !</div>');

                }
                else{

                        $("#error").fadeIn(1000, function(){
                        $("#success").fadeOut();

                        $("#error").html('<div class="alert alert-danger"><span class="glyphicon glyphicon-info-sign"></span>&nbsp; Sorry, records not saved !</div>');

                        $("#btn-submit").html('<span class="glyphicon glyphicon-log-in"></span> &nbsp; Save');

                    });

                }
            }
        });
        return false;
    }
    /* form submit */
});
function myFunction() {
    location.reload();
}