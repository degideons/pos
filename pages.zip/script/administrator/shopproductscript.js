$('document').ready(function(){
  $('#add').click(function(){
	  var shops = $('#shop').val();
	  if(shops == ''){
		  alert("Please select Shop");
	  }else{
   var html = '<tr>';
   html += '<td><b class="numb">1</b></td>';
   html += '<td><select name="pid[]" id="pid" class="pid form-control" style="width: 100%" required="required"></select><input type="hidden" class="prodname form-control" name="prodname[]" id="prodname" readonly="readonly"  required="required"></td>';
   html += '<td style="width:20%"><input type="text" class="instock form-control" name="instock" id="instock" readonly="readonly" required="required"></td>';
   html += '<td style="width:20%"><input type="text" class="quantity form-control" name="quantity[]" id="quantity" required="required"></td>';
   html += '<td style="text-align: center;"><button class="remove btn btn-danger" data-toggle="tooltip" title="Remove" name="Remove"><span class="glyphicon glyphicon-trash"></span></button></td>';
   html += '</tr>';
   $('#order_table-grid tbody').prepend(html);
   var n = 0;
   $(".numb").each(function(){
   $(this).html(++n); 
   })

   $('.pid').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/administrator/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
	  }
  });

  $('.shop').select2({
        placeholder: 'Select Shop',
        ajax: {
          url: '../../production/administrator/shopnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
  $(document).on("change","#shop",function(){
	  var shop = $(this).val();
	
	  $.ajax({
		  url:"../../production/administrator/dispshoptype.php",
		  method: "POST",
		  data:{shop:shop},
		  success:function(data){
			  $("#dispShoptype").html(data);
		  }
	  })
  })

  $("#showorderlist").delegate(".pid","change",function(){
  	var pid = $(this).val();
    var shop = $("#shop").val();
  	var tr = $(this).parent().parent();
	  
  	$.ajax({
  		url:'../../production/administrator/neworderitems.php',
  		method:'POST',
  		dataType: 'json',
  		data:{priceqty:1,id:pid,shop:shop},
  		success: function(data){
			
        tr.find(".prodname").val(data["Product"]);
        tr.find(".instock").val(data["Quantity"]);
  			tr.find(".quantity").val(1);
  		}
  	})
  });

  $('table tbody').on('click','.remove', function(){
   $(this).closest('tr').remove();
  });
});

  $('select[name="shop"]').change(function(){
  $("#toshopname").val($("#shop option:selected").text());
 });
