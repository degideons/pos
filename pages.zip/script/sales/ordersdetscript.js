$('document').ready(function()
{

var dataTable = $('#shop_table-grid').DataTable( {
                    "processing": true,
                    "serverSide": true,
                    "ajax":{
                        url :"../../production/sales/ordersdet.php", // json datasource
                        type: "post",  // method  , by default get
                        error: function(){  // error handling
                            $(".shop_table-grid-error").html("");
                            $("#shop_table-grid").append('<tbody class="shop_table-grid-error"><tr><th colspan="3" style="text-align:center">No data found in the server</th></tr></tbody>');
                            $("#shop_table-grid_processing").css("display","none");
                            
                        }
                    }
        });

    /* form submit */
});
function myFunction() {
    location.reload();
}