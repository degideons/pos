$('document').ready(function(){
  $('#add').click(function(){
   var html = '<tr>';
   html += '<td><b class="numb">1</b></td>';
   html += '<td style="width:13%"><select class="pricetype form-control" name="pricetype" id="pricetype" required="required"><option></option><option value="Retail">Retail</option><option value="Wholesale">Wholesale</option></select></td>';
   html += '<td ><select name="pid[]" id="pid" class="pid form-control" style="width: 100%" required="required"></select><input type="hidden" class="prodname form-control" name="prodname[]" id="prodname" readonly="readonly"  required="required"></td>';
   html += '<td style="width:8%"><input type="text" class="tquantity form-control" name="tquantity[]" id="tquantity" readonly="readonly"  required="required"></td>';
   html += '<td style="width:8%"><input type="text" class="quantity form-control" name="quantity[]" id="quantity" required="required"></td>';
   html += '<td style="width:8%"><input type="text" class="remqty form-control" name="remqty[]" id="remqty" readonly="readonly"  required="required"></td>';
   html += '<td style="width:10%"><input type="text" class="price form-control" name="price[]" id="price" readonly="readonly" required="required"></td>';
   html += '<td style="text-align: center;">&cent; <span class="amount" id="amount">0.00</span></td>';
   html += '<td style="width:5%"><input type="text" class="discount form-control" name="discount[]" id="discount" required="required"></td>';
   html += '<td style="text-align: center;">&cent; <span class="sub_total" id="sub_total">0.00</span></td>';
   html += '<td style="text-align: center;"><button class="remove btn btn-danger" data-toggle="tooltip" title="Remove" name="Remove"><span class="glyphicon glyphicon-trash"></span></button></td>';
   html += '</tr>';
   $('#order_table-grid tbody').prepend(html);
   var n = 0;
   $(".numb").each(function(){
   $(this).html(++n); 
   })

      $('.pricetype').select2({
        placeholder: 'Select price type',
      });
  });
  $("#showorderlist").delegate(".pricetype","change",function(){
    $('.pid').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/sales/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
  })

  $("#showorderlist").delegate(".pid","change",function(){
  
    var pid = $(this).val();
    var tr = $(this).parent().parent();
 
    $.ajax({
      url:'../../production/sales/neworderitem.php',
      method:'POST',
      dataType: 'json',
      data:{priceqty:1,id:pid},
      success: function(data){
      if(tr.find(".pricetype").val() == "Retail"){
        tr.find(".discount").val(0);
        tr.find(".prodname").val(data["Product"]);
        tr.find(".tquantity").val(data["Quantity"]);
        tr.find(".quantity").val(0);
        tr.find(".price").val(data["RetailPrice"]);
        tr.find(".amount").html(tr.find(".quantity").val() * tr.find(".price").val());
        tr.find(".sub_total").html(tr.find(".quantity").val() * tr.find(".price").val());
        tr.find(".remqty").val(tr.find(".tquantity").val() - tr.find(".quantity").val());
        calculate();
      }else if(tr.find(".pricetype").val() == "Wholesale"){
        tr.find(".discount").val(0);
        tr.find(".prodname").val(data["Product"]);
        tr.find(".tquantity").val(data["Quantity"]);
        tr.find(".quantity").val(0);
        tr.find(".price").val(data["SellingPrice"]);
        tr.find(".amount").html(tr.find(".quantity").val() * tr.find(".price").val());
        tr.find(".sub_total").html(tr.find(".quantity").val() * tr.find(".price").val());
        tr.find(".remqty").val(tr.find(".tquantity").val() - tr.find(".quantity").val());
        calculate();
      }
      }
    })
  });

  $("#showorderlist").delegate(".quantity","keyup",function(){
    var qty = $(this);
    var tr = $(this).parent().parent();
   
    if(isNaN(qty.val())){
      alert("please enter a number");
      qty.val(1);
    }
     else{
      if(qty.val() > tr.find(".tquantity").val()-0){
        alert("Sorry! This quantity is not available");
        qty.val(0);
        tr.find(".discount").val(0);
        tr.find(".remqty").val(tr.find(".tquantity").val() - qty.val());
        tr.find(".amount").html(qty.val() * tr.find(".price").val());
        tr.find(".sub_total").html(qty.val() * tr.find(".price").val());
      }else{
        tr.find(".discount").val(0);
        tr.find(".remqty").val(tr.find(".tquantity").val() - qty.val());
        tr.find(".amount").html((qty.val() * tr.find(".price").val()).toFixed(2));
        tr.find(".sub_total").html((qty.val() * tr.find(".price").val()).toFixed(2));
        calculate();
      }
     }
  });

  $('table tbody').on('click','.remove', function(){
   $(this).closest('tr').remove();
   calculate(0,0);
  });

  $('.pid').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/sales/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });

  function calculate(){
    var subtotal = 0;
    var nettotal = 0;
    var due = 0;

    $(".sub_total").each(function(){
        subtotal = subtotal + ($(this).html() * 1);
    })
    nettotal = (subtotal).toFixed(2);
    due = nettotal;
    $("#subtotal").val(subtotal);
    //$("#discount").val(0);
    $("#paid").val(0);
    $("#nettotal").val(nettotal);
    $("#due").val(due);
  }

$("#showorderlist").delegate(".discount","keyup",function(){
    var discount = $(this);
    var tr = $(this).parent().parent();
    tr.find(".sub_total").html(tr.find(".amount").html() - discount.val());
       calculate();
  });
 

  $(document).on("change keyup blur", "#paid", function() {
  var nettotal = $('#nettotal').val();
  var amntpaid = $('#paid').val();

  var compamnt = new Number(amntpaid);
  var compnet = new Number(nettotal);
  if(compamnt > compnet){
    alert('Please, Amount paid cannot be greater than Net Total');

    $('#paid').val(0);
    $('#due').val(nettotal);
  }
  else{
 var due = (nettotal - amntpaid).toFixed(2);
  $('#due').val(due);
  }
});
});


$('.paymentmethod').select2({
        placeholder: 'Payment method',
      });
