<?php include 'admheader.php';?>
<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
       <div class="user-panel">
        <div class="pull-left image">
          <img src="../../dist/img/pos.png" class="img-circle" alt="User Image">
       </div>
        <div class="pull-left info">
          <p><?php echo $usertype; ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li>
          <a href="dashboard.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span> Manage Stock</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="distproducts.php"><i class="fa fa-circle-o"></i> Add New Shop Products</a></li>
            <li><a href="shops.php"><i class="fa fa-circle-o"></i> Check Stock</a></li>
             <li><a href="prod_history_shops.php"><i class="fa fa-circle-o"></i> Shop Products History</a></li>
            <li><a href="transferprod.php"><i class="fa fa-circle-o"></i> Transfer Products</a></li>
            <li><a href="transhops.php"><i class="fa fa-circle-o"></i> Transfer Details</a></li>
            <!--li><a href="update_shop_products.php"><i class="fa fa-circle-o"></i> Update Shop Products </a></li-->
            <li><a href="shop_prod_report.php"><i class="fa fa-circle-o"></i> Shop Products Report</a></li>
            <li><a href="transferprodreport.php"><i class="fa fa-circle-o"></i> Transferred Products Report</a></li>
          </ul>
        </li>

          <li class="treeview">
          <a href="#">
            <i class="fa fa-file"></i> <span>Manage Sales</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="sales_shop.php"><i class="fa fa-circle-o"></i> Sales Details</a></li>
            <li><a href="shoporders.php"><i class="fa fa-circle-o"></i> Total Sales</a></li>
            <li><a href="dsalesreport.php"><i class="fa fa-circle-o"></i> Daily Sales Report</a></li>
            <li><a href="othsalesreport.php"><i class="fa fa-circle-o"></i> Other Sales Report</a></li>
            <li><a href="transactionsreport.php"><i class="fa fa-circle-o"></i> Transactions Report</a></li>
          </ul>
        </li>

         <li class="treeview">
          <a href="#">
            <i class="fa fa-retweet"></i> <span>Manage Returns</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <!--li><a href="returnproduct.php"><i class="fa fa-circle-o"></i> Return Product</a></li-->
            <li><a href="return_prod_details.php"><i class="fa fa-circle-o"></i>Return Product Details</a></li>
            <li><a href="returned_prod_report.php"><i class="fa fa-circle-o"></i>Return Products Report</a></li>
          </ul>
        </li>

          <li class="treeview">
          <a href="#">
            <i class="fa fa-user"></i> <span>Manage Debtors</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="debtors.php"><i class="fa fa-circle-o"></i> Debtors</a></li>
            <li><a href="debtpayhistory.php"><i class="fa fa-circle-o"></i> Debt Payment History</a></li>
            <li><a href="debtorsreport.php"><i class="fa fa-circle-o"></i> Debtors Report </a></li>
          </ul>
        </li>


         <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i> <span>Expenses</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="expenses.php"><i class="fa fa-circle-o"></i> Expenses</a></li>
          </ul>
        </li>


          <li class="treeview">
          <a href="#">
            <i class="fa fa-money"></i> <span>Net Income</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="netincome.php"><i class="fa fa-circle-o"></i> Net Income</a></li>
          </ul>
        </li>

         <li class="treeview">
          <a href="#">
            <i class="fa fa-desktop"></i> <span>Manage Vendors</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="vendors.php"><i class="fa fa-circle-o"></i> Vendors</a></li>
            <li><a href="newpurchases.php"><i class="fa fa-circle-o"></i> New Purchases</a></li>
            <li><a href="purvendors.php"><i class="fa fa-circle-o"></i> Purchases</a></li>
          </ul>
        </li>


        


         <li class="treeview">
          <a href="#">
            <i class="fa fa-rub"></i> <span> Manage Products</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="prodcat.php"><i class="fa fa-circle-o"></i> Main Product Categories</a></li>
            <li><a href="brandet.php"><i class="fa fa-circle-o"></i> Brand</a></li>
            <li><a href="products.php"><i class="fa fa-circle-o"></i> Products</a></li>
            <li><a href="updateproduct.php"><i class="fa fa-circle-o"></i> Update Products</a></li>
            <li><a href="prodpricesreport.php"><i class="fa fa-circle-o"></i> Print Products Prices </a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-home"></i>
            <span>Manage Shop</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="shop.php"><i class="fa fa-circle-o"></i> Shop</a></li>
           <li><a href="updateshop.php"><i class="fa fa-circle-o"></i> Update Shop</a></li>
          </ul>
        </li>
      
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i>
            <span>Manage Users</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="addnewuser.php"><i class="fa fa-circle-o"></i> Add New User</a></li>
            <li><a href="userdetails.php"><i class="fa fa-circle-o"></i> Users Details</a></li>
			      <li><a href="status.php"><i class="fa fa-circle-o"></i> User Status</a></li>
          </ul>
        </li>

        <li>
          <a href="changepassword.php">
            <i class="fa fa-edit"></i> <span>Change Password</span>
          </a>
        </li>
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
