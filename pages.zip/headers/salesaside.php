<?php include 'salesheader.php';?>
<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
       <div class="user-panel">
        <div class="pull-left image">
          <img src="../../dist/img/pos.png" class="img-circle" alt="User Image">
       </div>
        <div class="pull-left info">
          <p><?php echo $fullname; ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li>
          <a href="dashboard.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
           
          </a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-rub"></i> <span> Manage Product</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="products.php"><i class="fa fa-circle-o"></i> Products</a></li>
            <li><a href="receivedproducts.php"><i class="fa fa-circle-o"></i> Received Products </a></li>
            <li><a href="prodpricesreport.php"><i class="fa fa-circle-o"></i> Print Products Prices </a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-file"></i> <span>Manage Orders</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
             <li><a href="neworder.php"><i class="fa fa-circle-o"></i> New Order</a></li>
            <li><a href="orders.php"><i class="fa fa-circle-o"></i> Orders</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-money"></i> <span>Manage Debtors</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="debtors.php"><i class="fa fa-circle-o"></i> Debtors</a></li>
            <li><a href="debtpayhistory.php"><i class="fa fa-circle-o"></i> Debt Payment History</a></li>
          </ul>
        </li>

         <li class="treeview">
          <a href="#">
            <i class="fa fa-retweet"></i> <span>Manage Returns</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="returnproduct.php"><i class="fa fa-circle-o"></i> Return Product</a></li>
            <li><a href="return_prod_details.php"><i class="fa fa-circle-o"></i>Return Product Details</a></li>
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-folder"></i> <span>Manage Reports</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="dsalesreport.php"><i class="fa fa-circle-o"></i> Daily Sales Report</a></li>
            <li><a href="othsalesreport.php"><i class="fa fa-circle-o"></i> Other Sales Report</a></li>
            <li><a href="receivedprodreport.php"><i class="fa fa-circle-o"></i> Received Products Report</a></li>
            <li><a href="debtorsreport.php"><i class="fa fa-circle-o"></i> Debtors Report </a></li>
            <li><a href="returned_prod_report.php"><i class="fa fa-circle-o"></i> Returned Product Report </a></li>
          </ul>
        </li>

        <li>
          <a href="changepassword.php">
            <i class="fa fa-edit"></i> <span>Change Password</span>
          </a>
        </li>   
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
