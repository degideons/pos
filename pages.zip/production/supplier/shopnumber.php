<?php
include("../../connection/config.php");
session_start();
$shopid = $_SESSION["shopid"];

            
	$sql = "SELECT distinct * from shop where Shop like '%". $_GET['q'] ."%' and ShopID !='$shopid' order by ShopID asc limit 10";
	$result = $mysqli->query($sql);
	$json = [];
	
	while($row = $result->fetch_assoc())
	{
		$json[] = ['id'=>$row['ShopID'], 'text'=>$row['Shop']];
	}
   echo json_encode($json);
			?>