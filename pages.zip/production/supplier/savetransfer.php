<?php
include '../../connection/config.php';
session_start();
error_reporting(0);
$shopid = $_SESSION["shopid"];


//if(isset($_POST['btnorder'])){
//$distid = rand(00000000,99999999);
$shop =    $_POST["shop"];
$pid =      $_POST["pid"];
$quantity = $_POST['quantity'];
$tquantity = $_POST['tquantity'];
$userid = $_SESSION['userid'];
$totquantity = 0;



for($i=0;$i<count($pid);$i++)
{
	
$stmt = $mysqli->prepare("select * from distribute where ShopID=? and ProductID=?");
$stmt->bind_param("ss",$shop,$pid[$i]);
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;
if($count > 0)
{
$totalquantity = $tquantity[$i] - $quantity[$i];
if($totalquantity < 0){
	echo "check";
}else{
	$row = $results->fetch_assoc();
$totquantity = $quantity[$i] + $row["Quantity"];
$stmt = $mysqli->prepare("update distribute set Quantity=?, UserID =? where ShopID=? and ProductID=?");
$stmt->bind_param("ssss",$totquantity,$userid,$shop,$pid[$i]);
$res = $stmt->execute();


$stmt = $mysqli->prepare("update distribute set Quantity=? where ShopID=? and ProductID=?");
$stmt->bind_param("sss",$totalquantity,$shopid,$pid[$i]);
$res = $stmt->execute();

$stmt = $mysqli->prepare("insert into transferprod(ShopID,ProductID,Quantity,UserID,FromShop)values(?,?,?,?,?)");
$stmt->bind_param("sssss",$shop,$pid[$i],$quantity[$i],$userid,$shopid);
$res = $stmt->execute();
}
}
else{
	$totalquantity = $tquantity[$i] - $quantity[$i];
	if($totalquantity < 0){
	echo "check";
}else{
$stmt = $mysqli->prepare("insert into distribute(ShopID,ProductID,Quantity,UserID)values(?,?,?,?)");
$stmt->bind_param("ssss",$shop,$pid[$i],$quantity[$i],$userid);
$res = $stmt->execute();

$stmt = $mysqli->prepare("update distribute set Quantity=? where ShopID=? and ProductID=?");
$stmt->bind_param("sss",$totalquantity,$shopid,$pid[$i]);
$res = $stmt->execute();

$stmt = $mysqli->prepare("insert into transferprod(ShopID,ProductID,Quantity,UserID,FromShop)values(?,?,?,?,?)");
$stmt->bind_param("sssss",$shop,$pid[$i],$quantity[$i],$userid,$shopid);
$res = $stmt->execute();
}
}
}

if($res){
	echo "ok";
}
else{
	echo "error";
}
//}
?>