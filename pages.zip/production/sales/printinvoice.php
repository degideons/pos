<?php
include "../fpdf/fpdf.php";
session_start();

if($_GET['orderdate'] && $_GET['invoiceno']){
     $pdf = new FPDF();
     $pdf->AddPage();

     $pdf->setFont("Arial","B",12);
     $pdf->Cell(60,10,"FRONT VIEW ENTERPRISE",0,1,"C");
     $pdf->Cell(80,10,"Papafio Lane Okaishie, Bicycle Lane, Accra",0,1,"C");
     $pdf->setFont("Arial",null,12);
     $pdf->Cell(60,10,"Tel: +233248464247",0,1,"C");
     $pdf->setFont("Arial",null,12);
     $pdf->Cell(60,10,"INVOICE",0,1,"C");
     $pdf->setFont("Arial",null,9);
  
     $pdf->Cell(50,10,"Invoice Number",0,0);
     $pdf->Cell(50,10,":  ". $_GET['invoiceno'] ,0,1);
     $pdf->Cell(50,10,"Date",0,0);
     $pdf->Cell(50,10,":  ". $_GET['orderdate'] ,0,1);
     $pdf->Cell(50,10,"Customer Name",0,0);
     $pdf->Cell(50,10,":  ". $_GET['customer'] ,0,1);

     $pdf->Cell(50,10,"" ,0,1);
     
     $pdf->Cell(5,10,"#",1,0,"C");
     $pdf->Cell(30,10,"Product",1,0,"C");
     $pdf->Cell(10,10,"Qty",1,0,"C");
     $pdf->Cell(12,10,"Price",1,0,"C");
     $pdf->Cell(12,10,"Total",1,0,"C");
     $pdf->Cell(8,10,"Disc ",1,0,"C");
     $pdf->Cell(14,10,"Sub Total ",1,1,"C");

     for($i=0; $i < count($_GET["pid"]); $i++){
     	$pdf->Cell(5,10, ($i+1),1,0,"C");
     	$pdf->Cell(30,10, $_GET['prodname'][$i],1,0,"C");
     	$pdf->Cell(10,10, $_GET['quantity'][$i],1,0,"C");
     	$pdf->Cell(12,10, $_GET['price'][$i],1,0,"C");
     	$pdf->Cell(12,10, $_GET['quantity'][$i] * $_GET['price'][$i],1,0,"C");
          $pdf->Cell(8,10, $_GET['discount'][$i],1,0,"C");
          $pdf->Cell(14,10, ($_GET['quantity'][$i] * $_GET['price'][$i])-$_GET['discount'][$i],1,1,"C");
     }

     $pdf->Cell(50,10,"" ,0,1);

     $pdf->Cell(50,10,"Net Total" ,0,0);
     $pdf->Cell(50,10,":  GHC ". $_GET['nettotal'] ,0,1);
     $pdf->Cell(50,10,"Paid" ,0,0);
     $pdf->Cell(50,10,":  GHC ". $_GET['paid'] ,0,1);
     $pdf->Cell(50,10,"Credit" ,0,0);
     $pdf->Cell(50,10,":  GHC ". $_GET['due'] ,0,1);
     $pdf->Cell(50,10,"Payment Method" ,0,0);
     $pdf->Cell(50,10,":  ". $_GET['paymentmethod'] ,0,1);

     $pdf->Cell(180,10,"God richly bless you!" ,0,1,"R");

     //$pdf->Output("../pdf_invoice/pdf_invoice". $_GET["invoiceno"].".pdf","F");

     $pdf->Output();
}
?>