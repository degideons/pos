<?php
include "../../connection/config.php";
session_start();
$shopsid = $_SESSION['shopid'];

$shopid = mysqli_real_escape_string($mysqli,$_POST['shopid']);
$invoice_detid = mysqli_real_escape_string($mysqli,$_POST['invoice_detid']);
$invoice_no = mysqli_real_escape_string($mysqli,$_POST['invoice_no']);
$productid = mysqli_real_escape_string($mysqli,$_POST['productid']);
$qty = mysqli_real_escape_string($mysqli,$_POST['qty']);
$returns = mysqli_real_escape_string($mysqli,$_POST['returns']);
$remaining = mysqli_real_escape_string($mysqli,$_POST['remaining']);
$total = mysqli_real_escape_string($mysqli,$_POST['total']);
$discount = mysqli_real_escape_string($mysqli,$_POST['discount']);
$subtotal = mysqli_real_escape_string($mysqli,$_POST['subtotal']);
$price = mysqli_real_escape_string($mysqli,$_POST['price']);
$date = date("Y-m-d");
$time = date("H:i:s");


$stmt = $mysqli->prepare("update distribute set Quantity= Quantity + ? where ShopID = ? and ProductID = ?");
$stmt->bind_param("sss",$returns,$shopid,$productid);
if($stmt->execute()){
    $stmt = $mysqli->prepare("update invoice set NetTotal= NetTotal - ?,Paid = Paid - ? where InvoiceNo = ? and ShopID = ?");
    $stmt->bind_param("ssss",$subtotal,$subtotal,$invoice_no,$shopid);
    if($stmt->execute()){
        $stmt = $mysqli->prepare("update invoice_details set Qty= ?,Discount = Discount - ? where InvDetID = ?");
        $stmt->bind_param("sss",$remaining,$discount,$invoice_detid);
        if($stmt->execute()){
        $stmt = $mysqli->prepare("insert into returnproducts(InvoiceNo,ProductID,rPrice,Bought,Returned,rDiscount,ShopID,ReturnDate,ReturnTime)values(?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssssss",$invoice_no,$productid,$price,$qty,$returns,$discount,$shopid,$date,$time);
        if($stmt->execute()){
           echo "Product(s) successfully returned";
        }
        else{
            echo "Sorry, Product(s) not returned";
        }
      }
      else{
            echo "Sorry, Product(s) not returned";
        }
    }
    else{
            echo "Sorry, Product(s) not returned";
        }

}
else{
            echo "Sorry, Product(s) not returned";
        }
?>