<?php
include '../../connection/config.php';
session_start();
$shopid = $_SESSION["shopid"];

if(isset($_POST['priceqty'])){
	$id = $_POST['id'];

	$sql = $mysqli->query("select * from distribute d, products p where d.ProductID = p.ProductID and d.ShopID='$shopid' and d.ProductID ='$id'");
	$row = $sql->fetch_assoc();
	echo json_encode($row);
}
?>