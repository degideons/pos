<?php
/* Database connection start */
include("../../connection/config.php");
session_start();

//cancel data
	if($_POST["action"] == "Cancel"){
		$data_id = $_POST['data_id'];
		$status = 'Cancelled';

		$stmt = $mysqli->prepare("Select * from invoice_details d,invoice i,products p where d.InvoiceNo=i.InvoiceNo and d.ProductID=p.ProductID and d.InvoiceNo=?");
		$stmt->bind_param("s",$data_id);
		$stmt->execute();
		$res = $stmt->get_result();
		while($row = $res->fetch_assoc()){
	    $shopid = $row['ShopID'];
		$product_id = $row['ProductID'];
	    $quantity = $row['Qty'];

	    $stmt = $mysqli->prepare("update distribute set Quantity = Quantity + ? where ShopID=? and ProductID=?");
	    $stmt->bind_param("sss",$quantity,$shopid,$product_id);
	    $results = $stmt->execute();
	}
	if($results){
		$stmt = $mysqli->prepare("update invoice set Status=? where InvoiceNo=?");
	    $stmt->bind_param("ss",$status,$data_id);
	    if($stmt->execute()){
	    	echo "Transaction successfully cancelled";
	    }
	    else{
	    	echo "Sorry transaction not cancelled!";
	    }
	}
}
	?>