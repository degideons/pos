<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
 <?php
include("../../connection/config.php");


    if(isset($_POST["debt_number"])){
    $debt_number = $_POST["debt_number"];
    
    $sql = "SELECT * from invoice where InvoiceNo like '%$debt_number%' order by InvoiceDate desc";
    $res = mysqli_query($mysqli,$sql) or die('Error, query failed');
      
    if($res->num_rows > 0)
    {
    $row = $res->fetch_assoc();
    ?>

 <div class="form-group">
  <label for="label"> Total Debt</label>
  <input type="hidden" name="invoicenum" class="form-control" id="invoicenum" value="<?php echo $row['InvoiceNo']?>" placeholder="Shop" required="required" readonly="readonly"> 

      <input type="text" name="totaldebt" class="form-control" id="totaldebt" value="<?php echo $row['Due']?>" placeholder="Shop" required="required" readonly="readonly">   
        </div>

     <div class="form-group">
     <label for="label"> Pay</label>
     <input type="hidden" name="curpaid" class="form-control" id="curpaid" value="<?php echo $row['Paid']?>"  required="required">

      <input type="text" name="pay" class="form-control" id="pay" placeholder="Paid" required="required">
   </div>

   <div class="form-group">
     <label for="label"> Due</label>
      <input type="text" name="due" class="form-control" id="due" placeholder="Due" required="required" readonly="readonly">
   </div>
   <div class="button-group">
  <button type="submit" class="btn btn-primary" name="btn_pay_debt" id="btn_pay_debt">Pay Debt</button>
  <button type="button" class="btn btn-warning" name="refresh" id="refresh" onClick="refreshPage()">Refresh Page</button>
  </div>

<?php 
   }
else{
  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong></strong> Sorry! No record(s) available.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
 }
}
?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
<script type="text/javascript">
  $(document).on("change keyup blur","#pay",function(){
      var pay = $("#pay").val();
      var totaldebt = $("#totaldebt").val();
      var balance;
      balance = (totaldebt - pay).toFixed(2);
      $("#due").val(balance);
    })
  function refreshPage() {
    location.reload();
}
       
</script>