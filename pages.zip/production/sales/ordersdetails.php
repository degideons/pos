<?php
include "../../connection/config.php";
?>
<div id="printpage">
    <table>
        <tr>
            <td>
            <h4 style="font-weight: bold">FRONT VIEW ENTERPRISE<br/>
            Papafio Lane Okaishie, Bicycle Lane, Accra<br/>
            Tel: +233248464247<br/>
            INVOICE</h4>
        </td>
        </tr>
    </table>
    <?php
    if(isset($_POST['get_select_invoice'])){
        $invoicenum = $_POST['inoicid'];
        $stmt = $mysqli->prepare("select * from invoice where InvoiceNo=?");
        $stmt->bind_param("s",$invoicenum);
        $stmt->execute();
       $res = $stmt->get_result();
       if($row = $res->fetch_assoc()){
        $ordernumber = $row['InvoiceNo'];
        $customer = $row['CustomerName'];
        $orderdate = $row['InvoiceDate'];
        $nettotal = $row['NetTotal'];
        $paid = $row['Paid'];
        $credit = $row['Due'];
        $paymenttype = $row['PaymentType'];
       }
      }
    ?>
    <div id="results">
    <div><label for="label" style="font-size: 15px;font-weight: bold">Invoice Number : <?php echo $ordernumber; ?></label></div>
    <div><label for="label" style="font-size: 15px;font-weight: bold">Date : <?php echo $orderdate; ?></label></div>
    <div><label for="label" style="font-size: 15px;font-weight: bold">Customer Name : <?php echo $customer; ?></label></div>
</div>
<table class="table table-bordered  table-hover" id="order_table-grid">
    <thead>
    <tr>
    <th>#</th>
    <th>Item</th>
    <th>Qty</th>
    <th>Price</th>
    <th>Total</th>
    <th>Disc</th>
    <th>Sub Total</th>
    </tr>
    </thead>
    <tbody>
    <?php
    if(isset($_POST['get_select_invoice'])){
    	$invoiceno = $_POST['inoicid'];
    	$total = 0;
        $sub_total = 0;
    	$gtotal = 0;
    $no = 1;
    $stmt = $mysqli->prepare("select * from invoice_details i,products p where i.Qty !='0' and i.ProductID=p.ProductID and i.InvoiceNo=?");
    $stmt->bind_param("s",$invoiceno);
    $stmt->execute();
    $rest = $stmt->get_result();
    while($rows = $rest->fetch_assoc()){
    	$total = $rows['Price'] * $rows['Qty'];
        $discount = $rows['Discount'];

        $sub_total = $total - $discount;
    	$gtotal = $gtotal + $sub_total;
    ?>
    <tr>
    <td><?php echo $no;?></td>
    <td><?php echo $rows['Product']?></td>
    <td><?php echo $rows['Qty']?></td>
    <td><?php echo "&cent;".$rows['Price']?></td>
    <td><?php echo "&cent;".$total;?></td>
    <td><?php echo $rows['Discount']?></td>
    <td><?php echo "&cent;".$sub_total;?></td>
    </tr>
<?php
$no++;
}
}
?>
</tbody>
</table>
<div id="results">
    <div><label for="label" style="font-size: 15px;font-weight: bold">Net Total : &cent;<?php echo $nettotal; ?></label></div>
    <div><label for="label" style="font-size: 15px;font-weight: bold">Paid : &cent;<?php echo $paid; ?></label></div>
    <div><label for="label" style="font-size: 15px;font-weight: bold">Credit : &cent;<?php echo $credit; ?></label></div>
    <div><label for="label" style="font-size: 15px;font-weight: bold">Payment Type : <?php echo $paymenttype; ?></label></div>
</div>
</div>
<div class="button-group">
  <button type="button" class="btn btn-primary pull-right" onclick="printDiv()">Print</button></div>
  </div>
  <script type="text/javascript">
      function printDiv() {    
    var printContents = document.getElementById('printpage').innerHTML;
    var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
    }
  </script>
