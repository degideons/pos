<?php
include '../../connection/config.php';
session_start();
error_reporting(0);
$userid = $_SESSION['userid'];
$shopid = $_SESSION["shopid"];
$status = 'Transacted';

function uuid(){
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); 
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); 
        return vsprintf('%s%s%s', str_split(bin2hex($data), 4));
}

$ordersid = uuid();
$pid =      $_POST["pid"];
$tquantity = $_POST['tquantity'];
$quantity = $_POST["quantity"];
$remqty = $_POST['remqty'];
$price =    $_POST["price"];
$discount =  $_POST['discount'];

$orderdate = mysqli_real_escape_string($mysqli,$_POST['orderdate']);
$customer = mysqli_real_escape_string($mysqli,$_POST['customer']);
$phone = mysqli_real_escape_string($mysqli,$_POST['phone']);
$nettotal = mysqli_real_escape_string($mysqli,$_POST['nettotal']);
$paid =     mysqli_real_escape_string($mysqli,$_POST['paid']);
$due =      mysqli_real_escape_string($mysqli,$_POST['due']);
$paymentmethod = mysqli_real_escape_string($mysqli,$_POST['paymentmethod']);

for($i=0;$i<count($pid);$i++)
{
	$totquantity = $tquantity[$i] - $quantity[$i];
	if($totquantity < 0){
		echo "check";
	}
	else{
		$stmt = $mysqli->prepare("update distribute set Quantity=? where ShopID=? and ProductID =?");
		$stmt->bind_param("sss",$remqty[$i],$shopid,$pid[$i]);
		$res = $stmt->execute();
	}
	
$stmt = $mysqli->prepare("insert into invoice_details(InvoiceNo,ProductID,Qty,Price,Discount)values(?,?,?,?,?)");
$stmt->bind_param("sssss",$ordersid,$pid[$i],$quantity[$i],$price[$i],$discount[$i]);
$res = $stmt->execute();
}
if($res){
	$stmt = $mysqli->prepare("insert into invoice(InvoiceNo,CustomerName,CustPhone,NetTotal,Paid,Due,PaymentType,InvoiceDate,ShopID,UserID,Status)values(?,?,?,?,?,?,?,?,?,?,?)");
$stmt->bind_param("sssssssssss",$ordersid,$customer,$phone,$nettotal,$paid,$due,$paymentmethod,$orderdate,$shopid,$userid,$status);
$res = $stmt->execute();
if($res){
	echo $ordersid;
}
else{
	echo "error";
}
}
else{
	echo "error";
}
?>