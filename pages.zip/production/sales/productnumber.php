<?php
include("../../connection/config.php");
session_start();
$shopid = $_SESSION["shopid"];

	$sql = "SELECT distinct * from distribute d,products p where d.ProductID=p.ProductID and d.ShopID ='$shopid' and  p.Product like '%". $_GET['q'] ."%' limit 10";
	$result = $mysqli->query($sql);
	$json = [];
	
	while($row = $result->fetch_assoc())
	{
		$json[] = ['id'=>$row['ProductID'], 'text'=>$row['Product']];
	}
   echo json_encode($json);
	?>