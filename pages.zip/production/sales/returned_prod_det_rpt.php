<?php
include("../../connection/config.php");
session_start();
$shopid = $_SESSION["shopid"];
error_reporting(0);

if(isset($_POST["txtfrom"]) && isset($_POST["txtto"])){
$txtfrom = $_POST["txtfrom"];
$txtto = $_POST["txtto"];
$date = date("Y-m-d");
$output = '';
$returned = 0;
$amnt_given = 0;
$total_amnt_given = 0;
//$status = 'Transacted';

$stmt = $mysqli->prepare("select * from returnproducts r,invoice i, products p, shop s where r.InvoiceNo=i.InvoiceNo and r.ProductID = p.ProductID and r.ShopID = s.ShopID and r.ReturnDate between ? and ? and r.ShopID = ?");
$stmt->bind_param("sss",$txtfrom,$txtto,$shopid);
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;

if($count > 0){
	$no = 1;
	$output .= '<div id="printpage">
          <center>
           <div>
           <h2>FRONT VIEW ENTERPRISE</h2>
           <h3>Papafio Lane Okaishie, Bicycle Lane, Accra</h3>
           <h4>Tel: +233248464247</h4>
           <h4>RETURNED PRODUCTS REPORT BETWEEN '.$txtfrom.' AND '.$txtto.' </h4>
          </div><hr>
</center>
  <div class="table-responsive" >
	       <table id="daily_sales_table" class="table table-striped" style="width:100%">
	        <thead>
		   <tr>
		   <th>No</th>
           <th>Customers</th>
           <th>Product</th>
           <th>Price</th>
           <th>Bought</th>
           <th>Returned</th>
           <th>Total (&cent;)</th>
           <th>Discount</th>
           <th>Amount Given Out</th>
           <th>Returned Date</th>
           <th>Returned Time</th>
		   </tr>
		   </thead>
		   <tbody>';
		   while($row = $results->fetch_assoc()){
        $shopname = $row['Shop'];
		   	$returned = $returned + $row["Returned"];
		   	$amnt_given = ($row["Returned"] * $row["rPrice"]) - $row["rDiscount"];
        $total_amnt_given = $total_amnt_given + $amnt_given;
$output .='<tr>
           <td>'.$no.'</td>
           <td>'.$row["CustomerName"].'</td>
           <td>'.$row["Product"].'</td>
           <td>'.$row["rPrice"].'</td>
           <td>'.$row["Bought"].'</td>
           <td>'.$row["Returned"].'</td>
           <td>'.$row["Returned"] * $row["rPrice"].'</td>
           <td>'.$row["rDiscount"].'</td>
           <td>'.$amnt_given.'</td>
           <td>'.$row["ReturnDate"].'</td>
           <td>'.$row["ReturnTime"].'</td>
           </tr>';
           $no++;
		   }
		   //$grandtotal = $totalpaid + $totaldue;
 
 $output .='<tr>
            <td colspan="5" align="right"><strong>Total Quantity Returned :</strong>
            </td><td><strong>'.$returned.'</strong></td>
            
            <td colspan="2" align="right"><strong>Total Money Given Out :</strong></td>
            <td><strong>&cent;'.$total_amnt_given.'</strong></d>
           </tr>
          
           </tbody>
           </table>
           <div><label for="label">Shop Name: '. $shopname.'</label></div>
	      </div></div>
        <div class="button-group">
  <button type="button" class="btn btn-warning pull-right" onclick="refreshPage()">Refresh Page</button>
  <button type="button" class="btn btn-primary pull-right" onclick="printDiv()">Print</button></div>
  </div>';
}
else{
	$output .='<center><h3>No records available</center><h3>';
}
echo $output;
}
?>