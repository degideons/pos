<?php
include("../../connection/config.php");

if(isset($_POST["btn_pay_debt"])){

$invoicenum = $_POST["invoicenum"];
$curpaid = $_POST["curpaid"];
$pay = $_POST["pay"];
$due = $_POST["due"];
$total_debt_paid = 0;

$total_debt_paid = $pay + $curpaid;


$stmt = $mysqli->prepare("update invoice set Paid=?, Due=? where InvoiceNo=?");
$stmt->bind_param("sss",$total_debt_paid,$due,$invoicenum);
$query = $stmt->execute();

if($query){
	$stmt = $mysqli->prepare("insert into debtpayment(InvoiceNo,Paid)values(?,?)");
	$stmt->bind_param("ss",$invoicenum,$pay);
	if($stmt->execute()){
      echo "paid";
	}
	else{
	echo "error";
   }
  }
else{
	echo "error";
 }
}
?>