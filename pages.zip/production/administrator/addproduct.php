<?php
include("../../connection/config.php");
session_start();
error_reporting(0);
if(isset($_POST['btnsave'])){
$productid = rand(000000,999999);
$prodcate =    $mysqli->real_escape_string($_POST["prodcate"]);
$brand =       $mysqli->real_escape_string($_POST["brand"]);
$product =       $mysqli->real_escape_string($_POST["product"]);
$unitprice =       $mysqli->real_escape_string($_POST["unitprice"]);
$sellingprice =       $mysqli->real_escape_string($_POST["sellingprice"]);
$retailprice =       $mysqli->real_escape_string($_POST["retailprice"]);
$userid = $_SESSION['userid'];

$stmt = $mysqli->prepare("select * from products where Product=?");
$stmt->bind_param("s",$product);
$stmt->execute();
$results= $stmt->get_result();
$count=$results->num_rows;
if($count == 0){

$stmt = $mysqli->prepare("insert into products(ProductID,MainProdcatID,BrandID,Product,UnitPrice,SellingPrice,RetailPrice,UserID)values(?,?,?,?,?,?,?,?)");
$stmt->bind_param("ssssssss",$productid,$prodcate,$brand,$product,$unitprice,$sellingprice,$retailprice,$userid);

if($stmt->execute()){
	echo "success";
   }
else
   {
	echo "error";
    }
  }
else
  {
	echo "1";
   }
}
?>