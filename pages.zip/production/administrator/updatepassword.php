<?php
include("../../connection/config.php");
session_start();
if(isset($_POST['btnupdate'])){

$oldpassword=$_POST['oldpassword'];
$password=$_POST['password'];
$userid = $_SESSION['userid'];

$oldpassword=(md5(sha1($oldpassword)).md5($oldpassword.'xxxx'));
$password=(md5(sha1($password)).md5($password.'xxxx'));

$stmt = $mysqli->prepare("select * from users where Password=?");
$stmt->bind_param("s",$oldpassword);
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;
if($count > 0){
$stmt = $mysqli->prepare("update  users set Password=? where UserID=?");
$stmt->bind_param("ss",$password,$userid);
$query = $stmt->execute();

if($query){
echo "updated";
}
else{
echo "error";
}
}
else{
	echo "1";
}
}