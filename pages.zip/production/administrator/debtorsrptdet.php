<?php
include("../../connection/config.php");
session_start();
$shopid = $_SESSION["shopid"];
error_reporting(0);

$output = '';
$totaldue = 0;
$status = 'Transacted';


$stmt = $mysqli->prepare("select * from invoice i,shop s where i.NetTotal !='0' and i.ShopID=s.ShopID and i.Due > 0 and i.Status=? ORDER BY Shop ASC");
$stmt->bind_param("s",$status);
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;

if($count > 0){
	$no = 1;
	$output .= '
  <div id="printpage">
<center>
<div class="heading">
<h2>FRONT VIEW ENTERPRISE</h2>
<h3>Papafio Lane Okaishie, Bicycle Lane, Accra</h3>
<h4>Tel: +233248464247</h4>
<h4>DEBTORS REPORT </h4>
</div><hr>
</center><div class="table-responsive" >
	       <table id="daily_sales_table" class="table table-striped" style="width:100%">
	        <thead>
		   <tr>
		   <th>No</th>
           <th>Shop</th>
           <th>Customers</th>
           <th>Telephone</th>
           <th>Net Total (&cent;)</th>
           <th>Paid (&cent;)</th>
           <th>Due (&cent;)</th>
           
		   </tr>
		   </thead>
		   <tbody>';
		   while($row = $results->fetch_assoc()){
$totaldue = $totaldue + $row["Due"];
$output .='<tr>
           <td>'.$no.'</td>
           <td>'.$row["Shop"].'</td>
           <td>'.$row["CustomerName"].'</td>
           <td>'.$row["CustPhone"].'</td>
           <td>'.$row["NetTotal"].'</td>
           <td>'.$row["Paid"].'</td>
           <td>'.$row["Due"].'</td>

           </tr>';
           $no++;
		   }
 
 $output .='<tr>
            <td colspan="6" align="right"><strong>Total Debt :</strong>
            </td><td><strong>&cent;'.$totaldue.'</strong></td>
            </tr>
           </tbody>
           </table>
	      </div></div>
        <div class="button-group">
  <button type="button" class="btn btn-warning pull-right" onclick="refreshPage()">Refresh Page</button>
  <button type="button" class="btn btn-primary pull-right" onclick="printDiv()">Print</button></div>
  </div>';
}
else{
	$output .='<center><h3>No records available</center><h3>';
}
echo $output;
?>