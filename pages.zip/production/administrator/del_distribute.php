<?php
/* Database connection start */
include("../../connection/config.php");
//delete data
	if($_POST["action"] == "Delete"){
		$data_id = $_POST['data_id'];
		$stmt = $mysqli->prepare("Delete from distribute where DistributeID=?");
		$stmt->bind_param("s",$data_id);
		if($stmt->execute()){
	
			echo "Record successfully deleted";
		}
		else{
			echo "Sorry! Record not deleted";
		}
	}
	?>