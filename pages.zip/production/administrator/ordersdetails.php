<?php
include "../../connection/config.php";
?>
<table class="table table-striped table-hover" id="order_table-grid">
    <thead>
    <tr>
    <th>No.</th>
    <th>Product</th>
    <th>Quantity</th>
    <th>Price</th>
    <th>Total</th>
    <th>Discount</th>
    <th>Sub Total</th>
    </tr>
    </thead>
    <tbody>
    <?php
    if(isset($_POST['get_select_invoice'])){
        $invoiceno = $_POST['inoicid'];
        $total = 0;
        $sub_total = 0;
        $gtotal = 0;
    $no = 1;
    $stmt = $mysqli->prepare("select * from invoice_details i,products p where i.Qty !='0' and i.ProductID=p.ProductID and i.InvoiceNo=?");
    $stmt->bind_param("s",$invoiceno);
    $stmt->execute();
    $rest = $stmt->get_result();
    while($rows = $rest->fetch_assoc()){
        $total = $rows['Price'] * $rows['Qty'];
        $discount = $rows['Discount'];

        $sub_total = $total - $discount;
        $gtotal = $gtotal + $sub_total;
    ?>
    <tr>
    <td><?php echo $no;?></td>
    <td><?php echo $rows['Product']?></td>
    <td><?php echo $rows['Qty']?></td>
    <td><?php echo "&cent;".$rows['Price']?></td>
    <td><?php echo "&cent;".$total;?></td>
    <td><?php echo $rows['Discount']?></td>
    <td><?php echo "&cent;".$sub_total;?></td>
    </tr>
<?php
$no++;
}
}
?>
<tr>
<td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td><label for="label" style="font-size: 20px;font-weight: bold">Net Total : </label></td>
    <td><label for="label" class="label label-success" style="font-size: 20px">&cent;<?php echo $gtotal; ?></label></td>
    </tr>
</tbody>
</table>
