<?php
include("../../connection/config.php");
if(isset($_POST['btnupdate'])){

$brandsid=$_POST['brandsid'];
$brands = $_POST['brands'];

$stmt = $mysqli->prepare("select * from brand");
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;

 //loop
 for($i=0;$i<$count;$i++){
$stmt = $mysqli->prepare("update brand set Brand=? where BrandID=?");
$stmt->bind_param("ss",$brands[$i],$brandsid[$i]);
$query = $stmt->execute();
 }
if($query){
echo "updated";
}
else{
echo "not updated";
}
}