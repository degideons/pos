<?php
include '../../connection/config.php';
session_start();
error_reporting(0);
$userid = $_SESSION['userid'];

function uuid(){
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); 
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); 
        return vsprintf('%s%s%s', str_split(bin2hex($data), 4));
}

$ordersid = uuid();
$pid =      $_POST["pid"];
$quantity = $_POST["quantity"];
$price =    $_POST["price"];
$tquantity = $_POST['tquantity'];

$orderdate = mysqli_real_escape_string($mysqli,$_POST['orderdate']);
$customer = mysqli_real_escape_string($mysqli,$_POST['customer']);
$subtotal = mysqli_real_escape_string($mysqli,$_POST['subtotal']);
$discount = mysqli_real_escape_string($mysqli,$_POST['discount']);
$nettotal = mysqli_real_escape_string($mysqli,$_POST['nettotal']);
$paid =     mysqli_real_escape_string($mysqli,$_POST['paid']);
$due =      mysqli_real_escape_string($mysqli,$_POST['due']);
$paymentmethod = mysqli_real_escape_string($mysqli,$_POST['paymentmethod']);

for($i=0;$i<count($pid);$i++)
{
	$totquantity = $tquantity[$i] - $quantity[$i];
	if($totquantity < 0){
		echo "check";
	}
	else{
		$stmt = $mysqli->prepare("update products set Quantity=? where ProductID =?");
		$stmt->bind_param("ss",$totquantity,$pid[$i]);
		$res = $stmt->execute();
	}
	
$stmt = $mysqli->prepare("insert into invoice_details(InvoiceNo,ProductID,Qty,Price)values(?,?,?,?)");
$stmt->bind_param("ssss",$ordersid,$pid[$i],$quantity[$i],$price[$i]);
$res = $stmt->execute();
}
if($res){
	$stmt = $mysqli->prepare("insert into invoice(InvoiceNo,CustomerName,SubTotal,Discount,NetTotal,Paid,Due,PaymentType,InvoiceDate,UserID)values(?,?,?,?,?,?,?,?,?,?)");
$stmt->bind_param("ssssssssss",$ordersid,$customer,$subtotal,$discount,$nettotal,$paid,$due,$paymentmethod,$orderdate,$userid);
$res = $stmt->execute();
if($res){
	echo $ordersid;
}
else{
	echo "error";
}
}
else{
	echo "error";
}
?>