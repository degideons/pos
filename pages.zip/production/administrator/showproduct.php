<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
 <?php
include("../../connection/config.php");


    if(isset($_POST["product_number"])){
    $product_number = $_POST["product_number"];
    
    $sql = "SELECT * from products p,mainprodcat m,brand b where p.MainProdcatID=m.MainProdcatID and p.BrandID=b.BrandID and p.ProductID = '$product_number' order by ProductDate desc";
    $res = mysqli_query($mysqli,$sql) or die('Error, query failed');
      
    if($res->num_rows > 0)
    {
    $row = $res->fetch_assoc();
    ?>


    <div class="form-group">
      <label for="label"> Category</label>
       <select class="prodcate form-control" style="width:100%" name="prodcate" id="prodcate" required="required">
        <option value="<?php echo $row['MainProdcatID']?>"><?php echo $row['MainprodCat']?></option>
       </select>
   </div>

    <div class="form-group">
      <label for="label"> Brand</label>
       <select class="brand form-control" style="width:100%" name="brand" id="brand" required="required">
        <option value="<?php echo $row['BrandID']?>"><?php echo $row['Brand']?></option>
       </select>
   </div>

    <div class="form-group">
      <label for="label"> Product</label>
   <input type="text" class="form-control" name="product" id="product" value="<?php echo $row['Product']?>" required="required"placeholder="Product" autocomplete="off">
   </div>

    <div class="form-group">
      <label for="label"> Unit Price</label>
       <input type="number" class="form-control" name="unitprice" id="unitprice" value="<?php echo $row['UnitPrice']?>" step="any" required="required"placeholder="Unit Price" autocomplete="off">
   </div>

    <div class="form-group">
      <label for="label"> Whole Sale Price</label>
       <input type="number" class="form-control" name="sellingprice" id="sellingprice" value="<?php echo $row['SellingPrice']?>" step="any" required="required"placeholder="Selling Price" autocomplete="off">
   </div>
   
   <div class="form-group">
      <label for="label"> Retail Price</label>
       <input type="number" class="form-control" name="retailprice" id="retailprice" value="<?php echo $row['RetailPrice']?>" step="any" required="required"placeholder="Selling Price" autocomplete="off">
   </div>

<?php 
   }
else{
  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Holy guacamole!</strong> Sorry! No record(s) available.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
 }
}
?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
<script type="text/javascript">
 $('.prodcate').select2({
        placeholder: 'Select product category',
        ajax: {
          url: '../../production/administrator/prodcate.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
$('.brand').select2({
        placeholder: 'Select brand',
        ajax: {
          url: '../../production/administrator/brand.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
       
</script>