<?php
include("../../connection/config.php");
session_start();
$shopid = $_SESSION["shopid"];
error_reporting(0);

if(isset($_POST["txtfrom"]) && isset($_POST["txtto"])){
$txtfrom = $_POST["txtfrom"];
$txtto = $_POST["txtto"];
$date = date("Y-m-d");
$output = '';
$totalpaid = 0;
$totaldue = 0;
$grandtotal = 0;
$status = 'Transacted';

$stmt = $mysqli->prepare("select SUM(i.Paid) as paid,SUM(i.Due) as due, s.Shop from invoice i,shop s where i.ShopID=s.ShopID and i.InvoiceDate BETWEEN ? and ? and i.NetTotal !='0' and i.Status=? GROUP BY s.Shop order by s.Shop ASC");
$stmt->bind_param("sss",$txtfrom,$txtto,$status);
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;

if($count > 0){
	$no = 1;
	$output .= '<div id="printpage">
          <center>
           <div>
           <h2>FRONT VIEW ENTERPRISE</h2>
           <h3>Papafio Lane Okaishie, Bicycle Lane, Accra</h3>
           <h4>Tel: +233248464247</h4>
           <h4>SALES REPORT BETWEEN '.$txtfrom.' AND '.$txtto.' </h4>
          </div><hr>
</center>
  <div class="table-responsive" >
	       <table id="daily_sales_table" class="table table-striped" style="width:100%">
	        <thead>
		   <tr>
		   <th>No</th>
           <th>Shop</th>
           <th>Cash at hand</th>
           <th>Due</th>
		   </tr>
		   </thead>
		   <tbody>';
		   while($row = $results->fetch_assoc()){
		   	$totalpaid = $totalpaid + $row["paid"];
		   	$totaldue = $totaldue + $row["due"];
$output .='<tr>
           <td>'.$no.'</td>
           <td>'.$row["Shop"].'</td>
           <td>'.$row["paid"].'</td>
           <td>'.$row["due"].'</td>
           </tr>';
           $no++;
		   }
		   $grandtotal = $totalpaid + $totaldue;
 
 $output .='<tr>
            <td colspan="3" align="right"><strong>Total Amount Paid :</strong>
            </td><td><strong>&cent;'.$totalpaid.'</strong></td>
            </tr>
            <tr>
            <td colspan="3" align="right"><strong>Total Due :</strong></td>
            <td><strong>&cent;'.$totaldue.'</strong></d>
           </tr>
           <tr>
           <td colspan="3" align="right"><strong>Grand Total :</strong></td>
           <td><strong>&cent;'.$grandtotal.'</strong></td>
           </tr>
           </tbody>
           </table>
	      </div></div>
        <div class="button-group">
  <button type="button" class="btn btn-warning pull-right" onclick="refreshPage()">Refresh Page</button>
  <button type="button" class="btn btn-primary pull-right" onclick="printDiv()">Print</button></div>
  </div>';
}
else{
	$output .='<center><h3>No records available</center><h3>';
}
echo $output;
}
?>