<?php
include "../fpdf/fpdf.php";
session_start();

if($_GET['orderdate'] && $_GET['invoiceno']){
     $pdf = new FPDF();
     $pdf->AddPage();

     $pdf->setFont("Arial","B",16);
     $pdf->Cell(190,10,"Point Of Sales",0,1,"C");
     $pdf->setFont("Arial",null,12);
  
     $pdf->Cell(50,10,"Invoice Number",0,0);
     $pdf->Cell(50,10,":  ". $_GET['invoiceno'] ,0,1);
     $pdf->Cell(50,10,"Date",0,0);
     $pdf->Cell(50,10,":  ". $_GET['orderdate'] ,0,1);
     $pdf->Cell(50,10,"Vendor's Name",0,0);
     $pdf->Cell(50,10,":  ". $_GET['vendorname'] ,0,1);

     $pdf->Cell(50,10,"" ,0,1);
     
     $pdf->Cell(10,10,"#",1,0,"C");
     $pdf->Cell(70,10,"Product Name",1,0,"C");
     $pdf->Cell(30,10,"Quantity",1,0,"C");
     $pdf->Cell(40,10,"Price (GHC)",1,0,"C");
     $pdf->Cell(40,10,"Total (GHC)",1,1,"C");

     for($i=0; $i < count($_GET["pid"]); $i++){
          $pdf->Cell(10,10, ($i+1),1,0,"C");
          $pdf->Cell(70,10, $_GET['prodname'][$i],1,0,"C");
          $pdf->Cell(30,10, $_GET['quantity'][$i],1,0,"C");
          $pdf->Cell(40,10, $_GET['price'][$i],1,0,"C");
          $pdf->Cell(40,10, $_GET['quantity'][$i] * $_GET['price'][$i],1,1,"C");
     }

     $pdf->Cell(50,10,"" ,0,1);

     $pdf->Cell(50,10,"Sub Total" ,0,0);
     $pdf->Cell(50,10,":  GHC ". $_GET['subtotal'] ,0,1);
     $pdf->Cell(50,10,"Discount" ,0,0);
     $pdf->Cell(50,10,":  ". $_GET['discount']."%" ,0,1);
     $pdf->Cell(50,10,"Net Total" ,0,0);
     $pdf->Cell(50,10,":  GHC ". $_GET['nettotal'] ,0,1);
     $pdf->Cell(50,10,"Paid" ,0,0);
     $pdf->Cell(50,10,":  GHC ". $_GET['paid'] ,0,1);
     $pdf->Cell(50,10,"Due" ,0,0);
     $pdf->Cell(50,10,":  GHC ". $_GET['due'] ,0,1);
     $pdf->Cell(50,10,"Payment Method" ,0,0);
     $pdf->Cell(50,10,":  ". $_GET['paymentmethod'] ,0,1);

     //$pdf->Cell(180,10,"Signature" ,0,1,"R");

     $pdf->Output("../pdf_invoice/pdf_invoice". $_GET["invoiceno"].".pdf","F");

     $pdf->Output();
}
?>