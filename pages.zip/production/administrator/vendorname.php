<?php
include("../../connection/config.php");


	$sql = "SELECT distinct * from vendors  where VendorName like '%". $_GET['q'] ."%' limit 10";
	$result = $mysqli->query($sql);
	$json = [];
	
	while($row = $result->fetch_assoc())
	{
		$json[] = ['id'=>$row['VendorName'], 'text'=>$row['VendorName']];
	}
   echo json_encode($json);
	?>