<?php
include "../fpdf/fpdf.php";
session_start();

if($_GET['distdate']){
     $pdf = new FPDF();
     $pdf->AddPage();

     $pdf->setFont("Arial","B",20);
     $pdf->Cell(190,10,"FRONT VIEW ENTERPRISE",0,1,"C");
     $pdf->Cell(190,10,"Papafio Lane Okaishie, Bicycle Lane, Accra",0,1,"C");
     $pdf->setFont("Arial",null,18);
     $pdf->Cell(190,10,"Tel: +233248464247",0,1,"C");
     $pdf->setFont("Arial",null,18);
     $pdf->Cell(190,10,"PRODUCT TRANSFER",0,1,"C");
     $pdf->setFont("Arial",null,18);


     $pdf->Cell(50,10,"Date",0,0);
     $pdf->Cell(50,10,":  ". $_GET['distdate'] ,0,1);
     $pdf->Cell(50,10,"From",0,0);
     $pdf->Cell(50,10,":  ". $_GET['fromshopname'] ,0,1);
     $pdf->Cell(50,10,"To",0,0);
     $pdf->Cell(50,10,":  ". $_GET['toshopname'] ,0,1);
  
     //$pdf->Cell(50,10,"Invoice Number",0,0);
     //$pdf->Cell(50,10,":  ". $_GET['invoiceno'] ,0,1);
     //$pdf->Cell(50,10,"Date",0,0);
     //$pdf->Cell(50,10,":  ". $_GET['distdate'] ,0,1);

     $pdf->Cell(50,10,"" ,0,1);
     
     $pdf->Cell(10,10,"#",1,0,"C");
     $pdf->Cell(70,10,"Product Name",1,0,"C");
     $pdf->Cell(30,10,"Cartons",1,0,"C");
     $pdf->Cell(40,10,"Total Quantity",1,1,"C");


     for($i=0; $i < count($_GET["pid"]); $i++){
     	$pdf->Cell(10,10, ($i+1),1,0,"C");
     	$pdf->Cell(70,10, $_GET['prodname'][$i],1,0,"C");
     	$pdf->Cell(30,10, $_GET['quantity'][$i],1,0,"C");
     	$pdf->Cell(40,10, $_GET['cartonquantity'][$i],1,1,"C");
     }

     $pdf->Cell(50,10,"" ,0,1);

  

     //$pdf->Cell(180,10,"Signature" ,0,1,"R");

    // $pdf->Output("../pdf_invoice/pdf_invoice". $_GET["invoiceno"].".pdf","F");

     $pdf->Output();
}
?>