<?php
include '../../connection/config.php';
//session_start();
//$shopid = $_POST["fromshopid"];

if(isset($_POST['priceqty'])){
	$id = $_POST['id'];
	$shop = $_POST['shop'];

	$sql = $mysqli->query("select * from products where ProductID ='$id'");
	$sql = $mysqli->query("select * from distribute where ShopID ='$shop' and ProductID ='$id'");
	$row = $sql->fetch_assoc();
	echo json_encode($row);

}
?>