<?php
include"../../connection/config.php";
if(isset($_POST["datefrom"]) && isset($_POST["dateto"])){
          $datefrom = $_POST['datefrom'];
          $dateto = $_POST['dateto'];

                    //income
$res = $mysqli->query("select sum(Paid) as paid from invoice where InvoiceDate between '$datefrom' and '$dateto'");
$row = $res->fetch_assoc();
$income = $row['paid'];

//on credit
$res = $mysqli->query("select sum(Due) as due from invoice where InvoiceDate between '$datefrom' and '$dateto'");
$myrow = $res->fetch_assoc();
$due = $myrow['due'];

//expenses
$result = $mysqli->query("select ExpensesType,sum(ExpAmount) as expensesA from expenses where ExpDate between '$datefrom' and '$dateto' group by ExpensesType");
  ?>
<table class="table">
          <tr>
            <td align="center">
              <h3 style="font-family: Times New Roman">FRONT VIEW ENTERPRISE</h3>
              <h4>Papafio Lane Okaishie, Bicycle Lane, Accra.</h4>
              <h4>Tel: +233248464247</h4>
              <h4>NET INCOME AS AT <?php echo date("Y-m-d")?></h4>
            </td>
          </tr>
        </table>

        <table class="table">
            <tr>
              <td><h5>Cash at hand</h5></td> <td> :</td><td><h5> &cent;<?php echo $income?></h5></td>
            </tr>
            <tr>
              <td><h5>Goods sold on credit</h5></td> <td> :</td><td><h5> &cent;<?php echo $due?></h5></td>
            </tr>
            <tr>
              <td><h5 style="font-weight:bold">Total</h5></td> <td> :</td><td></td><td><h5
              style="font-weight:bold"> &cent;<?php echo $due + $income;?></h5></td>
            </tr>
        </table>
        <br/>

         <table class="table table-striped">
          <tr>
            <td colspan="4"><h5 style="font-weight: bold">Expenses</h5></td>
          </tr>
          <?php
          $totalexp = 0;
           while($rows = $result->fetch_assoc()){
            $totalexp = $totalexp + $rows['expensesA'];
           ?>
            <tr>
              <td><h5><?php echo $rows['ExpensesType']?></h5></td> 
              <td> :</td>
              <td><h5> &cent;<?php echo $rows['expensesA']?></h5></td>
            </tr>
            <?php
          }
            ?>
            <tr>
              <td><h5 style="font-weight: bold">Total Expenses</h5></td> <td> :</td><td></td>
              <td><h5 style="font-weight: bold">( &cent;<?php echo $totalexp ?> )</h5></td>
              </tr>
              <tr>
              <td><h5 style="font-weight: bold">Net Income</h5></td> <td>:</td><td></td>
              <td><h5 style="font-weight: bold;border-bottom:double 4px">&cent;<?php echo ($due + $income)- $totalexp ?></h5></td>
            </tr>
        </table>
        <?php
      }
        ?>