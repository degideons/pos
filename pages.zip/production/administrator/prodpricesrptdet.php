<?php
include("../../connection/config.php");
session_start();
$shopid = $_SESSION["shopid"];
error_reporting(0);

$output = '';


$stmt = $mysqli->prepare("select * from products");
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;

if($count > 0){
	$no = 1;
	$output .= '
  <div id="printpage">
<center>
<div class="heading">
<h2>FRONT VIEW ENTERPRISE</h2>
<h3>Papafio Lane Okaishie, Bicycle Lane, Accra</h3>
<h4>Tel: +233248464247</h4>
<h4>PRODUCT PRICES </h4>
</div><hr>
</center><div class="table-responsive" >
	       <table id="daily_sales_table" class="table table-striped" style="width:100%">
	        <thead>
		   <tr>
		   <th>No</th>
           <th>Product</th>
           <th>Wholesale Price </th>
           <th>Retail Price </th>
		   </tr>
		   </thead>
		   <tbody>';
		   while($row = $results->fetch_assoc()){

$output .='<tr>
           <td>'.$no.'</td>
           <td>'.$row["Product"].'</td>
           <td>&cent;'.$row["SellingPrice"].'</td>
           <td>&cent;'.$row["RetailPrice"].'</td>
           </tr>';
           $no++;
		   }
 
 $output .='
           </tbody>
           </table>
	      </div></div>
        <div class="button-group">
  <button type="button" class="btn btn-warning pull-right" onclick="refreshPage()">Refresh Page</button>
  <button type="button" class="btn btn-primary pull-right" onclick="printDiv()">Print</button></div>
  </div>';
}
else{
	$output .='<center><h3>No records available</center><h3>';
}
echo $output;
?>