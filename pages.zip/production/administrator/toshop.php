<?php
include("../../connection/config.php");

            
	$sql = "SELECT distinct * from shop where Shop like '%". $_GET['q'] ."%' order by ShopID asc limit 10";
	$result = $mysqli->query($sql);
	$json = [];
	
	while($row = $result->fetch_assoc())
	{
		$json[] = ['id'=>$row['Shop'], 'text'=>$row['Shop']];
	}
   echo json_encode($json);
			?>