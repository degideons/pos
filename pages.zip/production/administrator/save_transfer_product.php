<?php
include "../../connection/config.php";
session_start();
$userid = $_SESSION["userid"];

$shopid = mysqli_real_escape_string($mysqli,$_POST['shopid']);
$shopname = mysqli_real_escape_string($mysqli,$_POST['shopname']);
$productid = mysqli_real_escape_string($mysqli,$_POST['productid']);
$qty = mysqli_real_escape_string($mysqli,$_POST['qty']);
$transfer_quantity = mysqli_real_escape_string($mysqli,$_POST['transfer_quantity']);
$remaining = mysqli_real_escape_string($mysqli,$_POST['remaining']);
$status = "Transferred";

$transfer_to = mysqli_real_escape_string($mysqli,$_POST['transfer_to']);
$current_stock = mysqli_real_escape_string($mysqli,$_POST['current_stock']);
$add_quantity = mysqli_real_escape_string($mysqli,$_POST['add_quantity']);
$totalqty = mysqli_real_escape_string($mysqli,$_POST['totalqty']);

$date = date("Y-m-d");
$time = date("H:i:s");

////if product and shop  exists
$stmt = $mysqli->prepare("select * from distribute where ShopID = ? and ProductID = ?");
$stmt->bind_param("ss",$transfer_to,$productid);
$stmt->execute();
$results = $stmt->get_result();
if($results->num_rows > 0){
    //add to shop
    $stmt = $mysqli->prepare("update distribute set Quantity = ?,UserID = ? where ShopID =? and ProductID = ?");
    $stmt->bind_param("ssss",$totalqty,$userid,$transfer_to,$productid);
    if($stmt->execute()){

        //deduct from shop
          $stmt = $mysqli->prepare("update distribute set Quantity = ?,UserID = ? where ShopID =? and ProductID = ?");
          $stmt->bind_param("ssss",$remaining,$userid,$shopid,$productid);
         if($stmt->execute()){

             //add to transfer
          $stmt = $mysqli->prepare("insert into transferprod(ShopID,ProductID,Quantity,UserID,FromShop,ProdStatus)values(?,?,?,?,?,?)");
          $stmt->bind_param("ssssss",$transfer_to,$productid,$transfer_quantity,$userid,$shopname,$status);
         if($stmt->execute()){

        //add to shop history
          $stmt = $mysqli->prepare("insert into shop_products_history(ShopID,ProductID,PreviousQty,AddQty,TotalQty,hStatus,hDate,hTime,UserID)values(?,?,?,?,?,?,?,?,?)");
          $stmt->bind_param("sssssssss",$transfer_to,$productid,$current_stock,$add_quantity,$totalqty,$status,$date,$time,$userid);
         if($stmt->execute()){

       //add to shop transfer history
          $stmt = $mysqli->prepare("insert into transfer_product_history(FromShop,ShopID,ProductID,PrevQty,TransQty,RemainingQty,TransDate,TransTime,UserID)values(?,?,?,?,?,?,?,?,?)");
          $stmt->bind_param("sssssssss",$shopname,$transfer_to,$productid,$qty,$transfer_quantity,$remaining,$date,$time,$userid);
         if($stmt->execute()){
        echo "Product(s) successfully transferred!";
    }
    else{
        echo "Sorry! Product(s) not transferred";
    }
    }
    else{
        echo "Sorry! Product(s) not transferred";
    }
    }
    else{
        echo "Sorry! Product(s) not transferred";
    }
         }
         else{
        echo "Sorry! Product(s) not transferred";
    }
    }
    else{
        echo "Sorry! Product(s) not transferred";
    }
    }

//if product and shop do not exist
    else{
         //add to shop
    $stmt = $mysqli->prepare("insert into distribute(ShopID,ProductID,Quantity,UserID)values(?,?,?,?)");
    $stmt->bind_param("ssss",$transfer_to,$productid,$totalqty,$userid);
    if($stmt->execute()){

        //deduct from shop
          $stmt = $mysqli->prepare("update distribute set Quantity = ?,UserID = ? where ShopID =? and ProductID = ?");
          $stmt->bind_param("ssss",$remaining,$userid,$shopid,$productid);
         if($stmt->execute()){

             //add to transfer
          $stmt = $mysqli->prepare("insert into transferprod(ShopID,ProductID,Quantity,UserID,FromShop,ProdStatus)values(?,?,?,?,?,?)");
          $stmt->bind_param("ssssss",$transfer_to,$productid,$transfer_quantity,$userid,$shopname,$status);
         if($stmt->execute()){

        //add to shop history
          $stmt = $mysqli->prepare("insert into shop_products_history(ShopID,ProductID,PreviousQty,AddQty,TotalQty,hStatus,hDate,hTime,UserID)values(?,?,?,?,?,?,?,?,?)");
          $stmt->bind_param("sssssssss",$transfer_to,$productid,$current_stock,$add_quantity,$totalqty,$status,$date,$time,$userid);
         if($stmt->execute()){

       //add to shop transfer history
          $stmt = $mysqli->prepare("insert into transfer_product_history(FromShop,ShopID,ProductID,PrevQty,TransQty,RemainingQty,TransDate,TransTime,UserID)values(?,?,?,?,?,?,?,?,?)");
          $stmt->bind_param("sssssssss",$shopname,$transfer_to,$productid,$qty,$transfer_quantity,$remaining,$date,$time,$userid);
         if($stmt->execute()){
        echo "Product(s) successfully transferred!";
    }
    else{
        echo "Sorry! Product(s) not transferred";
    }
    }
    else{
        echo "Sorry! Product(s) not transferred";
    }
    }
    else{
        echo "Sorry! Product(s) not transferred";
    }
         }
         else{
      echo "Sorry! Product(s) not transferred";
    }
    }
    }
?>