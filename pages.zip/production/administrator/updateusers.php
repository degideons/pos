<?php
include("../../connection/config.php");
if(isset($_POST['btn_update'])){

$userid  =     $mysqli->real_escape_string($_POST["userid"]);
$fullname  =     $mysqli->real_escape_string($_POST["fullname"]);
$phone     =     $mysqli->real_escape_string($_POST["phone"]);
$email     =     $mysqli->real_escape_string($_POST["email"]);
$usertype  =     $mysqli->real_escape_string($_POST["usertype"]);
$shop  =         $mysqli->real_escape_string($_POST["shop"]);
$othshop  =      $mysqli->real_escape_string($_POST["othshop"]);
$username  =     $mysqli->real_escape_string($_POST["username"]);
$status    =     $mysqli->real_escape_string($_POST["status"]);


$stmt = $mysqli->prepare("update users set FullName = ?,PhoneNo = ?,Email = ?,UserType = ?,ShopID = ?,OthShop = ?,Username = ?,Status = ? where UserID=?");
$stmt->bind_param("sssssssss",$fullname,$phone,$email,$usertype,$shop,$othshop,$username,$status,$userid);
$query = $stmt->execute();

if($query){
echo "updated";
}
else{
echo "not updated";
}
}