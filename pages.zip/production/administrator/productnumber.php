<?php
include("../../connection/config.php");


	$sql = "SELECT distinct ProductID,Product from products order by Product ASC";
	$result = $mysqli->query($sql);
	$json = [];
	
	while($row = $result->fetch_assoc())
	{
		$json[] = ['id'=>$row['ProductID'], 'text'=>$row['Product']];
	}
   echo json_encode($json);
	?>