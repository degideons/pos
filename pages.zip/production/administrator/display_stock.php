<?php
include("../../connection/config.php");
if(isset($_GET['shid'])){
	$shopid = $_GET['shid'];
$output = '';

$output .='<div class="table-responsive" >
	       <table id="shop_table-grid" class="display" style="width:100%">
		   <thead>
		   <tr>
		   <th>No</th>
           <th>Product</th>
           <th>Quantity</th>
           <th>Created by</th>
           <th>Date</th>
           <th>Action</th>
		   </tr>
		   </thead>
		   <tbody>';
    $stmt = $mysqli->prepare("select * from distribute d, products p, users u where d.ProductID=p.ProductID and d.UserID=u.UserID and d.ShopID=?");
    $stmt->bind_param("s",$shopid);
    $stmt->execute();
    $results = $stmt->get_result();
    while($row = $results->fetch_assoc()){
  $output.='<tr>
           <td>'.$row['Product'].'</td>
           <td>'.$row['Quantity'].'</td>
           <td>'.$row['FullName'].'</td>
           <td>'.$row['DistributeDate'].'</td>
           <td><a href="increase_stock.php?sid='.$shopid.'&& rid='.$row['ProductID'].'" class="btn btn-info" data-toggle="Tooltip" Title="Increase Stock"><span class=" glyphicon glyphicon-plus-sign"></span></a>
	           <a href="reduce_stock.php?sid='.$shopid.'&& rid='.$row['ProductID'].'&& dit='.$row["DistributeDate"].'" class="btn btn-warning" data-toggle="Tooltip" Title="Reduce Stock"><span class=" glyphicon glyphicon-minus-sign"></span></a>
	<a href="transfer_product.php?sid='.$shopid.'&& rid='.$row['ProductID'].'" class="btn btn-primary" data-toggle="Tooltip" Title="Transfer Product">Transfer</a>
	<button type="button" class="btn btn-danger delete" data-toggle="tooltip" title="Delete" id="'.$row['DistributeID'].'"><span class="fa fa-trash"></span></button></td>
		   </tr>';
		   }
  $output .='</tbody>
		   </table>
		  </div>';

}
?>