<?php
include("../../connection/config.php");
error_reporting(0);
session_start();

if(isset($_POST['btnupdate'])){

$datepicker =     $mysqli->real_escape_string($_POST["datepicker"]);  
$shop  =          $mysqli->real_escape_string($_POST["shop"]);
$products  =      $mysqli->real_escape_string($_POST["products"]);
$grand_total     =   $mysqli->real_escape_string($_POST["grand_total"]);
$total_quantity     =   $mysqli->real_escape_string($_POST["total_quantity"]);

if(empty($total_quantity) || empty($total_quantity)){
  echo "<script>alert('All fields are required!')</script>";
}else{


$alert = "";

 $stmt = $mysqli->prepare("update distribute set Quantity = ? where ShopID=? and ProductID=?");
        $stmt->bind_param("sss",$grand_total,$shop,$products);
       if($stmt->execute()){
        $stmt = $mysqli->prepare("update transferprod set Quantity = ? where DistributeDate=? and ShopID=? and ProductID=?");
        $stmt->bind_param("ssss",$total_quantity,$datepicker,$shop,$products);
       if($stmt->execute()){

       $alert = '<div class="alert alert-success" role="alert"> Records successfully updated!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  </div>';
       }
       else
         {
          $alert = '<div class="alert alert-danger" role="alert">Sorry, records not updated!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  </div>';
 }
     }
      else
         {
          $alert = '<div class="alert alert-danger" role="alert">Sorry, records not updated!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  </div>';
 }
 }
}
?>