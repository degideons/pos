<?php
include("../../connection/config.php");

            
	$sql = "SELECT * from mainprodcat where MainprodCat like '%". $_GET['q'] ."%' order by MainprodCat asc limit 10";
	$result = $mysqli->query($sql);
	$json = [];
	
	while($row = $result->fetch_assoc())
	{
		$json[] = ['id'=>$row['MainProdcatID'], 'text'=>$row['MainprodCat']];
	}
     echo json_encode($json);
?>