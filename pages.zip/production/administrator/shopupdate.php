<?php
include("../../connection/config.php");
error_reporting(0);
session_start();

if(isset($_POST['btnsave'])){
  
$shop  =          $mysqli->real_escape_string($_POST["shop"]);
$shopname  =      $mysqli->real_escape_string($_POST["shopname"]);
$shoptype     =   $mysqli->real_escape_string($_POST["shoptype"]);
$userid = $_SESSION["userid"];

$alert = "";

 $stmt = $mysqli->prepare("update shop set Shop=?,ShopType=? where ShopID=?");
        $stmt->bind_param("sss",$shopname,$shoptype,$shop);
       if($stmt->execute()){
       $alert = '<div class="alert alert-success" role="alert"> Records successfully updated!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  </div>';
       }
      else
         {
          $alert = '<div class="alert alert-danger" role="alert">Sorry, records not updated!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  </div>';
 }
}
?>