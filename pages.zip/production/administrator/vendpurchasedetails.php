<?php
include "../../connection/config.php";
?>
<table class="table table-striped table-hover" id="order_table-grid">
    <thead>
    <tr>
    <th>No.</th>
    <th>Product</th>
    <th>Quantity</th>
    <th>Price</th>
    <th>Total</th>
    </tr>
    </thead>
    <tbody>
    <?php
    if(isset($_POST['get_select_invoice'])){
    	$invoiceno = $_POST['inoicid'];
    	$total = 0;
    	$gtotal = 0;
    $no = 1;
    $stmt = $mysqli->prepare("select * from purchases_details i,products p where i.ProductID=p.ProductID and i.InvoiceNumber=?");
    $stmt->bind_param("s",$invoiceno);
    $stmt->execute();
    $rest = $stmt->get_result();
    while($rows = $rest->fetch_assoc()){
    	$total = $rows['Price'] * $rows['pQuantity'];
    	$gtotal = $gtotal + $total;
    ?>
    <tr>
    <td><?php echo $no;?></td>
    <td><?php echo $rows['Product']?></td>
    <td><?php echo $rows['pQuantity']?></td>
    <td><?php echo $rows['Price']?></td>
    <td><?php echo $total;?></td>
    </tr>
<?php
$no++;
}
}
?>
<tr>
	<td></td>
    <td></td>
    <td></td>
    <td><label for="label" style="font-size: 20px;font-weight: bold">Total</label></td>
    <td><label for="label" class="label label-success" style="font-size: 20px">&cent;<?php echo $gtotal; ?></label></td>
    </tr>
</tbody>
</table>
