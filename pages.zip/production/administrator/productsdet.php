<?php
/* Database connection start */
include("../../connection/config.php");
/* Database connection end */


// storing  request (ie, get/post) global array to a variable  
$requestData= $_REQUEST;


$columns = array( 
// datatable column index  => database column name
	0 =>'MainprodCat', 
	1 =>'Brand', 
	2 => 'Product',
	3 => 'UnitPrice',
	4 => 'SellingPrice',
	5 => 'RetailPrice',
    6 => 'ProductDate',
	7 => 'FullName',
);

// getting total number records without any search
$sql = "SELECT * ";
$sql.=" FROM products p, mainprodcat m, brand b, users u where p.MainProdcatID=m.MainProdcatID and p.BrandID=b.BrandID and p.UserID=u.UserID";
$query=mysqli_query($mysqli, $sql) or die("productsdet.php: get products");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


$sql = "SELECT * ";
$sql.=" FROM products p, mainprodcat m, brand b, users u where p.MainProdcatID=m.MainProdcatID and p.BrandID=b.BrandID and p.UserID=u.UserID";
if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
	$sql.=" AND (Product LIKE '".$requestData['search']['value']."%' ";    
	$sql.=" OR MainprodCat LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR Brand LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR FullName LIKE '".$requestData['search']['value']."%' )";
}
$query=mysqli_query($mysqli, $sql) or die("productsdet.php: get products");
$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
/* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
$query=mysqli_query($mysqli, $sql) or die("productsdet.php: get products");
$x=1;
$data = array();
while( $row=mysqli_fetch_array($query) ) {  // preparing an array

       
	$nestedData=array(); 

	$nestedData[] = $x;
	$nestedData[] = $row["MainprodCat"];
	$nestedData[] = $row["Brand"];
	$nestedData[] = $row["Product"];
	$nestedData[] = $row["UnitPrice"];
	$nestedData[] = $row["SellingPrice"];
	$nestedData[] = $row["RetailPrice"];
	$nestedData[] = $row["ProductDate"];
	$nestedData[] = $row["FullName"];
	$nestedData[] = '<button type="button" class="btn btn-danger delete" data-toggle="tooltip" title="Delete" id="'.$row['ProductID'].'"><span class="fa fa-trash"></span></button>';

	$x++;
	$data[] = $nestedData;
}



$json_data = array(
			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format

?>
