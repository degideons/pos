<?php
include"../../connection/config.php";
session_start();

if(isset($_POST['btnsave'])){

	$vendorname =   $mysqli->real_escape_string($_POST['vendorname']);
	$phone =        $mysqli->real_escape_string($_POST['phone']);
	$email =        $mysqli->real_escape_string($_POST['email']);
	$address =      $mysqli->real_escape_string($_POST['address']);
	$location =     $mysqli->real_escape_string($_POST['location']);
	$userid = $_SESSION['userid'];
	$status = "Active";

	$stmt = $mysqli->prepare("select VendorName from vendors where VendorName = ?");
    $stmt->bind_param("s",$vendorname);
    $stmt->execute();
    $results = $stmt->get_result();

    if($results->num_rows != 1){
     $stmt = $mysqli->prepare("insert into vendors(VendorName,Phone,vEmail,Address,Location,vStatus,UserID)values(?,?,?,?,?,?,?)");
     $stmt->bind_param("sssssss",$vendorname,$phone,$email,$address,$location,$status,$userid);
     if($stmt->execute()){
     	echo "success";
     }
     else{
     	echo "error";
     }
    }
    else{
    	echo "1";
    }
}
?>