<?php
include '../../connection/config.php';


if(isset($_POST['priceqty'])){
	$id = $_POST['id'];

	$sql = $mysqli->query("select * from distribute d, products p where d.ProductID = p.ProductID and d.ProductID ='$id'");
	$row = $sql->fetch_assoc();
	echo json_encode($row);
}
?>