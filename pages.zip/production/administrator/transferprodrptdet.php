<?php
include("../../connection/config.php");
session_start();
$shopid = $_SESSION["shopid"];
error_reporting(0);

if(isset($_POST["txtdate"])){
$txtdate = $_POST["txtdate"];

$output = '';
$totalquantity = 0;


$stmt = $mysqli->prepare("SELECT * FROM transferprod t,products p,shop s WHERE t.ProductID=p.ProductID and t.ShopID=s.ShopID and YEAR(t.DistributeDate)=YEAR(?) and MONTH(t.DistributeDate)=MONTH(?) and DAY(t.DistributeDate)=DAY(?) and ProdStatus='Transferred' ORDER BY Shop ASC");
$stmt->bind_param("sss",$txtdate,$txtdate,$txtdate);
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;

if($count > 0){
	$no = 1;
	$output .= '<div id="printpage">
          <center>
           <div>
           <h2>FRONT VIEW ENTERPRISE</h2>
           <h3>Papafio Lane Okaishie, Bicycle Lane, Accra</h3>
           <h4>Tel: +233248464247</h4>
           <h4>TRANSFERRED PRODUCTS REPORT AS AT '.$txtdate.'</h4>
          </div><hr>
</center>
  <div class="table-responsive" >
	       <table id="daily_sales_table" class="table table-striped" style="width:100%">
	        <thead>
		   <tr>
		       <th>No</th>
           <th>From</th>
           <th>To</th>
           <th>Product</th>
           <th>Quantity</th>
		   </tr>
		   </thead>
		   <tbody>';
		   while($row = $results->fetch_assoc()){
		   	$totalquantity = $totalquantity + $row["Quantity"];
$output .='<tr>
           <td>'.$no.'</td>
           <td>'.$row["FromShop"].'</td>
           <td>'.$row["Shop"].'</td>
           <td>'.$row["Product"].'</td>
           <td>'.$row["Quantity"].'</td>
           </tr>';
           $no++;
		   }
 
 $output .='<tr>
            <td colspan="4" align="right"><strong>Total Products Transferred :</strong>
            </td><td><strong>'.$totalquantity.'</strong></td>
            </tr>
           </tbody>
           </table>
	      </div></div>
        <div class="button-group">
  <button type="button" class="btn btn-warning pull-right" onclick="refreshPage()">Refresh Page</button>
  <button type="button" class="btn btn-primary pull-right" onclick="printDiv()">Print</button></div>
  </div>';
}
else{
	$output .='<center><h3>No records available</center><h3>';
}
echo $output;
}
?>