<?php
include("../../connection/config.php");
session_start();
error_reporting(0);

if(isset($_POST['btnupdate'])){

$expensesid=$_POST['expensesid'];
$expensesamount=$_POST['expensesamount'];
$expensestype=$_POST['expensestype'];
$expensesdetails=$_POST['expensesdetails'];

$userid=$_SESSION['userid'];

$stmt = $mysqli->prepare("select * from expenses");
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;

 //loop
 for($i=0;$i<$count;$i++){
$stmt = $mysqli->prepare("update  expenses set ExpAmount=?,ExpensesType=?,ExpDetails=?,UserID=? where ExpensesID=?");
$stmt->bind_param("sssss",$expensesamount[$i],$expensestype[$i],$expensesdetails[$i],$userid,$expensesid[$i]);
$query = $stmt->execute();
 }
if($query){
echo "updated";
}
else{
echo "not updated";
}
}