<?php
include "../../connection/config.php";
session_start();
$userid = $_SESSION["userid"];

$shopid = mysqli_real_escape_string($mysqli,$_POST['shopid']);
$productid = mysqli_real_escape_string($mysqli,$_POST['productid']);
$current_stock = mysqli_real_escape_string($mysqli,$_POST['current_stock']);
$add_quantity = mysqli_real_escape_string($mysqli,$_POST['add_quantity']);
$totalqty = mysqli_real_escape_string($mysqli,$_POST['totalqty']);

$status = "Distributed";
$add_status = "Added";

$date = date("Y-m-d");
$time = date("H:i:s");



        //add products to shop
          $stmt = $mysqli->prepare("update distribute set Quantity = ?,UserID = ? where ShopID =? and ProductID = ?");
          $stmt->bind_param("ssss",$totalqty,$userid,$shopid,$productid);
         if($stmt->execute()){

             //add to transfer
          $stmt = $mysqli->prepare("insert into transferprod(ShopID,ProductID,Quantity,UserID,ProdStatus)values(?,?,?,?,?)");
          $stmt->bind_param("sssss",$shopid,$productid,$add_quantity,$userid,$status);
         if($stmt->execute()){

        //add to shop history
          $stmt = $mysqli->prepare("insert into shop_products_history(ShopID,ProductID,PreviousQty,AddQty,TotalQty,hStatus,hDate,hTime,UserID)values(?,?,?,?,?,?,?,?,?)");
          $stmt->bind_param("sssssssss",$shopid,$productid,$current_stock,$add_quantity,$totalqty,$add_status,$date,$time,$userid);
         if($stmt->execute()){

     echo "Product(s) successfully added!";
    }
    else{
        echo "Sorry! Product(s) not Added";
    }
    }
    else{
        echo "Sorry! Product(s) not Added";
    }
         }
         else{
      echo "Sorry! Product(s) not Added";
    }

    
?>