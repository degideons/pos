<?php
include '../../connection/config.php';
session_start();
//error_reporting(0);

$shop =    $_POST["shop"];
$product =      $_POST["product"];
$quantity = $_POST['quantity'];
$userid = $_SESSION['userid'];
$prodstatus = 'Distributed';

$stmt = $mysqli->prepare("select * from distribute where ShopID=? and ProductID=?");
$stmt->bind_param("ss",$shop,$product);
$stmt->execute();
$results = $stmt->get_result();

if($results->num_rows > 0){
	$stmt = $mysqli->prepare("update distribute set Quantity = Quantity + ?, UserID = ? where ShopID = ? and ProductID = ?");
	$stmt->bind_param("ssss",$quantity,$userid,$shop,$product);
   if($stmt->execute()){
   	   $stmt = $mysqli->prepare("insert into transferprod(ShopID,ProductID,Quantity,UserID,ProdStatus)values(?,?,?,?,?)");
       $stmt->bind_param("sssss",$shop,$product,$quantity,$userid,$prodstatus);
       $res = $stmt->execute();
       if($res){
	echo "Record(s) successfully saved!";
}
else{
	echo "Sorry! Record(s) not saved!";
}
   }
}
else{
	$stmt = $mysqli->prepare("insert into distribute(ShopID,ProductID,Quantity,UserID)values(?,?,?,?)");
$stmt->bind_param("ssss",$shop,$product,$quantity,$userid);
$res = $stmt->execute();

$stmt = $mysqli->prepare("insert into transferprod(ShopID,ProductID,Quantity,UserID,ProdStatus)values(?,?,?,?,?)");
$stmt->bind_param("sssss",$shop,$product,$quantity,$userid,$prodstatus);
$res = $stmt->execute();


if($res){
	echo "Record(s) successfully saved!";
}
else{
	echo "Sorry! Record(s) not saved!";
}
}

?>