<?php
/* Database connection start */
include("../../connection/config.php");

if(isset($_POST['productid']) && isset($_POST['transfer_to'])){
	$transfer_to = $_POST['transfer_to'];
	$productid = $_POST['productid'];

	$stmt = $mysqli->prepare("select * from distribute where ProductID=? and ShopID = ?");
	$stmt->bind_param("ss",$productid,$transfer_to);
	$stmt->execute();
    $rest = $stmt->get_result();
    $row = $rest->fetch_assoc();
}
?>
 <div class="form-group">
        <label>Current Stock</label>
        <input type="text" class="add_quantity form-control" id="current_stock" name="current_stock" value="<?php echo $row['Quantity']?>"required="required" readonly="readonly">
        </div>

        <div class="form-group">
        <label>Add Quantity</label>
        <input type="text" class="add_quantity form-control" id="add_quantity" name="add_quantity" required="required" vreadonly="readonly">
        </div>

        <div class="form-group">
        <label>Total Quantity</label>
        <input type="text" class="form-control" id="totalqty" name="totalqty" required="required" readonly="readonly">
        </div>


<div class="button-group">
  <button type="button" id="btn_return-product" class="btn_return-product btn btn-primary pull-right">Transfer</button></div>
  </div>

<script type="text/javascript">
       $(document).on("change keyup blur", "#add_quantity", function() {
  var add_quantity = $('#add_quantity').val();
  var current_stock = $('#current_stock').val();

   if(add_quantity <= 0){
    location.reload();
   }
  // else{
  //var compadd_quantity = new Number(add_quantity);
  //var compcurrent_stock = new Number(current_stock);
  //if(compadd_quantity > compcurrent_stock){
    //alert('Please, Transfer quantity cannot be greater than Current Stock');
  //  location.reload();
 // }
  else{
      var sum = 0;
      $(".add_quantity").each(function(){
      	sum += Number($(this).val());
      });
      $("#totalqty").val(sum);
  }
 // }

});

        </script>