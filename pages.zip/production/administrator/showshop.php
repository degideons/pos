<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
 <?php
include("../../connection/config.php");


    if(isset($_POST["shop_number"])){
    $shop_number = $_POST["shop_number"];
    
    $sql = "SELECT * from shop where ShopID = '$shop_number' order by ShopDate desc";
    $res = mysqli_query($mysqli,$sql) or die('Error, query failed');
      
    if($res->num_rows > 0)
    {
    $row = $res->fetch_assoc();
    ?>

 <div class="form-group">
  <label for="label"> Change Shop</label>
            <input type="text" name="shopname" class="form-control" id="shopname" value="<?php echo $row['Shop']?>" placeholder="Shop" required="required">   
        </div>

     <div class="form-group">
      <label for="label"> Change Shop Type</label>
       <select class="shoptype form-control" style="width:100%" name="shoptype" id="shoptype" value="" required="required">
        <option value="<?php echo $row['ShopType']?>"><?php echo $row['ShopType']?></option>
        <option value="Retail">Retail</option>
        <option value="wholesale">Wholesale</option>
    </select>
   </div>

<?php 
   }
else{
  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong></strong> Sorry! No record(s) available.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
 }
}
?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
<script type="text/javascript">
  $('.shoptype').select2({
        placeholder: 'Select Shop Type',
      });
       
</script>