<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
 <?php
include("../../connection/config.php");


    if(isset($_POST["datepicker"]) && isset($_POST["shop_number"]) && isset($_POST["product_number"])){
      $datepicker = $_POST["datepicker"];
      $shop_number = $_POST["shop_number"];
      $product_number = $_POST["product_number"];
    
    $sql = "SELECT t.Quantity as tquantity,d.Quantity as dquantity FROM products p, transferprod t,distribute d WHERE p.ProductID=t.ProductID and p.ProductID=d.ProductID  and t.ShopID=d.ShopID and t.ShopID='$shop_number' and t.DistributeDate='$datepicker' and t.ProductID='$product_number' ORDER BY t.TransferID DESC";
    $res = mysqli_query($mysqli,$sql) or die('Error, query failed');
      
    if($res->num_rows > 0)
    {
    $row = $res->fetch_assoc();
    ?>

    <div class="form-group">
      <label for="label"> Current Stock</label>
   <input type="number" class="quantity form-control" name="total_stock" id="total_stock" step="any" value="<?php echo $row['dquantity']?>" required="required" placeholder="Total Stock" readonly="readonly">
   </div>

   <div class="form-group">
      <label for="label"> Current Quantity Added</label>
   <input type="number" class="prodqty form-control" name="total_added" id="total_added" step="any" value="<?php echo $row['tquantity']?>" required="required" placeholder="Current Quantity Added" readonly="readonly">
   </div>

    <div class="form-group">
      <label for="label"> Select Status</label>
       <select class="status form-control" name="status" id="status" step="any" required="required">
       <option value="Add">Add Quantity</option>
       <option value="Deduct">Deduct Quantity</option>
       </select>
   </div>

    <div class="form-group">
      <label for="label"> Input Quantity</label>
       <input type="number" class="quantity form-control prodqty" name="quantity" id="quantity" step="any" required="required" placeholder="Input Quantity" autocomplete="off">
   </div>

   <div class="form-group">
      <label for="label"> Total Quantity Added</label>
   <input type="number" class="total_quantity form-control" name="total_quantity" id="total_quantity"  step="any" required="required" placeholder="Total Quantity Added" autocomplete="off" readonly="readonly">
   </div>
   
   <div class="form-group">
      <label for="label"> Total Stock</label>
       <input type="number" class="grand_total form-control" name="grand_total" id="grand_total"  step="any" required="required" placeholder="Grand Total" autocomplete="off" readonly="readonly">
   </div>


<?php 
   }
else{
  echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Holy guacamole!</strong> Sorry! No record(s) available.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
 }
}
?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
<script type="text/javascript">
 $('.status').select2({
        placeholder: 'Select product Status',
       
      });
</script>