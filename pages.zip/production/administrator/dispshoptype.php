<?php
include '../../connection/config.php';
session_start();
error_reporting(0);

if(isset($_POST["shop"])){
$shop = $_POST["shop"];
$stmt = $mysqli->prepare("select * from shop where ShopID=?");
$stmt->bind_param("s",$shop);
$stmt->execute();
$results = $stmt->get_result();
$row = $results->fetch_assoc();
echo '<div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label"> Shop Type</label>
      <div class="col-sm-6">
        <input type="text" name="shoptype" id="shoptype" class="form-control form-control-sm" value="'.$row["ShopType"].'" required="required" readonly="readonly">
      </div>
    </div>';
}
?>