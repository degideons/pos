<?php
include("../../connection/config.php");
error_reporting(0);
session_start();

if(isset($_POST['btnsave'])){
$productid =    $mysqli->real_escape_string($_POST["productid"]); 
$prodcate =    $mysqli->real_escape_string($_POST["prodcate"]);
$brand =       $mysqli->real_escape_string($_POST["brand"]);
$product =       $mysqli->real_escape_string($_POST["product"]);
$unitprice =       $mysqli->real_escape_string($_POST["unitprice"]);
$sellingprice =       $mysqli->real_escape_string($_POST["sellingprice"]);
$retailprice =       $mysqli->real_escape_string($_POST["retailprice"]);
$userid = $_SESSION['userid'];

$alert = "";

 $stmt = $mysqli->prepare("update products set MainProdcatID=?,BrandID=?, Product=?,UnitPrice=?,SellingPrice=?,RetailPrice=?,UserID=? where ProductID=?");
        $stmt->bind_param("ssssssss",$prodcate,$brand,$product,$unitprice,$sellingprice,$retailprice,$userid,$productid);
       if($stmt->execute()){
       $alert = '<div class="alert alert-success" role="alert"> Records successfully updated!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  </div>';
       }
      else
         {
          $alert = '<div class="alert alert-danger" role="alert">Sorry, records not updated!<button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  </div>';
 }
}
?>