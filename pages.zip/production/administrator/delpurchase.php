<?php
/* Database connection start */
include("../../connection/config.php");
//delete data
	if($_POST["action"] == "Delete"){
		$purch_id = $_POST['purch_id'];
		$stmt = $mysqli->prepare("Delete from purchases where InvoiceNumber=?");
		$stmt->bind_param("s",$purch_id);
		if($stmt->execute()){
		$stmt = $mysqli->prepare("Delete from purchases_details where InvoiceNumber=?");
		    $stmt->bind_param("s",$purch_id);
		if($stmt->execute()){
			echo "Record successfully deleted";
		  }
		  else{
			echo "Sorry! Record not deleted";
		}
		}
		else{
			echo "Sorry! Record not deleted";
		}
	}
	?>