<?php
include("../../connection/config.php");
session_start();
$userid = $_SESSION['userid'];

if(isset($_POST['btnsave'])){
	

$expamount =    $mysqli->real_escape_string($_POST["expamount"]);
$exptype  =     $mysqli->real_escape_string($_POST["exptype"]);
$expdetails  =  $mysqli->real_escape_string($_POST["expdetails"]);
$date = date("Y-m-d");

$stmt = $mysqli->prepare("insert into expenses(ExpAmount,ExpensesType,ExpDetails,ExpDate,UserID)values(?,?,?,?,?)");
$stmt->bind_param("sssss",$expamount,$exptype,$expdetails,$date,$userid);

if($stmt->execute()){
	echo "success";
   }
else
   {
	echo "error";
    }
  }
?>