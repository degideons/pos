<?php
include("../../connection/config.php");

if(isset($_POST['btnsave'])){
	
	
	function uuid(){
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); 
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); 
        return vsprintf('%s%s%s', str_split(bin2hex($data), 4));
}

$prodcatid = uuid();
$prodcat  =  $mysqli->real_escape_string($_POST["prodcat"]);

$stmt = $mysqli->prepare("select * from mainprodcat where MainprodCat=?");
$stmt->bind_param("s",$prodcat);
$stmt->execute();
$results= $stmt->get_result();
$count=$results->num_rows;
if($count == 0){

$stmt = $mysqli->prepare("insert into mainprodcat(MainProdcatID,MainprodCat)values(?,?)");
$stmt->bind_param("ss",$prodcatid,$prodcat);

if($stmt->execute()){
	echo "success";
   }
else
   {
	echo "error";
    }
  }
else
  {
	echo "1";
   }
}
?>