<?php
include '../../connection/config.php';
session_start();
error_reporting(0);

//if(isset($_POST["btn-submit"])){

$shopid = $_SESSION["shopid"];

$shop =    $_POST["shop"];
$pid =      $_POST["pid"];
//$price = $_POST["price"];
$quantity = $_POST['quantity'];
$userid = $_SESSION['userid'];
$prodstatus = 'Distributed';
//$totquantity = 0;

for($i=0;$i<count($pid);$i++)
{

$stmt = $mysqli->prepare("insert into distribute(ShopID,ProductID,Quantity,UserID)values(?,?,?,?)");
$stmt->bind_param("ssss",$shop,$pid[$i],$quantity[$i],$userid);
$res = $stmt->execute();

$stmt = $mysqli->prepare("insert into transferprod(ShopID,ProductID,Quantity,UserID,ProdStatus)values(?,?,?,?,?)");
$stmt->bind_param("sssss",$shop,$pid[$i],$quantity[$i],$userid,$prodstatus);
$res = $stmt->execute();
}

if($res){
	echo "ok";
}
else{
	echo "error";
}
//}
//}
?>