<?php
include("../../connection/config.php");
if(isset($_POST['btnupdate'])){

$prodcatsid=$_POST['prodcatsid'];
$prodcats = $_POST['prodcats'];

$stmt = $mysqli->prepare("select * from mainprodcat");
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;

 //loop
 for($i=0;$i<$count;$i++){
$stmt = $mysqli->prepare("update mainprodcat set MainprodCat=? where MainProdcatID=?");
$stmt->bind_param("ss",$prodcats[$i],$prodcatsid[$i]);
$query = $stmt->execute();
 }
if($query){
echo "updated";
}
else{
echo "not updated";
}
}