<?php
/* Database connection start */
include("../../connection/config.php");
/* Database connection end */


// storing  request (ie, get/post) global array to a variable  
$requestData= $_REQUEST;


$columns = array( 
// datatable column index  => database column name
	0 =>'ExpAmount', 
	1 =>'ExpensesType', 
	2 =>'ExpDetails', 
	3 => 'ExpDate',
	4 => 'FullName',
);

// getting total number records without any search
$sql = "SELECT * ";
$sql.=" FROM expenses e, users u where e.UserID=u.UserID";
$query=mysqli_query($mysqli, $sql) or die("expensesdet.php: get Expenses");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


$sql = "SELECT * ";
$sql.=" FROM expenses e,users u where e.UserID=u.UserID and 1=1";
if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
	$sql.=" AND ( ExpAmount LIKE '".$requestData['search']['value']."%' ";    
	$sql.=" OR ExpensesType LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR ExpDetails LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR ExpDate LIKE '".$requestData['search']['value']."%' )";
}
$query=mysqli_query($mysqli, $sql) or die("expensesdet.php: get Expenses");
$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
/* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
$query=mysqli_query($mysqli, $sql) or die("expensesdet.php: get Expenses");
$x=1;
$data = array();
while( $row=mysqli_fetch_array($query) ) {  // preparing an array
$modal='<a  class="btn btn-warning btn-sm" data-toggle="modal" data-target="#admodal'.$row['ExpensesID'] .'" data-toggle="tooltip" data-placement="left" title="Edit Expenses"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span></a>
        <div class="modal fade" id="admodal'. $row['ExpensesID'] .'" aria-labelledby="admodallabel'. $row['ExpensesID'] .'" role="dialog" aria-hidden="true" tabindex="-1">
	<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
	<button type="button" class="close" onClick="refreshPage()" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"></span></button>
	<h3 class="modal-title" id="admodallabel'. $row['ExpensesID'] .'"> Edit Expenses</h3>
	</div>
	<div class="modal-body">
	
	
	     <input type="hidden" class="form-control" name="expensesid[]" id="expensesid'. $row['ExpensesID'] .'" value="'.$row['ExpensesID'] .'" required="required" placeholder="Expenses ID" readonly />
	
	 
	 <div class="form-group">
       <input type="number" class="form-control" step="any" id="expensesamount'.$row['ExpensesID'].'" style="width:100%" name="expensesamount[]" value="'.$row['ExpAmount'].'" required="required"placeholder="Amount" autocomplete="off">
   </div>

   <div class="form-group">
       <select class="exptype form-control" style="width:100%" name="expensestype[]" id="expensestype'.$row['ExpensesID'].'" required="required">
        <option value="'.$row['ExpensesType'].'">'.$row['ExpensesType'].'</option>
        <option value="Electricity Bill">Electricity Bill</option>
        <option value="Wages and Salary">Wages and Salary</option>
        <option value="Transportation">Transportation</option>
        <option value="Clothing">Clothing</option>
        <option value="Cost of goods and services">Cost of goods and services</option>
        <option value="Advertisement">Advertisement</option>
        <option value="Tax">Tax</option>
        <option value="Rent">Rent</option>
        <option value="Telephone">Telephone</option>
        <option value="Bad Debt">Bad Debt</option>
        <option value="Amortization">Amortization</option>
        <option value="Depreciation">Depreciation</option>
        <option value="Insurance">Insurance</option>
        <option value="Miscellaneous">Miscellaneous</option>
        <option value="Entertainment">Entertainment</option>
        <option value="Utility">Utility</option>
       </select>
   </div>

    <div class="form-group">
       <input type="text" class="form-control" style="width:100%" name="expensesdetails[]" id="expensesdetails'.$row['ExpensesID'].'" required="required"placeholder="Expenses Details" value="'.$row['ExpDetails'].'" autocomplete="off">
   </div>
	  
	</div>
	<div class="modal-footer">
	<button type="button"  class="btn btn-success" onClick="refreshPage()" data-dismiss="modal"><span class="glyphicon glyphicon-arrow-left"></span> Back</button>
	<button type="submit" class="btn btn-primary" name="btnupdate" id="btn_update"><span class="glyphicon glyphicon-save"></span> Save changes</button>
	</div>  
	</div>
	</div>
	</div>
		
	<script>
	function refreshPage() {
    location.reload();
     $(".exptype").select2({
    placeholder: "Select Expenses Type",
  });
}</script>';
       
	$nestedData=array(); 

	$nestedData[] = $x;
	$nestedData[] = $row["ExpAmount"];
	$nestedData[] = $row["ExpensesType"];
	$nestedData[] = $row["ExpDetails"];
	$nestedData[] = $row["ExpDate"];
	$nestedData[] = $row["FullName"];
	$nestedData[] = $modal;

	$x++;
	$data[] = $nestedData;
}



$json_data = array(
			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format

?>
