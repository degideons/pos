<?php
include "../../connection/config.php";
session_start();
$userid = $_SESSION["userid"];

$stock_date = mysqli_real_escape_string($mysqli,$_POST['stock_date']);
$shopid = mysqli_real_escape_string($mysqli,$_POST['shopid']);
$productid = mysqli_real_escape_string($mysqli,$_POST['productid']);
$current_stock = mysqli_real_escape_string($mysqli,$_POST['current_stock']);
$reduce_quantity = mysqli_real_escape_string($mysqli,$_POST['reduce_quantity']);
$totalqty = mysqli_real_escape_string($mysqli,$_POST['totalqty']);

$status = "Distributed";
$add_status = "Deducted";

$date = date("Y-m-d");
$time = date("H:i:s");



        //add products to shop
          $stmt = $mysqli->prepare("update distribute set Quantity = ?,UserID = ? where ShopID =? and ProductID = ?");
          $stmt->bind_param("ssss",$totalqty,$userid,$shopid,$productid);
         if($stmt->execute()){

             //add to transfer
          $stmt = $mysqli->prepare("update transferprod set Quantity =?, UserID=? where ShopID=? and ProductID=? and DistributeDate=?");
          $stmt->bind_param("sssss",$reduce_quantity,$userid,$shopid,$productid,$stock_date);
         if($stmt->execute()){

        //add to shop history
          $stmt = $mysqli->prepare("insert into shop_products_history(ShopID,ProductID,PreviousQty,AddQty,TotalQty,hStatus,hDate,hTime,UserID)values(?,?,?,?,?,?,?,?,?)");
          $stmt->bind_param("sssssssss",$shopid,$productid,$current_stock,$reduce_quantity,$totalqty,$add_status,$date,$time,$userid);
         if($stmt->execute()){

     echo "Product(s) successfully added!";
    }
    else{
        echo "Sorry! Product(s) not Added";
    }
    }
    else{
        echo "Sorry! Product(s) not Added";
    }
         }
         else{
      echo "Sorry! Product(s) not Added";
    }

    
?>