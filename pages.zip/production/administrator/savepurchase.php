<?php
include '../../connection/config.php';
session_start();
error_reporting(0);
$userid = $_SESSION['userid'];

$pid =      $_POST["pid"];
$quantity = $_POST["quantity"];
$price =    $_POST["price"];
$tquantity = $_POST['tquantity'];

$invoiceno = $_POST['invoiceno'];
$orderdate = mysqli_real_escape_string($mysqli,$_POST['orderdate']);
$vendorname = mysqli_real_escape_string($mysqli,$_POST['vendorname']);
$subtotal = mysqli_real_escape_string($mysqli,$_POST['subtotal']);
$discount = mysqli_real_escape_string($mysqli,$_POST['discount']);
$nettotal = mysqli_real_escape_string($mysqli,$_POST['nettotal']);
$paid =     mysqli_real_escape_string($mysqli,$_POST['paid']);
$due =      mysqli_real_escape_string($mysqli,$_POST['due']);
$paymentmethod = mysqli_real_escape_string($mysqli,$_POST['paymentmethod']);

for($i=0;$i<count($pid);$i++)
{
$stmt = $mysqli->prepare("insert into purchases_details(InvoiceNumber,ProductID,pQuantity,Price)values(?,?,?,?)");
$stmt->bind_param("ssss",$invoiceno,$pid[$i],$quantity[$i],$price[$i]);
$res = $stmt->execute();
}
if($res){
	$stmt = $mysqli->prepare("insert into purchases(InvoiceNumber,VendorName,SubTotal,Discount,NetTotal,Paid,Due,PaymentType,PurchaseDate,UserID)values(?,?,?,?,?,?,?,?,?,?)");
$stmt->bind_param("ssssssssss",$invoiceno,$vendorname,$subtotal,$discount,$nettotal,$paid,$due,$paymentmethod,$orderdate,$userid);
$res = $stmt->execute();
if($res){
	echo $invoiceno;
}
else{
	echo "error";
}
}
else{
	echo "error";
}
?>