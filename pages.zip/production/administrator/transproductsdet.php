<?php
/* Database connection start */
include("../../connection/config.php");
/* Database connection end */
session_start();
error_reporting(0);
$shopt = $_SESSION['shopd'];
//$supshop = $_SESSION["shopid"];
//$shopid = "5bfc7c897738e";

// storing  request (ie, get/post) global array to a variable  
$requestData= $_REQUEST;


$columns = array( 
// datatable column index  => database column name
	0 => 'Product',
	1 => 'PrevQty',
	2 => 'TransQty',
	3 => 'RemainingQty',
	4 => 'FullName',
	5 => 'Shop',
	6 => 'TransDate',
	7 => 'TransTime',
	9 => '',
	

);

// getting total number records without any search
$sql = "SELECT * ";
$sql.=" FROM transfer_product_history d,products p, users u, shop s where d.ProductID=p.ProductID and d.UserID=u.UserID and d.ShopID=s.ShopID and d.FromShop ='$shopt'";
$query=mysqli_query($mysqli, $sql) or die("transproductsdet.php: get products");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


$sql = "SELECT * ";
$sql.=" FROM transfer_product_history d,products p, users u,shop s where d.ProductID=p.ProductID and d.UserID=u.UserID and d.ShopID=s.ShopID and d.FromShop='$shopt' and 1=1";
if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
	$sql.=" AND (Product LIKE '".$requestData['search']['value']."%' ";    
	$sql.=" OR TransQty LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR FullName LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR TransDate LIKE '".$requestData['search']['value']."%' )";
}
$query=mysqli_query($mysqli, $sql) or die("transproductsdet.php: get products");
$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
/* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
$query=mysqli_query($mysqli, $sql) or die("transproductsdet.php: get products");
$x=1;
$data = array();

while( $row=mysqli_fetch_array($query) ) {  // preparing an array
   
	$nestedData=array(); 

	$nestedData[] = $x;
	$nestedData[] = $row["Product"];
	$nestedData[] = $row["PrevQty"];
	$nestedData[] = $row["TransQty"];
	$nestedData[] = $row["RemainingQty"];
	$nestedData[] = $row["FullName"];
	$nestedData[] = $row["Shop"];
	$nestedData[] = $row["TransDate"];
	$nestedData[] = $row["TransTime"];


	$x++;
	$data[] = $nestedData;
}



$json_data = array(
			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format

?>
