<?php
include '../../connection/config.php';
session_start();
error_reporting(0);
$shopid = $_POST["fromshop"];


$fromshopname = $_POST['fromshopname'];
$shop =    $_POST["toshop"];
$pid =      $_POST["pid"];
$quantity = $_POST['quantity'];
$cartonquantity = $_POST['cartonquantity'];
$tquantity = $_POST['tquantity'];
$userid = $_SESSION['userid'];
$prodstatus = 'Transferred';
//$totquantity = 0;



for($i=0;$i<count($pid);$i++)
{
	
$stmt = $mysqli->prepare("SELECT * from distribute where ShopID=? and ProductID=?");
$stmt->bind_param("ss",$shop,$pid[$i]);
$stmt->execute();
$results = $stmt->get_result();
$count = $results->num_rows;
if($count > 0)
{
$totalquantity = $tquantity[$i] - $quantity[$i];
if($totalquantity < 0){
	echo "check";
}else{
	$row = $results->fetch_assoc();
//$totquantity = $cartonquantity[$i] + $row["Quantity"];
$stmt = $mysqli->prepare("UPDATE distribute set Quantity= Quantity + ?, UserID =? where ShopID=? and ProductID=?");
$stmt->bind_param("ssss",$cartonquantity[$i],$userid,$shop,$pid[$i]);
$res = $stmt->execute();


$stmt = $mysqli->prepare("UPDATE distribute set Quantity= Quantity - ? where ShopID=? and ProductID=?");
$stmt->bind_param("sss",$quantity[$i],$shopid,$pid[$i]);
$res = $stmt->execute();

$stmt = $mysqli->prepare("INSERT into transferprod(ShopID,ProductID,Quantity,UserID,FromShop,ProdStatus)values(?,?,?,?,?,?)");
$stmt->bind_param("ssssss",$shop,$pid[$i],$cartonquantity[$i],$userid,$fromshopname,$prodstatus);
$res = $stmt->execute();
}
}
else{
	$totalquantity = $tquantity[$i] - $quantity[$i];
	if($totalquantity < 0){
	echo "check";
}else{
$stmt = $mysqli->prepare("INSERT into distribute(ShopID,ProductID,Quantity,UserID)values(?,?,?,?)");
$stmt->bind_param("ssss",$shop,$pid[$i],$cartonquantity[$i],$userid);
$res = $stmt->execute();

$stmt = $mysqli->prepare("UPDATE distribute set Quantity - ? where ShopID=? and ProductID=?");
$stmt->bind_param("sss",$quantity[$i],$shopid,$pid[$i]);
$res = $stmt->execute();

$stmt = $mysqli->prepare("INSERT into transferprod(ShopID,ProductID,Quantity,UserID,FromShop,ProdStatus)values(?,?,?,?,?,?)");
$stmt->bind_param("ssssss",$shop,$pid[$i],$cartonquantity[$i],$userid,$fromshopname,$prodstatus);
$res = $stmt->execute();
}
}
}

if($res){
	echo "ok";
}
else{
	echo "error";
}
//}
?>