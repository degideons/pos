<?php
/* Database connection start */
include("../../connection/config.php");
/* Database connection end */
session_start();
$shopid = $_SESSION['ordshop'];

// storing  request (ie, get/post) global array to a variable  
$requestData= $_REQUEST;


$columns = array( 
// datatable column index  => database column name
	0 => 'InvoiceNo',
	1 => 'CustomerName',
	2 => 'CustPhone',
	3 => 'NetTotal',
    4 => 'Paid',
    5 => 'Due',
    6 => 'PaymentType',
    7 => 'InvoiceDate',

);

// getting total number records without any search
$sql = "SELECT * ";
$sql.=" FROM invoice where NetTotal !='0' and ShopID='$shopid' and Status='Transacted'";
$query=mysqli_query($mysqli, $sql) or die("productsdet.php: get products");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


$sql = "SELECT * ";
$sql.=" FROM invoice  where NetTotal !='0' and ShopID='$shopid' and Status='Transacted' and 1=1";
if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
	$sql.=" AND (InvoiceNo LIKE '".$requestData['search']['value']."%' ";    
	$sql.=" OR CustomerName LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR InvoiceDate LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR PaymentType LIKE '".$requestData['search']['value']."%' )";
}
$query=mysqli_query($mysqli, $sql) or die("productsdet.php: get products");
$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
/* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc  */	
$query=mysqli_query($mysqli, $sql) or die("productsdet.php: get products");
$x=1;
$data = array();

while( $row=mysqli_fetch_array($query) ) {  // preparing an array
$button = '<a  class="ordinvoice btn btn-danger btn-sm" data-toggle="modal" data-target="#admodal'.$row['InvoiceNo'] .'" data-toggle="tooltip" data-placement="left" title="View Details" prodid="'. $row['InvoiceNo'] .'"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
<div class="modal fade" id="admodal'. $row['InvoiceNo'] .'" aria-labelledby="admodallabel'. $row['InvoiceNo'] .'" role="dialog" aria-hidden="true" tabindex="-1">
	<div class="modal-dialog">
	<div class="modal-content">
	<div class="modal-header">
	<button type="button" class="close" onClick="refreshPage()" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only"></span></button>
	<h3 class="modal-title" id="admodallabel'. $row['InvoiceNo'] .'"> Orders Details</h3>
	</div>
	<div class="modal-body">

    <div id="showdetail'. $row['InvoiceNo'] .'">
    
    </div>
	 
	</div>
	<div class="modal-footer">
	

	</div>
	
	    
	</div>
	</div>
	</div>
	<script>
	$("document").ready(function(){
		 $("body").delegate(".ordinvoice","click",function(event){
      event.preventDefault();
      var nid = $(this).attr("prodid");
     $.ajax({
     	url:"../../production/sales/ordersdetails.php",
     	method:"POST",
     	data:{get_select_invoice:1,inoicid:nid},
     	success:function(data){
        $("#showdetail'. $row['InvoiceNo'] .'").html(data);
     	}
     	});
    });
    });
	function refreshPage() {
    location.reload();
}
	</script>';

       
	$nestedData=array(); 

	$nestedData[] = $x;
	$nestedData[] = $row["InvoiceNo"];
	$nestedData[] = $row["CustomerName"];
	$nestedData[] = $row["CustPhone"];
	$nestedData[] = $row["NetTotal"];
	$nestedData[] = $row["Paid"];
	$nestedData[] = $row["Due"];
	$nestedData[] = $row["PaymentType"];
	$nestedData[] = $row["InvoiceDate"];
	$nestedData[] = $button;


	$x++;
	$data[] = $nestedData;
}



$json_data = array(
			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format

?>
