
<?php include '../../headers/salesaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-file"> New Order</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">New Order</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="myform" onsubmit="return false">

           <div id="error"></div> 
           <div id="success"></div>    
<?php
include '../../connection/config.php';
session_start();
error_reporting(0);
$shopid = $_SESSION["shopid"];
$stmt = $mysqli->prepare("select * from shop where ShopID=?");
$stmt->bind_param("s",$shopid);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$shoptype = $row["ShopType"];
?>
<div class="row">
  <div class="col-md-12">
  <div class="orderlist">
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Shop Type</label>
      <div class="col-sm-6">
	  <input type="text" name="shoptype" id="shoptype" class="form-control form-control-sm" value="<?php echo $shoptype?>" required="required" readonly="readonly">
    </div>
	</div>
	<div class="form-group row">
	<input type="hidden" name="shoptype" id="shoptype" class="form-control form-control-sm" value="<?php echo $shoptype?>" required="required">
      <label for="label" align="right" class="col-sm-3 col-form-label">Order Date</label>
      <div class="col-sm-6"><input type="text" name="orderdate" id="orderdate" value="<?php echo date("Y-m-d")?>" class="form-control form-control-sm" required="required" readonly="readonly"></div>
    </div>
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Customer Name</label>
      <div class="col-sm-6"><input type="text" name="customer" class="form-control form-control-sm" required="required"></div>
    </div>
     <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Phone No.</label>
      <div class="col-sm-6"><input type="text" name="phone" id="phone" class="form-control form-control-sm"></div>
    </div>
    </div>

	<div class="table-responsive" >
	     <table id="order_table-grid" class="display" style="width:100%">
        <h2>Order List <button class="btn btn-success pull-right" id="add" data-toggle="tooltip" title="Add"><span class="glyphicon glyphicon-plus-sign"></span> Add</button></h2>
		   <thead>
		   <tr>
		   <th>#</th>
       <th style="text-align: center;">Price Type</th>
       <th style="text-align: center;">Item </th>
       <th style="text-align: center;color: red">In Stock</th>
       <th style="text-align: center;">Sell Qty</th>
       <th style="text-align: center;">Rem Qty</th>
       <th style="text-align: center;">Price (&cent;)</th>
       <th style="text-align: center;" nowrap="nowrap">Amnt </th>
       <th style="text-align: center;">Disc</th>
       <th style="text-align: center;" nowrap="nowrap">Sub Total</th>
       <th style="text-align: center;" nowrap="nowrap">Remove </th>
		   </tr>
		   </thead>
       <tbody id="showorderlist">

       </tbody>
		   </table>

       <center style="padding: 10px">
         
       </center>
		  </div>
      </div>
      </div>
<div class="row">
<div class="col-md-4"></div>
      <div class="col-md-4">
          
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-6 col-form-label">Net Total (&cent;)</label>
      <div class="col-sm-8">
        <input type="text" name="nettotal" id="nettotal" class="form-control form-control-sm" required="required" readonly="readonly">
      </div>
    </div>
     <div class="form-group row">
      <label for="label" align="right" class="col-sm-6 col-form-label">Paid (&cent;)</label>
      <div class="col-sm-8">
        <input type="text" name="paid" id="paid" class="form-control form-control-sm" required="required">
      </div>
    </div>
     <div class="form-group row">
      <label for="label" align="right" class="col-sm-6 col-form-label">Due (&cent;)</label>
      <div class="col-sm-8">
        <input type="text" name="due" id="due" class="form-control form-control-sm" required="required" readonly="readonly">
      </div>
    </div>
     <div class="form-group row">
      <label for="label" align="right" class="col-sm-8 col-form-label">Payment Method</label>
      <div class="col-sm-8">
        <select name="paymentmethod" id="paymentmethod" class="paymentmethod form-control form-control-sm" style="width: 100%" required="required">
          <option></option>
          <option value="Cash">Cash</option>
          <option value="Cheque">Cheque</option>
          <option value="Mobile Money">Mobile Money</option>
        </select>
      </div>
    </div>

    <div class="button-group" style="margin: auto;">
      
      <div class="col-sm-8">
      <button class="btn btn-primary" id="order_form" name="btnorder" style="width: 100%">Order</button><br><br>
      <button class="btn btn-success " id="refresh" name="btnrefresh" style="width: 100%" onclick="refreshPage()">Refresh Page</button>
      
   
    </div>

      </div>
     </div>
    </div>
  </form>
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/salesfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../script/sales/orderscript.js"></script>
<script src="../../bower_components/validator/dist/js/jquery.maskedinput.js"></script>

<script type="text/javascript">
$(document).ready(function(e){
        $("#order_form").click(function(e){
        e.preventDefault();

        var invoice = $("#myform").serialize();
          
          $.ajax({
          url:'../../production/sales/saveorders.php',
          type:'post',
          data:$("#myform").serialize(),
            success:function(data){
              if(data < 0){
                alert(data);
              }
              else if(data == "check"){
                alert("Sorry! This much quantity is not available");
              }
              else{
                $("order_form").trigger("reset");
                if(confirm("Do you want to print invoice?")){
                  window.location.href = "../../production/sales/printinvoice.php?invoiceno="+data+"&"+invoice;
                }
                else{
                  alert("Records successfully saved");
                }
              }
            }
          })
        })


  });
$(function() {
        $("#phone").mask("+233999999999");

        $("input").blur(function() {
            $("#info").html("Unmasked value: " + $(this).mask());
        }).dblclick(function() {
            $(this).unmask();
        });
    });
function refreshPage(){
  location.reload();
}
</script>