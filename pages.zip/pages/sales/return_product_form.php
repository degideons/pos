
<?php include '../../headers/salesaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
  <link rel="stylesheet" href="../../bower_components/jquery/dist/css/jquery.dataTables.min.css"> 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-file"> Return Products</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"> Manage Returns</li>
      </ol>
    </section>
  
  <!-- Main content -->
    <section class="content">
  
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="return_product-form">

           <div id="uperror"></div> 
           <div id="upsuccess"></div>
            
<?php
include "../../connection/config.php";
session_start();
$shopsid = $_SESSION['shopid'];

    if(isset($_GET['id'])){
      $invoice_id = $_GET['id'];
      $prod_id = $_GET['rid'];

    $stmt = $mysqli->prepare("select * from invoice_details i,products p where i.ProductID=p.ProductID and i.InvoiceNo=? and i.ProductID=?");
    $stmt->bind_param("ss",$invoice_id,$prod_id);
    $stmt->execute();
    $rest = $stmt->get_result();
    $row = $rest->fetch_assoc();
}
?>


  <div class="row">
       <div class="col-md-3"></div>
       <div class="col-md-6">
          <div class="form-group">
        <label>Invoice Number</label>
         <input type="hidden" class="form-control" id="shopid" name="shopid" value="<?php echo $shopsid?>" readonly="readonly">
         <input type="hidden" class="form-control" id="invoice_detid" name="invoice_detid" value="<?php echo $row['InvDetID']?>" readonly="readonly">
       
        <input type="text" class="form-control" id="invoice_no" name="invoice_no" value="<?php echo $row['InvoiceNo']?>" readonly="readonly">
        </div>

     <div class="form-group">
        <label>Product</label>
        <input type="hidden" class="form-control" id="productid" name="productid" value="<?php echo $row['ProductID']?>">
        <input type="text" class="form-control" id="product" name="product" value="<?php echo $row['Product']?>" readonly="readonly">
        </div>

         <div class="form-group">
        <label>Price</label>
        <input type="text" class="form-control" id="price" name="price" value="<?php echo $row['Price']?>" readonly="readonly">
        </div>

    <div class="form-group">
        <label>Quantity</label>
        <input type="text" class="form-control" id="qty" name="qty" value="<?php echo $row['Qty']?>" readonly="readonly">
        </div>

    <div class="form-group">
        <label>Return</label>
        <input type="text" class="form-control" id="returns" name="returns" required="required">
        </div>

<div class="form-group">
        <label>Remaining</label>
        <input type="text" class="form-control" id="remaining" name="remaining" required="required" readonly="readonly">
        </div>

        <div class="form-group">
        <label>Total</label>
        <input type="text" class="form-control" id="total" name="total" required="required" readonly="readonly">
        </div>

        <div class="form-group">
        <label>Discount</label>
        <input type="text" class="form-control" id="discount" name="discount" required="required" value="<?php echo $row['Discount']?>"readonly="readonly">
        </div>

        <div class="form-group">
        <label>Sub Total</label>
        <input type="text" class="form-control" id="subtotal" name="subtotal" required="required" readonly="readonly">
        </div>

<div class="button-group">
  <button type="button" id="btn_return-product" class="btn_return-product btn btn-primary pull-right">Return</button></div>
  </div>
       </div>
      
      </form>
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/salesfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script>    

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  
  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/sales/sales_products_script.js"></script>
<!--script type="text/javascript" src="../../script/administrator/updateprodcatescript.js"></script-->

<script type="text/javascript">
    $(document).on('click','.btn_return-product',function(){
      var data_id = $(this).attr("id");
      var action = "Cancel";
   if(confirm("Are you sure you want to return product?"))
   {
    $.ajax({
     url:"../../production/sales/return_product.php",
     method:"POST",
     data:$("#return_product-form").serialize(),
     success:function(data)
     {
      alert(data);
      //load_data();
      location.reload();
     }
    });
   }
   else
   {
    alert('Product(s) not returned!');
    return false;
   }
  })

$(document).on("change keyup blur", "#returns", function() {
  var returns = $('#returns').val();
  var qty = $('#qty').val();
  var price = $('#price').val();
  var discount = $('#discount').val();
   if(returns <= 0){
    //alert("Invalid Input");
    location.reload();
   }
   else{
  var compreturns = new Number(returns);
  var compqty = new Number(qty);
  if(compreturns > compqty){
    alert('Please, Return cannot be greater than Quantity');
    location.reload();
    
    $('#remaining').val(0);
    $('#returns').val(0);
  }
  else{
 var remaining = (qty - returns);
  $('#remaining').val(remaining);
  var total = (price * returns).toFixed(2);
  $('#total').val(total);
  var subtotal =(total-discount).toFixed(2);
  $('#subtotal').val(subtotal);
  }
  }
});
</script>