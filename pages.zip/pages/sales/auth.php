<?php session_start();
error_reporting(0);

if(!$_SESSION["fullname"]){
	header("Location: ../../index.php");
}
else{
	$fullname = $_SESSION['fullname'];
}
?>