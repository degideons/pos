
<?php include '../../headers/salesaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
  <link rel="stylesheet" href="../../bower_components/jquery/dist/css/jquery.dataTables.min.css"> 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-file"> Return Products Details</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"> Manage Returns</li>
      </ol>
    </section>
  
  <!-- Main content -->
    <section class="content">
  
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="update-form">

           <div id="uperror"></div> 
           <div id="upsuccess"></div>
            



  <div class="table-responsive" >
   <marquee behavior="alternate"> <label for="label" class="label label-danger" style="font-size: 100%">Amount Given 
   Out is based on (Price * Returned) - Discount</label></marquee><br/><br/>
         <table id="shop_table-grid" class="display" style="width:100%">
       <thead>
       <tr>
       <th>No</th>
       <th>Invoice No.</th>
       <th>Customer</th>
       <th>Products</th>
       <th>Price</th>
       <th>Bought</th>
       <th>Returned</th>
       <th>Total (&cent;)</th>
       <th>Discount</th>
       <th>Amount Given Out (&cent;)</th>
       <th>Returned Date</th>
       <th>Returned Time</th>
      
       </tr>
       </thead>
       </table>
      </div>
      </form>

  <form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="register-form">
      

  </form>
  
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/salesfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script>    

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  
  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/sales/return_prod_det_script.js"></script>
<!--script type="text/javascript" src="../../script/administrator/updateprodcatescript.js"></script-->

<script type="text/javascript">
  $(document).on('click','.cancel',function(){
      var data_id = $(this).attr("id");
      var action = "Cancel";
   if(confirm("Are you sure you want to cancel transaction?"))
   {
    $.ajax({
     url:"../../production/sales/cancel_transaction.php",
     method:"POST",
     data:{data_id:data_id, action:action},
     success:function(data)
     {
      alert(data);
      //load_data();
      location.reload();
     }
    });
   }
   else
   {
    alert('Transaction not cancelled');
    return false;
   }
  })

</script>