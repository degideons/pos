
<?php include '../../headers/salesaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-file"> New Order</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">New Order</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="myform" onsubmit="return false">

           <div id="error"></div> 
           <div id="success"></div>    
<?php
include '../../connection/config.php';
session_start();
error_reporting(0);
$userid = $_SESSION["userid"];
$stmt = $mysqli->prepare("select * from users u, shop s where u.ShopID = s.ShopID and u.UserID=?");
$stmt->bind_param("s",$userid);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$mainshopid = $row["ShopID"];
$shopname = $row["Shop"];

$stmt = $mysqli->prepare("select * from users u, shop p where u.OthShop = p.ShopID and u.UserID=?");
$stmt->bind_param("s",$userid);
$stmt->execute();
$res = $stmt->get_result();
$rows = $res->fetch_assoc();
$othershopid = $rows["OthShop"];
$othershopname = $rows["Shop"];
?>
<div class="row">
  <div class="col-md-3"></div>
  <div class="col-md-6">

    <marquee behavior="alternate" style="color:darkred;font-size: 20px">Please select Shop to sell</marquee>

<br/><br/><br/>

 <div class="button-group" style="margin: auto;">
<a href="neworder.php?id=<?php echo $mainshopid ?>" class="btn btn-success"style="margin: auto;font-size: 50px"><?php echo $shopname ?></a>

<br/><br/><br/>
<a href="neworder.php?id=<?php echo $othershopid ?>" class="btn btn-warning" style="margin: auto;font-size: 50px"><?php echo $othershopname?></a>

<br/><br/><br/>
</div>
	
      </div>
      </div>

  </form>
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/salesfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../script/sales/orderscript.js"></script>
<!--script type="text/javascript" src="../../script/administrator/updateprodcatescript.js"></script-->
<script src="../../bower_components/validator/dist/js/jquery.maskedinput.js"></script>

<script type="text/javascript">

</script>