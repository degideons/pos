
<?php include '../../headers/salesaside.php'?>
<link rel="stylesheet" href="../../bower_components/jquery/dist/css/jquery.dataTables.min.css"> 

<!--set time-->
<script type="text/javascript">
 
function timedMsg()
{
var t=setTimeout("document.getElementById('alert').style.display='none';",4000);
}
</script>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-money"> Debtors</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Manage Debtors</li>
      </ol>
    </section>
  
  <!-- Main content -->
    <section class="content">
  
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
<div class="signin-form">

   <button type="button" name="add" class="btn btn-success" data-toggle="collapse" data-target="#user_collapse"><span class="glyphicon glyphicon-plus-sign"></span> Pay Debt</button>  
                <br />  

      <div id="user_collapse" class="collapse">
      <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">
      <form method="post" id="pay_debt_form">

      <div id="error"></div>
      <div id="success"></div>
            
      <div class="form-group"> 
      <label>Enter Invoice Number</label>  
      <input type="text" name="invoicenumber" id="invoicenumber" class="form-control" placeholder="Invoice Number" required="required" /> 
      </div>
      <div id="showRec">
         
      </div>
 
      </form> 
      </div> 
      </div>  
      </div>  
      <br/><hr>

<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" id="register-form">
         <h3 class="form-signin-heading"></h3>
           <div class="table-responsive" >
         <table id="shop_table-grid" class="display" style="width:100%">
       <thead>
       <tr>
       <th>No</th>
       <th>Invoice No.</th>
       <th>Customers</th>
       <th>Telephone</th>
       <th>Net Total (&cent;)</th>
       <th>Paid (&cent;)</th>
       <th>Due (&cent;)</th>
       <th>Created At</th>
       <th>Action</th>
       </tr>
       </thead>
       </table>
      </div>
       
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/salesfooter.php'?>    
 
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script> 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  

<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/sales/debtorsdetscript.js"></script>


<script type="text/javascript">
  $('document').ready(function(){

$('#invoicenumber').keyup(function(){
    var debt_number = $(this).val();
    $.ajax({
      url:"../../production/sales/showdebtor.php",
      method:"POST",
      data:{debt_number:debt_number},
      success:function(data){
        $('#showRec').html(data);
      }
    });
   });

 $("#pay_debt_form").validate({
       
        submitHandler: submitForm
    });
    /* validation */

    /* form submit */
    function submitForm()
    {
        var data = $("#pay_debt_form").serialize();

        $.ajax({

            type : 'POST',
            url  : '../../production/sales/paydebt.php',
            data : data,
            beforeSend: function()
            {
                $("#error").fadeOut();
                $("#btn_pay_debt").html('<span class="glyphicon glyphicon-transfer"></span> &nbsp; sending ...');
            },
            success :  function(data)
            {

                if(data=="paid")
                {
                    $("#error").fadeOut();
                    $("#btn_pay_debt").html('Pay Debt');
                    $("#success").html('<div class="alert alert-success"><span class="glyphicon glyphicon-info-sign"></span> &nbsp; Payment successfully made !</div>');

                }
                else{

                    $("#error").fadeIn(1000, function(){
             $("#success").fadeOut();

                        $("#error").html('<div class="alert alert-danger"><span class="glyphicon glyphicon-info-sign"></span> &nbsp; '+data+' !</div>');

                        $("#btn_pay_debt").html('<span class="glyphicon glyphicon-log-in"></span> &nbsp; Pay Debt');

                    });

                }
            }
        });
        return false;
    }
    /* form submit */
});
  
function refreshPage() {
    location.reload();
}
</script>
