
<?php include '../../headers/salesaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-list"> Products</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Products</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="update-form">

           <div id="uperror"></div> 
           <div id="upsuccess"></div>
            

  <!--div class="button-group">
     <button type="button" name="add" id="add" class="btn btn-success pull-right" data-toggle="modal" data-target="#myModal" data-toggle="tooltip" data-placement="left" title="Add Car Type"><span class="glyphicon glyphicon-plus-sign"></span> Add Product</button>
    </div><br/><br/-->

	<div class="table-responsive" >
	       <table id="shop_table-grid" class="display" style="width:100%">
		   <thead>
		   <tr>
		   <th>No</th>
       <!--th>Product Category</th>
       <th>Brand</th-->
		   <th>Products</th>
       <th>Quantity</th>
       <th>Unit Price (&cent;)</th>
       <th>Whole Sale Price (&cent;)</th>
	   <th>Retail Price (&cent;)</th>
		   <th>Created At</th>
		   </tr>
		   </thead>
		   </table>
		  </div>
		  </form>

  <form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="register-form">
      

  </form>
  
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/salesfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script>      
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  
  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/sales/productscript.js"></script>
<!--script type="text/javascript" src="../../script/administrator/updateprodcatescript.js"></script-->

<script type="text/javascript">
$('.shop').select2({
        placeholder: 'Select Shop',
        ajax: {
          url: '../../production/administrator/shopnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
$('.prodcate').select2({
        placeholder: 'Select product category',
        ajax: {
          url: '../../production/administrator/prodcate.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
$('.brand').select2({
        placeholder: 'Select brand',
        ajax: {
          url: '../../production/administrator/brand.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
</script>