<?php include '../../production/administrator/productupdate.php'?>
<?php include '../../headers/admaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

<!--set time-->
<script type="text/javascript">
 
function timedMsg()
{
var t=setTimeout("document.getElementById('alert').style.display='none';",4000);
}
</script>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-edit"> Update Product</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Manage Products</li>
      </ol>
    </section>
  
  <!-- Main content -->
    <section class="content">
  
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">

  
      
  <form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" id="register-form">
         <h3 class="form-signin-heading">Select product to update</h3><hr>
<?php echo $alert .'<script language="JavaScript" type="text/javascript">timedMsg()</script>' ?>
            <!--div id="error">
            </div>
           <div id="success">
            </div-->
      <div class="form-group">
           <select class="productid form-control" style="width:100%" name="productid" id="productid" required="required">
    </select>   
        </div>
       
       <div id="showRec">
         
       </div>

            <!-- /.col -->
       <div class="col-md-12">
      <div class="form-group" style="float:right">
      <button type="button" class="btn btn-info" onClick="refreshPage()" name="btn-save" id="btn-addnew">
                    <span class="glyphicon glyphicon-refresh"></span> &nbsp; Reset
                </button>
                <button type="submit" class="btn btn-primary" name="btnsave" id="btn-submit">
                <span class="fa fa-save"></span> &nbsp; Save Changes
                </button>
                 </div>
                </div>
               </form>
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/admfooter.php'?>    
 
  <!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>

<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script src="../../bower_components/validator/dist/js/jquery.maskedinput.js"></script>
<script type="text/javascript">
  $('document').ready(function(){
$('#productid').change(function(){
    var product_number = $(this).val();
    $.ajax({
      url:"../../production/administrator/showproduct.php",
      method:"POST",
      data:{product_number:product_number},
      success:function(data){
        $('#showRec').html(data);
      }
    });
   });
});
  $('.productid').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/administrator/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });

function refreshPage() {
    location.reload();
}
</script>
