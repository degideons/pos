
<?php include '../../headers/admaside.php'?>
<link rel="stylesheet" href="../../bower_components/jquery/dist/css/jquery.dataTables.min.css"> 

<!--set time-->
<script type="text/javascript">
 
function timedMsg()
{
var t=setTimeout("document.getElementById('alert').style.display='none';",4000);
}
</script>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-money"> Debtors</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Manage Debtors</li>
      </ol>
    </section>
  
  <!-- Main content -->
    <section class="content">
  
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
<div class="signin-form">

<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" id="register-form">
         <h3 class="form-signin-heading"></h3>
           <div class="table-responsive" >
         <table id="shop_table-grid" class="display" style="width:100%">
       <thead>
       <tr>
       <th>No</th>
       <th>Invoice</th>
       <th>Customers</th>
       <th>Telephone</th>
       <th>Net Total (&cent;)</th>
       <th>Paid (&cent;)</th>
       <th>Due (&cent;)</th>
       <th>Shop</th>
       <th>Created At</th>
       <th>Action</th>
       </tr>
       </thead>
       </table>
      </div>
       
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/admfooter.php'?>    
 
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script> 
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  

<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/administrator/debtorsdetscript.js"></script>


<script type="text/javascript">
  $('document').ready(function(){



 })
  
function refreshPage() {
    location.reload();
}
</script>
