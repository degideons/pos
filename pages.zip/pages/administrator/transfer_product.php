
<?php include '../../headers/admaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
  <link rel="stylesheet" href="../../bower_components/jquery/dist/css/jquery.dataTables.min.css"> 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-file"> Transfer Product</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"> Transfer Product</li>
      </ol>
    </section>
  
  <!-- Main content -->
    <section class="content">
  
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="transfer_product-form">

           <div id="uperror"></div> 
           <div id="upsuccess"></div>
            
<?php
include "../../connection/config.php";
session_start();
//$shopsid = $_SESSION['shopid'];

    if(isset($_GET['sid'])){
      $distribute_id = $_GET['sid'];
      //$prod_id = $_GET['rid'];

    $stmt = $mysqli->prepare("select * from distribute d,products p, shop s where d.ProductID=p.ProductID and d.ShopID=s.ShopID and d.DistributeID=?");
    $stmt->bind_param("s",$distribute_id);
    $stmt->execute();
    $rest = $stmt->get_result();
    $row = $rest->fetch_assoc();
}
?>


  <div class="row">
    <marquee style="color:darkred"><label for="label">You are transferring product from <?php echo $row['Shop']?></label></marquee>
       <div class="col-md-6">
          
          <div class="form-group">
            <label>Transfer From</label>
          <input type="text" class="form-control" id="shopname" name="shopname" value="<?php echo $row['Shop']?>" readonly="readonly">
        
         <input type="hidden" class="form-control" id="shopid" name="shopid" value="<?php echo $row['ShopID']?>" readonly="readonly">
        </div>

     <div class="form-group">
        <label>Product</label>
        <input type="hidden" class="form-control" id="productid" name="productid" value="<?php echo $row['ProductID']?>">
        <input type="text" class="form-control" id="product" name="product" value="<?php echo $row['Product']?>" readonly="readonly">
        </div>

    <div class="form-group">
        <label>Current Stock</label>
        <input type="text" class="form-control" id="qty" name="qty" value="<?php echo $row['Quantity']?>" readonly="readonly">
        </div>

    <div class="form-group">
        <label>Transfer Quantity</label>
        <input type="text" class="form-control" id="transfer_quantity" name="transfer_quantity" required="required">
        </div>

<div class="form-group">
        <label>Remaining</label>
        <input type="text" class="form-control" id="remaining" name="remaining" required="required" readonly="readonly">
        </div>
       </div>
       <div class="col-md-6">
       

        <div class="form-group">
        <label>Transfer To</label>
        <select  class="form-control transfer_to" id="transfer_to" name="transfer_to" style="width: 100%" required="required">
        </select>
        </div>

        <div id="displayRecords"></div>

         

       </div>
      
      </form>
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/salesfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script>    

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  
  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/sales/sales_products_script.js"></script>
<!--script type="text/javascript" src="../../script/administrator/updateprodcatescript.js"></script-->

<script type="text/javascript">
  $('document').ready(function(){
  $("#transfer_to").change(function(){

      var transfer_to = $("#transfer_to").val();
      var productid = $("#productid").val();
    $.ajax({
    url:'../../production/administrator/show_transfer_to.php',
    method:'POST',
    data:{productid:productid,transfer_to:transfer_to},
    success:function(data){
      $("#displayRecords").html(data);
    }
  })
  })

  $('.transfer_to').select2({
        placeholder: 'Select Shop',
        ajax: {
          url: '../../production/administrator/shopnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
})
  
    

$(document).on("change keyup blur", "#transfer_quantity", function() {
  var transfer_quantity = $('#transfer_quantity').val();
  var qty = $('#qty').val();

   if(transfer_quantity <= 0){
    location.reload();
   }
   else{
  var comptransfer_quantity = new Number(transfer_quantity);
  var compqty = new Number(qty);
  if(comptransfer_quantity > compqty){
    //alert('Please, Transfer quantity cannot be greater than Current Stock');
    location.reload();
  }
  else{
 var remaining = qty - transfer_quantity;
  $('#remaining').val(remaining);
  }
  }
});

$(document).on('click','.btn_return-product',function(){
      var data_id = $(this).attr("id");
      var action = "Cancel";
   if(confirm("Are you sure you want to transfer product?"))
   {
    $.ajax({
     url:"../../production/administrator/save_transfer_product.php",
     method:"POST",
     data:$("#transfer_product-form").serialize(),
     success:function(data)
     {
      alert(data);
      //load_data();
      location.reload();
     }
    });
   }
   else
   {
    alert('Product(s) not transferred!');
    return false;
   }
  })
</script>