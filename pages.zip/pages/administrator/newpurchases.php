
<?php include '../../headers/admaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-file"> Purchases</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"> Purchases</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="myform" onsubmit="return false">

           <div id="error"></div> 
           <div id="success"></div>    

<div class="row">
  <div class="col-md-8">
  <div class="orderlist">
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Invoice Number</label>
      <div class="col-sm-6">
        <input type="text" name="invoiceno" id="invoiceno" class="invoiceno form-control form-control-sm" required="required">
      </div>
    </div>
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Purchase Date</label>
      <div class="col-sm-6">
        <input type="date" name="orderdate" id="orderdate" class="form-control form-control-sm" required="required">
      </div>
    </div>
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Vendor's Name</label>
      <div class="col-sm-6">
        <select name="vendorname" class="vendorname form-control form-control-sm" required="required">
        </select>
      </div>
    </div>
    </div>

	<div class="table-responsive" >
	     <table id="order_table-grid" class="display" style="width:100%">
        <h2>Purchase List <button class="btn btn-success pull-right" id="add" data-toggle="tooltip" title="Add"><span class="glyphicon glyphicon-plus-sign"></span> Add</button></h2>
		   <thead>
		   <tr>
		   <th>#</th>
       <th style="text-align: center;">Item Name</th>
       <th style="text-align: center;">Quantity</th>
       <th style="text-align: center;">Price (&cent;)</th>
       <th style="text-align: center;">Total </th>
       <th style="text-align: center;">Remove </th>
		   </tr>
		   </thead>
       <tbody id="showorderlist">

       </tbody>
		   </table>

       <center style="padding: 10px">
         
       </center>
		  </div>
      </div>

      <div class="col-md-4">
          <div class="form-group row">
      <label for="label" align="right" class="col-sm-4 col-form-label">Sub total (&cent;)</label>
      <div class="col-sm-6">
        <input type="text" name="subtotal" id="subtotal" value="" class="form-control form-control-sm" required="required"  readonly="readonly">
      </div>
    </div>
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-4 col-form-label">Discount (%)</label>
      <div class="col-sm-6">
        <input type="text" name="discount" id="discount" class="form-control form-control-sm" required="required">
      </div>
    </div>
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-4 col-form-label">Net Total (&cent;)</label>
      <div class="col-sm-6">
        <input type="text" name="nettotal" id="nettotal" class="form-control form-control-sm" required="required" readonly="readonly">
      </div>
    </div>
     <div class="form-group row">
      <label for="label" align="right" class="col-sm-4 col-form-label">Paid (&cent;)</label>
      <div class="col-sm-6">
        <input type="text" name="paid" id="paid" class="form-control form-control-sm" required="required">
      </div>
    </div>
     <div class="form-group row">
      <label for="label" align="right" class="col-sm-4 col-form-label">Due (&cent;)</label>
      <div class="col-sm-6">
        <input type="text" name="due" id="due" class="form-control form-control-sm" required="required" readonly="readonly">
      </div>
    </div>
     <div class="form-group row">
      <label for="label" align="right" class="col-sm-4 col-form-label">Payment Method</label>
      <div class="col-sm-6">
        <select name="paymentmethod" id="paymentmethod" class="paymentmethod form-control form-control-sm" style="width: 100%" required="required">
          <option></option>
          <option value="Cash">Cash</option>
          <option value="Cheque">Cheque</option>
          <option value="Mobile Money">Mobile Money</option>
        </select>
      </div>
    </div>

    <div class="button-group" style="margin: auto;">
      <div align="right" class="col-sm-4 col-form-label"></div>
      <div class="col-sm-7">
      <button class="btn btn-success invisible" id="prt_invoice" name="btnprint">Print Invoice</button>
      <button class="btn btn-primary" id="order_form" name="btnorder" style="width: 35%">Save</button>
    </div>
    </div>

      </div>
    </div>
  </form>
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/admfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>

  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../script/administrator/purchasescript.js"></script>
<!--script type="text/javascript" src="../../script/administrator/updateprodcatescript.js"></script-->

<script type="text/javascript">
$(document).ready(function(e){
        $("#order_form").click(function(e){
        e.preventDefault();

        var invoice = $("#myform").serialize();
          
          $.ajax({
          url:'../../production/administrator/savepurchase.php',
          type:'post',
          data:$("#myform").serialize(),
            success:function(data){
              if(data < 0){
                alert(data);
              }
              else if(data == "check"){
                alert("Sorry! This much quantity is not available");
              }
              else{
                $("order_form").trigger("reset");
                if(confirm("Do you want to print invoice?")){
                  window.location.href = "../../production/administrator/printpurchase.php?invoiceno="+data+"&"+invoice;
                }
                else{
                  alert("Records successfully saved");
                }
              }
            }
          })
        })


  });

</script>