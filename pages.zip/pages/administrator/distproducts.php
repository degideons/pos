
<?php include '../../headers/admaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-file"> Add New Shop Products</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"> Add New Shop Products</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="myform" onsubmit="return false">

           <div id="error"></div> 
           <div id="success"></div>    

<div class="row">
  <div class="col-md-8">
  <div class="orderlist">
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label"> Date</label>
      <div class="col-sm-6">
        <input type="text" name="distdate" id="distdate" class="form-control form-control-sm" value="<?php echo date("Y-m-d")?>" required="required" readonly="readonly">
      </div>
    </div>

    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Select Shop</label>
      <div class="col-sm-6">
        <select name="shop" class="shop form-control form-control-sm" id="shop" required="required">
        </select>
        
      </div>
    </div>

    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Select Product</label>
      <div class="col-sm-6">
        <select name="product" class="product form-control form-control-sm" id="product" required="required">
        </select>
      </div>
    </div>

    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Quantity</label>
      <div class="col-sm-6">
        <input type="number" name="quantity" id="quantity" class="form-control" min="1" step="any" required="required">
      </div>
    </div>

    </div>

	<div class="table-responsive" >
	   

       <center style="padding: 10px">
          <div class="button-group" style="margin: auto;">
      <div align="right" class="col-sm-4 col-form-label"></div>
      <div class="col-sm-7">
      <button class="save_button btn btn-primary" id="save_button" name="save_button" style="width: 35%">Save to shop</button>
    </div>
    </div>
       </center>
		  </div>
      </div>

      <div class="col-md-4">


   

      </div>
    </div>
  </form>
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/admfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>

  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<!--script type="text/javascript" src="../../script/administrator/shopproductscript.js"></script-->
<!--script type="text/javascript" src="../../script/administrator/updateprodcatescript.js"></script-->

<script type="text/javascript">

  $('.shop').select2({
        placeholder: 'Select Shop',
        ajax: {
          url: '../../production/administrator/shopnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });

  $('.product').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/administrator/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });

$(document).on('click','.save_button',function(){
     
   //if(confirm("Are you sure you want to Save product?"))
  // {
    $.ajax({
     url:"../../production/administrator/saveshopproduct.php",
     method:"POST",
     data:$("#myform").serialize(),
     success:function(data)
     {
      alert(data);
      //load_data();
      location.reload();
     }
    });
 // }
   //else
   //{
   // alert('Product(s) not transferred!');
   // return false;
   //}
  })

 

</script>