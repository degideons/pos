<?php include '../../headers/admaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

<!--set time-->
<script type="text/javascript">
 
function timedMsg()
{
var t=setTimeout("document.getElementById('alert').style.display='none';",4000);
}
</script>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-money"> Net Income</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Net Income</li>
      </ol>
    </section>
  
  <!-- Main content -->
    <section class="content">
  
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">

  
      
  <form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" id="register-form">
         <h3 class="form-signin-heading">Select date to search</h3><hr>
<center>
      <div class="form-group">
 <label for="label">From</label> <input type="date" name="datefrom" id="datefrom"> 
 <label for="label">To</label> <input type="date" name="dateto" id="dateto">
        </div>
      </center>
        
<div class="row">
  <div class="col-md-1"></div>
  <div class="col-md-9">
<center>
<div id="printpage">
<div id="displayReport"></div>
        
   </div>
 </center>
</div>
</div>

            <!-- /.col -->
       <div class="col-md-12">
      <div class="form-group" style="float:right">
      <button type="button" class="btn btn-info" onClick="refreshPage()" name="btn-save" id="btn-addnew">
                    <span class="glyphicon glyphicon-refresh"></span> &nbsp; Reset
                </button>
                <button type="button" class="btn btn-primary" name="btnsave" id="btn-submit" onclick="printDiv()">
                <span class="fa fa-print"></span> &nbsp; Print
                </button>
                 </div>
                </div>
               </form>
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/admfooter.php'?>    
 
  <!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>

<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script src="../../bower_components/validator/dist/js/jquery.maskedinput.js"></script>
<script type="text/javascript">
  $('document').ready(function(){
  $("#dateto").change(function(){
    var dateto = $("#dateto").val();
    var datefrom = $("#datefrom").val();
    $.ajax({
    url:'../../production/administrator/netincomerpt.php',
    method:'POST',
    data:{datefrom:datefrom,dateto:dateto},
    success:function(data){
      $("#displayReport").html(data);
    }
  })
  })
  })
   function printDiv() {    
    var printContents = document.getElementById('printpage').innerHTML;
    var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
    }
function refreshPage() {
    location.reload();
}
</script>
