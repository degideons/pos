
<?php include '../../headers/admaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-home"> Shop</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Shop</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="update-form">

           <div id="uperror"></div> 
           <div id="upsuccess"></div>
            

  <div align="right">
     <button type="button" name="add" id="add" class="btn btn-success" data-toggle="modal" data-target="#myModal" data-toggle="tooltip" data-placement="left" title="Add Car Type"><span class="glyphicon glyphicon-plus-sign"></span> Add New Shop</button>
    </div><br/>

	<div class="table-responsive" >
	       <table id="shop_table-grid" class="display" style="width:100%">
		   <thead>
		   <tr>
		   <th>No</th>
		   <th>Shop</th>
       <th>Shop Type</th>
		   <th>Created At</th>
		   </tr>
		   </thead>
		   </table>
		  </div>
		  </form>

  <form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="register-form">
      
      <!--add new car-->
  <div class="modal  fade" id="myModal" aria-labelledby="admodallabel" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content panel-warning">
  <div class="modal-header">
  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true" onclick="myFunction()">&times;</span><span class="sr-only"></span></button>
  <h3 class="modal-title" id="admodallabel"> <span class="fa fa-home"></span> Add New Shop</h3>
  </div>
  <div class="modal-body">
  
  <div id="error">
            </div>
           <div id="success">
            </div>
   
     <div class="form-group">
       <input type="text" class="form-control" style="width:100%" name="shop" id="shop" required="required"placeholder="Shop" autocomplete="off">
   </div>

   <div class="form-group">
       <select class="shoptype form-control" style="width:100%" name="shoptype" id="shoptype" required="required">
        <option></option>
        <option value="Retail">Retail</option>
        <option value="wholesale">Wholesale</option>
        <option value="Main wholesale">Main Wholesale</option>
       </select>
   </div>
  
  </div>
  <div class="modal-footer">
  <button type="button"  class="btn btn-default" onclick="myFunction()" data-dismiss="modal"><span class="glyphicon glyphicon-plus-sign"></span> Add New</button>
  <button type="submit" class="btn btn-success" name="btnsave" id="btn-submit"><span class="fa fa-save"></span> Save </button>
  </div>
   
  </div>
  </div>
  </div>
  </form>
  
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/admfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script>      
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  
  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/administrator/shopscript.js"></script>
<script type="text/javascript" src="../../script/administrator/updateprodcatescript.js"></script>

<script type="text/javascript">
   $('.shoptype').select2({
    placeholder: 'Select shop type',
  });
</script>