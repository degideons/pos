<?php include '../../production/administrator/update_product_qty.php'?>
<?php include '../../headers/admaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="../../bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

<!--set time-->
<script type="text/javascript">
 
function timedMsg()
{
var t=setTimeout("document.getElementById('alert').style.display='none';",4000);
}
</script>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-edit"> Update Shop Products</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Manage Shop Products</li>
      </ol>
    </section>
  
  <!-- Main content -->
    <section class="content">
  
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">

  
      
  <form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" id="register-form">
         <h3 class="form-signin-heading">Select shop and product to update</h3><hr>
<?php echo $alert .'<script language="JavaScript" type="text/javascript">timedMsg()</script>' ?>
            <!--div id="error">
            </div>
           <div id="success">
            </div-->
             <div class="form-group">
           <input type="text" class="form-control datepicker" name="datepicker" id="datepicker" placeholder="Copy and paste date">
        </div>
      <div class="form-group">
           <select class="shop form-control" style="width:100%" name="shop" id="shop" required="required">
    </select>   
        </div>
         <div class="form-group">
           <select class="products form-control" style="width:100%" name="products" id="products" required="required">
    </select>   
        </div>
       
       <div id="showRec">
         
       </div>

            <!-- /.col -->
       <div class="col-md-12">
      <div class="form-group" style="float:right">
      <button type="button" class="btn btn-info" onClick="refreshPage()" name="btn-save" id="btn-addnew">
                    <span class="glyphicon glyphicon-refresh"></span> &nbsp; Reset
                </button>
                <button type="submit" class="btn btn-primary" name="btnupdate" id="btn-submit">
                <span class="fa fa-save"></span> &nbsp; Save Changes
                </button>
                 </div>
                </div>
               </form>
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/admfooter.php'?> 
<script src="../../bower_components/moment/min/moment.min.js"></script>
<script src="../../bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="../../bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

 
  <!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>

<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script src="../../bower_components/validator/dist/js/jquery.maskedinput.js"></script>

<script type="text/javascript">
  $('document').ready(function(){


    $('#products').change(function(){
    var datepicker = $('#datepicker').val();
    var product_number = $(this).val();
    var shop_number = $('#shop').val();
    $.ajax({
      url:"../../production/administrator/show_product_qty.php",
      method:"POST",
      data:{datepicker:datepicker,shop_number:shop_number,product_number:product_number},
      success:function(data){
        $('#showRec').html(data);
      }
    });
   });

});
  $('.shop').select2({
        placeholder: 'Select Shop',
        ajax: {
          url: '../../production/administrator/shopnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
  $('.products').select2({
        placeholder: 'Select Product',
        ajax: {
          url: '../../production/administrator/productnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
  $(document).on("change keyup blur", "#quantity", function() {
    var status = $('#status').val();
    var sum = 0;
    var mysum = 0;
    
    if(status == "Add"){
  
    $('.quantity').each(function(){
      sum += Number($(this).val());
    })
    $('#grand_total').val(sum);

    $('.prodqty').each(function(){
      mysum += Number($(this).val());
    })
    $('#total_quantity').val(mysum);
  }
  else if(status == "Deduct"){
    var minus = 0;
    var deduct = 0;
    var total_stock = $('#total_stock').val();
    var quantity = $('#quantity').val();
    deduct = (total_stock - quantity);
    $('#grand_total').val(deduct);

    var total_added = $('#total_added').val();
    var quantity = $('#quantity').val();
    minus = (total_added - quantity);
    $('#total_quantity').val(minus);
  }
  })

//Date picker
   //Date picker
    //$('#datepicker').datepicker({
     // autoclose: true
      //format: 'yyyy-mm-dd hh:ii:ss'

    //})

  

function refreshPage() {
    location.reload();
}
</script>
