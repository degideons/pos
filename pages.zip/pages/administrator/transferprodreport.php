
<?php include '../../headers/admaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
  <link rel="stylesheet" href="../../bower_components/jquery/dist/css/jquery.dataTables.min.css"> 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-folder"> Transferred Products Report</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Manage Reports</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"><i> <label for="label" class="label label-success">Please select date to search</label></i></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="report-form">
          
           <div class="calendar">
           <label for="label">Select Date</label><input type="date" name="txtdate" id="txtdate">&nbsp;

           </div>
            


	<div id="displayReport">
   
  </div>
  
  
  </form>
		

  
  
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/admfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script>    

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  
  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>


<script type="text/javascript">
  $('document').ready(function(){
  $("#txtdate").change(function(){
    var txtdate = $("#txtdate").val();
    $.ajax({
    url:'../../production/administrator/transferprodrptdet.php',
    method:'POST',
    data:{txtdate:txtdate},
    success:function(data){
      $("#displayReport").html(data);
    }
  })
  })
})
    function printDiv() {    
    var printContents = document.getElementById('printpage').innerHTML;
    var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
    }
    function refreshPage(){
      location.reload();
    }
</script>