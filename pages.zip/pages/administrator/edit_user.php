<?php include '../../headers/admaside.php'?>
 <!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-users"> Add New User</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Add New User</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="register-box" style="margin-top:-10px">
       <div class="register-box-body">
<div class="signin-form">

<?php
include("../../connection/config.php");
if(isset($_GET['id'])){
  $uid = $_GET['id'];
   $pid = $_GET['id'];

    $stmt = $mysqli->prepare("select * From users u, shop s where u.ShopID = s.ShopID and u.UserID = ?");
    $stmt->bind_param("s",$uid);
    $stmt->execute();
    $rest = $stmt->get_result();
    $row = $rest->fetch_assoc();

    $stmt = $mysqli->prepare("select * FROM users u, shop p where u.OthShop=p.ShopID and u.UserID = ?");
    $stmt->bind_param("s",$pid);
    $stmt->execute();
    $rest = $stmt->get_result();
    $rows = $rest->fetch_assoc();
    //$othshop = $rows['OtherShop'];
}
?>
   

<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="register-form">
        <!--form class="form-signin" method="post" id="register-form"-->

            <h4 class="form-signin-heading">All fields are required</h4><hr />

            <div id="error">
            </div>
           <div id="success">
            </div>
			
            <div class="form-group">
              <label for="label">Full Name</label>
              <input type="hidden" class="form-control" placeholder="User ID" name="userid" id="fullname" value="<?php echo $_GET['id'];?>" required="required" readonly="readonly" />
                <input type="text" class="form-control" placeholder="Full Name" name="fullname" id="fullname" value="<?php echo $row['FullName']?>" required="required" />
				 <div class="help-block with-errors"></div>
            </div>
			
			<div class="form-group">
        <label for="label">Phone Number</label>
                <input type="tel" class="form-control" placeholder="Phone Number" name="phone" id="phone" value="<?php echo $row['PhoneNo']?>"required="required" />
                <div class="help-block with-errors"></div>
            </div>

            <div class="form-group">
              <label for="label">Email</label>
                <input type="email" class="form-control" placeholder="Email address" name="email" id="email" value="<?php echo $row['Email']?>" />
                <div class="help-block with-errors"></div>
            </div>
			
			
			<div class="form-group">
        <label for="label">User Type</label>
	  <select name="usertype" id="usertype" class="usertype form-control" required="required" data-error="Please select one option.">
	  <option value="<?php echo $row['UserType']?>"> <?php echo $row['UserType']?></option>
	  <option value="Administrator">Administrator</option>
	  <option value="Sales Personnel">Sales Personnel</option>
	  <option value="Supplier">Supplier</option>
	  </select>
        <span class="glyphicon glyphicon form-control-feedback"></span>
		<div class="help-block with-errors"></div>
      </div>

      <div class="form-group">
        <label for="label">Shop 1</label>
    <select name="shop" id="shop" class="shop form-control" required="required" data-error="Please select one option.">
      <option value="<?php echo $row['ShopID']?>"> <?php echo $row['Shop']?></option>
    </select>
        <span class="glyphicon glyphicon form-control-feedback"></span>
    <div class="help-block with-errors"></div>
      </div>

      <div class="form-group">
        <label for="label">Shop 2 Optional</label>
    <select name="othshop" id="othshop" class="othshop form-control" data-error="Please select one option.">
       <option value="<?php echo $rows['OthShop'] ?>"> <?php echo $rows['Shop']?></option>
    </select>
        <span class="glyphicon glyphicon form-control-feedback"></span>
    <div class="help-block with-errors"></div>
      </div>
			
		<div class="form-group">
    <label for="label">User Name</label>	 
        <input type="text" name="username" id="username" value="<?php echo $row['Username']?>" class="form-control" placeholder="Username" required="required" data-error="Please enter a username.">
        <span class="glyphicon glyphicon form-control-feedback"></span>
		<div class="help-block with-errors"></div>
      </div>


			<div class="form-group">
        <label for="label">Status</label>
	    <select name="status" id="status" class="status form-control" required="required" data-error="Please select one option.">
	  <option value="<?php echo $row['Status']?>"><?php echo $row['Status']?></option>
	  <option value="Active">Active</option>
	  <option value="Inactive">Inactive</option>
	  </select>
        <span class="glyphicon glyphicon form-control-feedback"></span>
		<div class="help-block with-errors"></div>
      </div>
			
            <hr />

            <div class="form-group">
			<button type="button" class="btn btn-info" name="btnaddnew" onClick="refreshPage()" id="btn-addnew">
                    <span class="glyphicon glyphicon-refresh"></span> &nbsp; Reset
                </button>
                <button type="submit" class="btn btn-primary"  name="btn_update" id="btn_update">
                    <span class="glyphicon glyphicon-edit"></span> &nbsp; Save Changes
                </button>
				
            </div>


        </form>

  
                  </div>

                </div>
			
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
  

<?php include '../../headers/admfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>

<script src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/administrator/updateuserscript.js"></script>

<script src="../../bower_components/validator/dist/js/jquery.maskedinput.js"></script>

 <script>
 			$(function() {
        $("#phone").mask("+233999999999");
		$("#tel").mask("+19999999999");

        $("input").blur(function() {
            $("#info").html("Unmasked value: " + $(this).mask());
        }).dblclick(function() {
            $(this).unmask();
        });
    });
	function refreshPage(){
    window.location.reload();
} 
 $('.usertype').select2({
		placeholder: 'Select user type',
	});
	 $('.status').select2({
		placeholder: 'Select status',
	});
   $('.shop').select2({
        placeholder: 'Select Shop',
        ajax: {
          url: '../../production/administrator/shopnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });

   $('.othshop').select2({
        placeholder: 'Select Shop 2 this is optional',
        ajax: {
          url: '../../production/administrator/shopnumber.php',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
	</script>

</body>
</html>
