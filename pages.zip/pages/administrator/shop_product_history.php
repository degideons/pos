<?php 
session_start();
error_reporting(0);
$_SESSION['shopd'] = $_GET['psid'];
$shopd = $_SESSION['shopd'];
//unset($_SESSION['shopd']);
?>
<?php include '../../headers/admaside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-desktop"> Shop Products History</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Shop Products History</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
          <div class="box-body">
          <div id="success"><label class="label label-danger" style="font-size: 20px"><?php echo $_GET['shops']?></label></div><br>
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="get" action="" role="form" data-toggle="validator" novalidate="true" id="myform">

        

	<div class="table-responsive" >
	       <table id="shop_table-grid" class="display" style="width:100%">
		   <thead>
		   <tr>
		   <th>No</th>
       <th>Product</th>
       <th>Previous Quantity</th>
       <th>Product Quantity</th>
       <th>Total Quantity</th>
       <th>Status</th>
       <th>Created By</th>
       <!--th>Shop</th-->
       <th>Date</th>
       <th>Time</th>
       <th>Action</th>
		   </tr>
		   </thead>
		   </table>
		  </div>
		  </form>
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/admfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script>      
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  
  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/administrator/shop_prod_history.js"></script>

<script type="text/javascript">
$(document).on('click','.delete',function(){
      var data_id = $(this).attr("id");
      var action = "Delete";
   if(confirm("Are you sure you want to delete this?"))
   {
    $.ajax({
     url:"../../production/administrator/delshop_products.php",
     method:"POST",
     data:{data_id:data_id, action:action},
     success:function(data)
     {
      alert(data);
      //load_data();
      location.reload();
     }
    });
   }
   else
   {
    return false;
   }
    })
</script>