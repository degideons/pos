<?php include '../../headers/supplieraside.php'?>
 <!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-edit"> Change Password</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Change Password</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="register-box" style="margin-top:-10px">
       <div class="register-box-body">
<div class="signin-form">

   

<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="register-form">
        <!--form class="form-signin" method="post" id="register-form"-->

            <h4 class="form-signin-heading">All fields are required</h4><hr />

            <div id="error">
            </div>
           <div id="success">
            </div>

		<div class="form-group">	 
        <input type="password" name="oldpassword" id="oldpassword" class="form-control" placeholder="Old Password" required="required" data-error="Please enter a oldpassword.">
        <span class="glyphicon glyphicon form-control-feedback"></span>
		<div class="help-block with-errors"></div>
      </div>

            <div class="form-group">
                <input type="password" class="form-control" placeholder="New Password" data-minlength="8" name="password" id="password" required="required" data-error="Please provide a new password." />
				<div id="errormsg">Password Needs To Be Minimum of 8 Characters</div>
             <div class="help-block with-errors"></div>           
		   </div>
			

            <div class="form-group">
                <input type="password" class="form-control" placeholder="Retype Password" name="cpassword" id="cpassword" data-match="#password" required="required" data-error="Please password does not match." />
				<div class="help-block with-errors"></div>
            </div>
			

			
            <hr />

            <div class="form-group">

                <button type="submit" class="btn btn-primary"  name="btnupdate" id="btn-submit">
                    <span class="glyphicon glyphicon-save"></span> &nbsp; Save Changes
                </button>
				
            </div>


        </form>

  
                  </div>

                </div>
			
              </div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
  

<?php include '../../headers/supplierfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>

<script src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/supplier/changepasscript.js"></script>

 <script>
 	
	function refreshPage(){
    window.location.reload();
} 

	</script>

</body>
</html>
