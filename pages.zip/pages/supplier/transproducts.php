<?php 
session_start();
error_reporting(0);
$_SESSION['shopd'] = $_GET['shop'];
$shopd = $_SESSION['shopd'];
//unset($_SESSION['shopd']);
?>
<?php include '../../headers/supplieraside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-desktop"> Transferred Products</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active">Transfer Products</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
          <div class="box-body">
          <div id="success"><label class="label label-danger" style="font-size: 20px"><?php echo $_GET['shops']?></label></div><br>
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="get" action="" role="form" data-toggle="validator" novalidate="true" id="myform">

        

	<div class="table-responsive" >
	       <table id="shop_table-grid" class="display" style="width:100%">
		   <thead>
		   <tr>
		   <th>No</th>
       <th>Product</th>
       <th>Quantity</th>
       <th>Date</th>
		   </tr>
		   </thead>
		   </table>
		  </div>
		  </form>
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/supplierfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>
  <!--datatables-->      
  <script src="../../bower_components/jquery/dist/jquery.dataTables.js"></script>      
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">  
  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../script/supplier/prodtransferscript.js"></script>
<!--script type="text/javascript" src="../../script/administrator/updateprodcatescript.js"></script-->

<script type="text/javascript">

</script>