
<?php include '../../headers/supplieraside.php'?>
<!-- Select2 -->
  <link rel="stylesheet" href="../../bower_components/select2/dist/css/select2.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <label for="label" class="fa fa-file"> Transfer Products</li>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"> Transfer Products</li>
      </ol>
    </section>
	
	<!-- Main content -->
    <section class="content">
	
      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <div class="box box-primary">
            <div class="box-header">
              <i class=""></i>

              <h3 class="box-title"></h3>

             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           
      
<div class="signin-form">
<form class="form-signin" enctype="multipart/form-data" method="post" action="" role="form" data-toggle="validator" novalidate="true" id="myform" onsubmit="return false">

           <div id="error"></div> 
           <div id="success"></div>    

<div class="row">
  <div class="col-md-8">
  <div class="orderlist">
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label"> Date</label>
      <div class="col-sm-6">
        <input type="text" name="distdate" id="distdate" class="form-control form-control-sm" value="<?php echo date("Y-m-d")?>" required="required" readonly="readonly">
      </div>
    </div>
    <div class="form-group row">
      <label for="label" align="right" class="col-sm-3 col-form-label">Shop</label>
      <div class="col-sm-6">
        <select name="shop" class="shop form-control form-control-sm" required="required">
        </select>
      </div>
    </div>
    </div>

	<div class="table-responsive" >
	     <table id="order_table-grid" class="display" style="width:100%">
        <h2>Product List <button class="btn btn-success pull-right" id="add" data-toggle="tooltip" title="Add"><span class="glyphicon glyphicon-plus-sign"></span> Add</button></h2>
		   <thead>
		   <tr>
		   <th>#</th>
       <th style="text-align: center;">Item Name</th>
       <th style="text-align: center;">Total Quantity</th>
       <th style="text-align: center;">Quantity</th>
       <!--th style="text-align: center;">Selling Price(&cent;) </th-->
       <th style="text-align: center;">Remove </th>
		   </tr>
		   </thead>
       <tbody id="showorderlist">

       </tbody>
		   </table>

       <center style="padding: 10px">
          <div class="button-group" style="margin: auto;">
      <div align="right" class="col-sm-4 col-form-label"></div>
      <div class="col-sm-7">
      <button class="btn btn-primary" id="order_form" name="btnorder" style="width: 35%">Save to shop</button>
    </div>
    </div>
       </center>
		  </div>
      </div>

      <div class="col-md-4">


   

      </div>
    </div>
  </form>
</div>
            </div>
          </div>
        </section>
      </div>
    </section>
  </div>
    
<?php include '../../headers/supplierfooter.php'?>
<!-- Select2 -->
<script src="../../bower_components/select2/dist/js/select2.full.min.js"></script>

  
<script type="text/javascript" src="../../bower_components/validator/dist/js/validator.min.js"></script>
<script type="text/javascript" src="../../script/supplier/transferprodscript.js"></script>

<script type="text/javascript">
$(document).ready(function(e){
        $("#order_form").click(function(e){
        e.preventDefault();

        var invoice = $("#myform").serialize();
          
          $.ajax({
          url:'../../production/supplier/savetransfer.php',
          type:'post',
          data:$("#myform").serialize(),
            success:function(data){
              if(data < 0){
                alert(data);
              }
              else if(data == "check"){
                alert("Sorry! This much quantity is not available");
              }
              else{
                $("order_form").trigger("reset");
                if(confirm("Do you want to print invoice?")){
                  window.location.href = "../../production/administrator/printdistinvoice.php?invoiceno="+data+"&"+invoice;
                }
                else{
                  alert("Records successfully saved");
                }
              }
            }
          })
        })


  });

</script>