-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2019 at 03:50 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `posdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `BrandID` varchar(20) NOT NULL,
  `Brand` varchar(200) DEFAULT NULL,
  `BrandDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`BrandID`, `Brand`, `BrandDate`) VALUES
('07849bb4f9624d3985', 'socket', '2018-11-14 23:39:28'),
('e60d9965cf60', 'italian shoe', '2018-11-15 00:08:27');

-- --------------------------------------------------------

--
-- Table structure for table `debthistory`
--

CREATE TABLE `debthistory` (
  `DebtorID` bigint(20) NOT NULL,
  `InvoiceNo` varchar(20) DEFAULT NULL,
  `NetTotal` decimal(10,2) NOT NULL,
  `Paid` decimal(10,2) NOT NULL,
  `Due` decimal(10,2) NOT NULL,
  `DebtDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `debthistory`
--

INSERT INTO `debthistory` (`DebtorID`, `InvoiceNo`, `NetTotal`, `Paid`, `Due`, `DebtDate`) VALUES
(1, '237a4eaa4a9f', '3400.00', '1000.00', '2400.00', '2019-02-11 23:08:38'),
(2, 'de31ef21c261', '5350.00', '0.00', '5350.00', '2019-02-11 23:08:38');

-- --------------------------------------------------------

--
-- Table structure for table `debtpayment`
--

CREATE TABLE `debtpayment` (
  `DeptPayID` bigint(20) NOT NULL,
  `InvoiceNo` varchar(20) NOT NULL,
  `Paid` decimal(10,2) NOT NULL,
  `DebtDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `debtpayment`
--

INSERT INTO `debtpayment` (`DeptPayID`, `InvoiceNo`, `Paid`, `DebtDate`) VALUES
(1, 'de31ef21c261', '4350.00', '2019-02-12 19:58:30'),
(3, 'de31ef21c261', '500.00', '2019-02-12 20:11:11'),
(4, 'de31ef21c261', '200.00', '2019-02-12 20:22:31'),
(5, 'de31ef21c261', '1000.00', '2019-02-12 20:25:53'),
(6, 'de31ef21c261', '1000.00', '2019-02-12 20:27:56'),
(7, 'de31ef21c261', '1000.00', '2019-02-12 20:34:49'),
(8, 'de31ef21c261', '1000.00', '2019-02-12 20:59:11'),
(9, 'de31ef21c261', '0.00', '2019-02-12 21:00:18'),
(10, 'de31ef21c261', '500.00', '2019-02-12 21:14:04'),
(11, '237a4eaa4a9f', '1000.00', '2019-02-12 23:52:20'),
(12, 'de31ef21c261', '2000.00', '2019-02-12 23:56:25');

-- --------------------------------------------------------

--
-- Table structure for table `distribute`
--

CREATE TABLE `distribute` (
  `DistributeID` bigint(20) NOT NULL,
  `ShopID` varchar(20) DEFAULT NULL,
  `ProductID` varchar(20) DEFAULT NULL,
  `Quantity` float DEFAULT NULL,
  `DistributeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UserID` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distribute`
--

INSERT INTO `distribute` (`DistributeID`, `ShopID`, `ProductID`, `Quantity`, `DistributeDate`, `UserID`) VALUES
(1, '5bfc7c897738e', '194916', 222, '2019-03-11 22:17:42', '48fcf7af2cf6'),
(2, '5bfc7c897738e', '524896', 200, '2019-05-09 13:48:06', '48fcf7af2cf6'),
(3, '5bfc7c94ee87d', '304658', 20, '2019-05-08 10:00:16', '48fcf7af2cf6'),
(4, '5bfc7c94ee87d', '524896', 94, '2019-05-09 13:48:06', '48fcf7af2cf6'),
(5, '5bfc7c94ee87d', '170975', 26, '2019-05-08 12:15:55', '48fcf7af2cf6'),
(6, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '48fcf7af2cf6'),
(16, '5bfc7c897738e', '927843', 10, '2019-05-08 14:47:24', '48fcf7af2cf6'),
(17, '5bfc7c9f69310', '927843', 40, '2019-02-28 17:20:55', '48fcf7af2cf6'),
(18, '5bfc7c9f69310', '170975', 50, '2019-02-28 17:05:48', '48fcf7af2cf6'),
(19, '5bfc7c9f69310', '304658', 40, '2019-02-28 18:25:33', '48fcf7af2cf6'),
(20, '5bfc7c9f69310', '194916', 20, '2019-05-09 13:46:12', '48fcf7af2cf6'),
(21, '5bfc7c9f69310', '524896', 42, '2019-03-02 00:57:46', '48fcf7af2cf6'),
(22, '5bfc7c94ee87d', '194916', 25, '2019-05-09 13:46:12', '48fcf7af2cf6'),
(23, '5bfc7c94ee87d', '927843', 20, '2019-05-09 13:10:12', '48fcf7af2cf6'),
(24, '5bfc7c897738e', '304658', 110, '2019-03-11 22:34:45', '48fcf7af2cf6'),
(25, '5bfc7c897738e', '437941', 10, '2019-05-08 14:47:24', '48fcf7af2cf6'),
(26, '5bfc7c897738e', '575194', 10, '2019-03-04 23:33:57', 'e41a13b0ea3e'),
(27, '5bfc7c9f69310', '575194', 19.5, '2019-03-07 19:35:23', '48fcf7af2cf6'),
(28, '5bfc7c94ee87d', '575194', 20, '2019-05-08 09:54:55', '48fcf7af2cf6'),
(29, '5bfc7c9f69310', '437941', 3.5, '2019-03-07 19:38:10', '48fcf7af2cf6'),
(30, '5bfc7c94ee87d', '437941', 19, '2019-05-08 14:47:24', '48fcf7af2cf6'),
(31, '5bfc7c94ee87d', '718985', 20, '2019-05-08 09:57:04', '48fcf7af2cf6');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `ExpensesID` bigint(20) NOT NULL,
  `ExpAmount` decimal(10,2) DEFAULT NULL,
  `ExpensesType` enum('Electricity Bill','Wages and Salary','Transportation','Clothing','Advertisement','Tax','Rent','Telephone','Bad Debt','Amortization','Depreciation','Insurance','Miscellaneous','Entertainment','Utility','Cost of goods and services') DEFAULT NULL,
  `ExpDetails` varchar(100) DEFAULT NULL,
  `ExpDate` date DEFAULT NULL,
  `UserID` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`ExpensesID`, `ExpAmount`, `ExpensesType`, `ExpDetails`, `ExpDate`, `UserID`) VALUES
(1, '25.00', 'Electricity Bill', 'bought it', '2018-12-06', '48fcf7af2cf6');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `InvoiceNo` varchar(20) NOT NULL,
  `CustomerName` varchar(200) DEFAULT NULL,
  `NetTotal` decimal(10,2) DEFAULT NULL,
  `Paid` decimal(10,2) DEFAULT NULL,
  `Due` decimal(10,2) DEFAULT NULL,
  `PaymentType` varchar(200) DEFAULT NULL,
  `InvoiceDate` date DEFAULT NULL,
  `ShopID` varchar(20) DEFAULT NULL,
  `UserID` varchar(20) DEFAULT NULL,
  `CustPhone` varchar(20) NOT NULL,
  `Status` enum('Cancelled','Transacted','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`InvoiceNo`, `CustomerName`, `NetTotal`, `Paid`, `Due`, `PaymentType`, `InvoiceDate`, `ShopID`, `UserID`, `CustPhone`, `Status`) VALUES
('17b3dd2b8415', 'Pablo', '548.00', '548.00', '0.00', 'Cash', '2019-05-06', '5bfc7c94ee87d', 'f7a6c6b34e93', '+233202990999', 'Transacted'),
('19718ea39cfd', 'Paulo', '650.00', '650.00', '0.00', 'Cash', '2019-05-03', '5bfc7c94ee87d', 'f7a6c6b34e93', '+233202990999', 'Transacted'),
('277a65652ff7', 'Paul', '0.00', '0.00', '0.00', 'Cash', '2019-05-03', '5bfc7c94ee87d', 'f7a6c6b34e93', '+233267726622', 'Transacted'),
('55611cca5407', 'Bannerman', '900.00', '900.00', '0.00', 'Cash', '2019-05-03', '5bfc7c94ee87d', 'f7a6c6b34e93', '+233546647747', 'Transacted'),
('7a8d7e3a2f9f', '', '0.00', '0.00', '0.00', 'Cash', '2019-05-02', '5bfc7c94ee87d', 'f7a6c6b34e93', '', 'Transacted'),
('f362a0689d16', 'Pinaman', '0.00', '0.00', '0.00', 'Cash', '2019-05-03', '5bfc7c94ee87d', 'f7a6c6b34e93', '+233267726622', 'Transacted');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_details`
--

CREATE TABLE `invoice_details` (
  `InvDetID` bigint(20) NOT NULL,
  `InvoiceNo` varchar(20) DEFAULT NULL,
  `ProductID` varchar(20) DEFAULT NULL,
  `Qty` float DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `Discount` float NOT NULL,
  `InvoiceDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_details`
--

INSERT INTO `invoice_details` (`InvDetID`, `InvoiceNo`, `ProductID`, `Qty`, `Price`, `Discount`, `InvoiceDate`) VALUES
(1, '7a8d7e3a2f9f', '524896', 0, '400.00', 0, '2019-05-03 15:42:33'),
(2, '55611cca5407', '194916', 2, '450.00', 0, '2019-05-03 11:21:54'),
(3, 'f362a0689d16', '170975', 0, '650.00', 0, '2019-05-08 12:15:55'),
(4, '277a65652ff7', '927843', 0, '500.00', 2, '2019-05-03 16:47:06'),
(6, '19718ea39cfd', '170975', 1, '650.00', 0, '2019-05-06 16:20:58'),
(7, '17b3dd2b8415', '194916', 0, '450.00', 0, '2019-05-06 14:41:58'),
(8, '17b3dd2b8415', '304658', 1, '550.00', 2, '2019-05-06 14:40:37');

-- --------------------------------------------------------

--
-- Table structure for table `mainprodcat`
--

CREATE TABLE `mainprodcat` (
  `MainProdcatID` varchar(20) NOT NULL,
  `MainprodCat` varchar(200) DEFAULT NULL,
  `prodcatDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mainprodcat`
--

INSERT INTO `mainprodcat` (`MainProdcatID`, `MainprodCat`, `prodcatDate`) VALUES
('c3c84f0f45cb', 'ELECTRICALS', '2018-11-14 23:54:27');

-- --------------------------------------------------------

--
-- Table structure for table `netincome`
--

CREATE TABLE `netincome` (
  `NetIncomeID` bigint(20) NOT NULL,
  `TotalIncome` decimal(10,2) DEFAULT NULL,
  `Expenses` decimal(10,2) DEFAULT NULL,
  `NetIncome` decimal(10,2) DEFAULT NULL,
  `IncomeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductID` varchar(20) NOT NULL,
  `MainProdcatID` varchar(20) DEFAULT NULL,
  `BrandID` varchar(20) DEFAULT NULL,
  `Product` varchar(200) DEFAULT NULL,
  `UnitPrice` decimal(10,2) DEFAULT NULL,
  `SellingPrice` decimal(10,2) DEFAULT NULL,
  `UserID` varchar(20) DEFAULT NULL,
  `ProductDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `RetailPrice` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `MainProdcatID`, `BrandID`, `Product`, `UnitPrice`, `SellingPrice`, `UserID`, `ProductDate`, `RetailPrice`) VALUES
('170975', 'c3c84f0f45cb', '07849bb4f9624d3985', 'Socket4', '550.00', '650.00', '48fcf7af2cf6', '2018-11-29 19:57:51', '0.00'),
('194916', 'c3c84f0f45cb', '07849bb4f9624d3985', 'Socket2', '350.00', '450.00', '48fcf7af2cf6', '2018-11-29 19:57:27', '0.00'),
('304658', 'c3c84f0f45cb', '07849bb4f9624d3985', 'Socket3', '450.00', '550.00', '48fcf7af2cf6', '2018-11-29 19:57:38', '0.00'),
('437941', 'c3c84f0f45cb', '07849bb4f9624d3985', 'socket5', '200.00', '250.00', 'e41a13b0ea3e', '2019-03-04 23:21:52', '20.00'),
('524896', 'ELECTRICALS', 'socket', 'Socket1', '250.00', '400.00', '48fcf7af2cf6', '2018-12-04 04:22:53', '0.00'),
('575194', 'c3c84f0f45cb', '07849bb4f9624d3985', 'socket6', '240.00', '250.00', '48fcf7af2cf6', '2019-03-04 23:32:59', '23.00'),
('718985', 'c3c84f0f45cb', '07849bb4f9624d3985', 'socket7', '260.00', '265.00', '48fcf7af2cf6', '2019-03-21 16:56:14', '26.00'),
('927843', 'ELECTRICALS', 'socket', 'Socket white', '345.00', '500.00', '48fcf7af2cf6', '2018-12-04 04:21:57', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `InvoiceNumber` varchar(20) NOT NULL,
  `VendorName` varchar(200) DEFAULT NULL,
  `SubTotal` decimal(10,2) DEFAULT NULL,
  `Discount` bigint(20) DEFAULT NULL,
  `NetTotal` decimal(10,2) DEFAULT NULL,
  `Paid` decimal(10,2) DEFAULT NULL,
  `Due` decimal(10,2) DEFAULT NULL,
  `PaymentType` varchar(200) DEFAULT NULL,
  `PurchaseDate` date DEFAULT NULL,
  `Created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UserID` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `purchases_details`
--

CREATE TABLE `purchases_details` (
  `PurchID` bigint(20) NOT NULL,
  `InvoiceNumber` varchar(20) DEFAULT NULL,
  `ProductID` varchar(20) DEFAULT NULL,
  `pQuantity` float DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `returnproducts`
--

CREATE TABLE `returnproducts` (
  `ReturnID` int(20) NOT NULL,
  `InvoiceNo` varchar(20) NOT NULL,
  `ProductID` varchar(20) NOT NULL,
  `rPrice` decimal(10,2) NOT NULL,
  `Bought` float NOT NULL,
  `Returned` float NOT NULL,
  `rDiscount` float NOT NULL,
  `ShopID` varchar(20) NOT NULL,
  `ReturnDate` date NOT NULL,
  `ReturnTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `returnproducts`
--

INSERT INTO `returnproducts` (`ReturnID`, `InvoiceNo`, `ProductID`, `rPrice`, `Bought`, `Returned`, `rDiscount`, `ShopID`, `ReturnDate`, `ReturnTime`) VALUES
(1, 'f362a0689d16', '170975', '23.00', 2, 1, 0, '5bfc7c94ee87d', '2019-05-03', '00:00:00'),
(2, '7a8d7e3a2f9f', '524896', '25.00', 1, 1, 0, '5bfc7c94ee87d', '2019-05-03', '00:00:00'),
(3, '277a65652ff7', '927843', '20.00', 1, 1, 0, '5bfc7c94ee87d', '2019-05-03', '00:00:00'),
(4, '19718ea39cfd', '170975', '30.00', 5, 2, 0, '5bfc7c94ee87d', '2019-05-03', '00:00:00'),
(5, '17b3dd2b8415', '194916', '450.00', 1, 1, 2, '5bfc7c94ee87d', '2019-05-06', '00:00:00'),
(6, '19718ea39cfd', '170975', '650.00', 2, 1, 0, '5bfc7c94ee87d', '2019-05-06', '18:20:57'),
(7, 'f362a0689d16', '170975', '650.00', 1, 1, 0, '5bfc7c94ee87d', '2019-05-08', '14:15:55');

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE `shop` (
  `ShopID` varchar(20) NOT NULL,
  `Shop` varchar(200) DEFAULT NULL,
  `ShopType` enum('Main Wholesale','Retail','Wholesale') DEFAULT NULL,
  `ShopDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UserID` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`ShopID`, `Shop`, `ShopType`, `ShopDate`, `UserID`) VALUES
('5bfc7c897738e', 'Gyamfi Shop', 'Retail', '2018-11-27 07:06:49', '48fcf7af2cf6'),
('5bfc7c94ee87d', 'Ben Shop', 'Wholesale', '2018-11-27 07:07:00', '48fcf7af2cf6'),
('5bfc7c9f69310', 'Asare Shop', 'Main Wholesale', '2018-11-27 07:07:11', '48fcf7af2cf6');

-- --------------------------------------------------------

--
-- Table structure for table `shop_products_history`
--

CREATE TABLE `shop_products_history` (
  `ShopProID` int(20) NOT NULL,
  `ShopID` varchar(20) NOT NULL,
  `ProductID` varchar(20) NOT NULL,
  `PreviousQty` float NOT NULL,
  `AddQty` float NOT NULL,
  `TotalQty` float NOT NULL,
  `hStatus` enum('Added','Deducted','Transferred','') NOT NULL,
  `hDate` date NOT NULL,
  `hTime` time NOT NULL,
  `UserID` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_products_history`
--

INSERT INTO `shop_products_history` (`ShopProID`, `ShopID`, `ProductID`, `PreviousQty`, `AddQty`, `TotalQty`, `hStatus`, `hDate`, `hTime`, `UserID`) VALUES
(1, '5bfc7c94ee87d', '524896', 50, 4, 54, 'Transferred', '2019-05-09', '15:43:00', '48fcf7af2cf6'),
(2, '5bfc7c94ee87d', '194916', 20, 5, 25, 'Transferred', '2019-05-09', '15:46:12', '48fcf7af2cf6'),
(3, '5bfc7c94ee87d', '524896', 54, 40, 94, 'Transferred', '2019-05-09', '15:48:06', '48fcf7af2cf6');

-- --------------------------------------------------------

--
-- Table structure for table `transferprod`
--

CREATE TABLE `transferprod` (
  `TransferID` bigint(20) NOT NULL,
  `ShopID` varchar(20) DEFAULT NULL,
  `ProductID` varchar(20) DEFAULT NULL,
  `Quantity` float DEFAULT NULL,
  `DistributeDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `UserID` varchar(20) DEFAULT NULL,
  `FromShop` varchar(20) DEFAULT NULL,
  `ProdStatus` enum('Distributed','Transferred','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transferprod`
--

INSERT INTO `transferprod` (`TransferID`, `ShopID`, `ProductID`, `Quantity`, `DistributeDate`, `UserID`, `FromShop`, `ProdStatus`) VALUES
(1, '5bfc7c897738e', '927843', 10, '2019-03-05 19:05:46', '018fd862f440', 'Ben Shop', 'Distributed'),
(2, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '018fd862f440', 'Ben Shop', 'Distributed'),
(3, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(4, '5bfc7c897738e', '927843', 5, '2019-03-07 19:29:29', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(5, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(6, '5bfc7c897738e', '927843', 5, '2019-03-07 19:29:29', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(7, '5bfc7c94ee87d', '524896', 5, '2019-02-28 19:09:51', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(8, '5bfc7c94ee87d', '304658', 5, '2019-02-28 19:10:02', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(9, '5bfc7c94ee87d', '194916', 5, '2019-02-28 19:10:11', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(10, '5bfc7c9f69310', '927843', 20, '2019-02-28 19:10:22', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(11, '5bfc7c9f69310', '170975', 20, '2019-02-28 19:10:36', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(12, '5bfc7c94ee87d', '194916', 5, '2019-02-28 19:10:49', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(13, '5bfc7c94ee87d', '927843', 5, '2019-02-28 19:10:59', '48fcf7af2cf6', 'Ben Shop', 'Distributed'),
(14, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(15, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(16, '5bfc7c897738e', '304658', 3, '2019-02-28 20:07:46', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(17, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(18, '5bfc7c897738e', '927843', 10, '2019-03-04 19:09:46', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(19, '5bfc7c897738e', '524896', 10, '2019-02-28 20:08:40', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(20, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(21, '5bfc7c897738e', '927843', 5, '2019-03-07 19:29:29', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(22, '5bfc7c897738e', '927843', 5, '2019-03-07 19:29:29', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(23, '5bfc7c897738e', '927843', 5, '2019-03-07 19:29:29', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(24, '5bfc7c897738e', '194916', 50, '2019-02-28 20:08:13', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(25, '5bfc7c897738e', '304658', 50, '2019-02-28 20:08:05', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(26, '5bfc7c897738e', '194916', 50, '2019-02-28 20:09:06', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(27, '5bfc7c897738e', '927843', 5, '2019-03-07 19:29:29', '48fcf7af2cf6', NULL, 'Distributed'),
(28, '5bfc7c897738e', '194916', 50, '2019-02-28 20:24:18', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(29, '5bfc7c897738e', '524896', 50, '2019-02-28 20:24:18', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(30, '5bfc7c897738e', '194916', 10, '2019-03-01 22:14:40', '48fcf7af2cf6', NULL, 'Distributed'),
(31, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '48fcf7af2cf6', NULL, 'Distributed'),
(34, '5bfc7c897738e', '927843', 10, '2019-03-06 19:09:46', '48fcf7af2cf6', NULL, 'Distributed'),
(35, '5bfc7c897738e', '194916', 1, '2019-03-02 00:57:16', '48fcf7af2cf6', NULL, 'Distributed'),
(36, '5bfc7c9f69310', '524896', 1, '2019-03-02 00:57:46', '48fcf7af2cf6', NULL, 'Distributed'),
(37, '5bfc7c9f69310', '524896', 1, '2019-03-02 00:57:46', '48fcf7af2cf6', NULL, 'Distributed'),
(38, '5bfc7c897738e', '194916', 1, '2019-03-02 01:56:35', '48fcf7af2cf6', NULL, 'Distributed'),
(39, '5bfc7c897738e', '170975', 160, '2019-03-05 00:01:43', '48fcf7af2cf6', NULL, 'Distributed'),
(40, '5bfc7c897738e', '194916', 10, '2019-03-04 22:15:07', '48fcf7af2cf6', NULL, 'Distributed'),
(41, '5bfc7c94ee87d', '194916', 10, '2019-03-04 22:26:22', '48fcf7af2cf6', NULL, 'Distributed'),
(42, '5bfc7c897738e', '927843', 10, '2019-03-04 19:09:46', '48fcf7af2cf6', NULL, 'Distributed'),
(43, '5bfc7c897738e', '524896', 90, '2019-03-04 23:14:00', 'e41a13b0ea3e', NULL, 'Distributed'),
(44, '5bfc7c897738e', '927843', 10, '2019-03-01 19:09:46', 'e41a13b0ea3e', NULL, 'Distributed'),
(45, '5bfc7c897738e', '437941', 10, '2019-03-04 23:23:12', 'e41a13b0ea3e', NULL, 'Distributed'),
(46, '5bfc7c897738e', '927843', 10, '2019-03-02 09:09:00', 'e41a13b0ea3e', NULL, 'Distributed'),
(47, '5bfc7c897738e', '575194', 10, '2019-03-04 23:33:57', 'e41a13b0ea3e', NULL, 'Distributed'),
(48, '5bfc7c897738e', '927843', 10, '2019-03-01 19:09:30', 'e41a13b0ea3e', NULL, 'Distributed'),
(49, '5bfc7c897738e', '304658', 5.5, '2019-03-07 19:33:02', '48fcf7af2cf6', NULL, 'Distributed'),
(50, '5bfc7c9f69310', '575194', 20.5, '2019-03-07 19:34:36', '48fcf7af2cf6', NULL, 'Distributed'),
(51, '5bfc7c94ee87d', '575194', 1, '2019-03-07 19:35:23', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(52, '5bfc7c9f69310', '437941', 2.5, '2019-03-07 19:36:24', '48fcf7af2cf6', NULL, 'Distributed'),
(53, '5bfc7c9f69310', '437941', 0.5, '2019-03-07 19:36:43', '48fcf7af2cf6', NULL, 'Distributed'),
(54, '5bfc7c9f69310', '437941', 1.5, '2019-03-07 19:37:31', '48fcf7af2cf6', NULL, 'Distributed'),
(55, '5bfc7c94ee87d', '437941', 1, '2019-03-07 19:38:10', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(56, '5bfc7c94ee87d', '575194', 19, '2019-05-08 09:54:55', '48fcf7af2cf6', NULL, 'Distributed'),
(57, '5bfc7c94ee87d', '927843', 17, '2019-05-08 09:57:04', '48fcf7af2cf6', NULL, 'Distributed'),
(58, '5bfc7c94ee87d', '718985', 20, '2019-05-08 09:57:04', '48fcf7af2cf6', NULL, 'Distributed'),
(59, '5bfc7c94ee87d', '437941', 19, '2019-05-08 09:58:45', '48fcf7af2cf6', NULL, 'Distributed'),
(60, '5bfc7c94ee87d', '194916', 12, '2019-05-08 09:58:45', '48fcf7af2cf6', NULL, 'Distributed'),
(61, '5bfc7c94ee87d', '304658', 13, '2019-05-08 10:00:16', '48fcf7af2cf6', NULL, 'Distributed'),
(62, '5bfc7c897738e', '927843', 5, '2019-05-08 14:47:24', '48fcf7af2cf6', 'Ben Shop', 'Transferred'),
(63, '5bfc7c897738e', '437941', 1, '2019-05-08 14:47:24', '48fcf7af2cf6', 'Ben Shop', 'Transferred'),
(64, '5bfc7c94ee87d', '524896', 4, '2019-05-09 13:43:00', '48fcf7af2cf6', 'Gyamfi Shop', 'Transferred'),
(65, '5bfc7c94ee87d', '194916', 5, '2019-05-09 13:46:12', '48fcf7af2cf6', 'Asare Shop', 'Transferred'),
(66, '5bfc7c94ee87d', '524896', 40, '2019-05-09 13:48:06', '48fcf7af2cf6', 'Gyamfi Shop', 'Transferred');

-- --------------------------------------------------------

--
-- Table structure for table `transfer_product_history`
--

CREATE TABLE `transfer_product_history` (
  `Transfer_ProdID` int(20) NOT NULL,
  `FromShop` varchar(200) NOT NULL,
  `ShopID` varchar(20) NOT NULL,
  `ProductID` varchar(20) NOT NULL,
  `PrevQty` float NOT NULL,
  `TransQty` float NOT NULL,
  `RemainingQty` float NOT NULL,
  `TransDate` date NOT NULL,
  `TransTime` time NOT NULL,
  `UserID` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transfer_product_history`
--

INSERT INTO `transfer_product_history` (`Transfer_ProdID`, `FromShop`, `ShopID`, `ProductID`, `PrevQty`, `TransQty`, `RemainingQty`, `TransDate`, `TransTime`, `UserID`) VALUES
(1, 'Gyamfi Shop', '5bfc7c94ee87d', '524896', 50, 4, 54, '2019-05-09', '15:43:00', '48fcf7af2cf6'),
(2, 'Asare Shop', '5bfc7c94ee87d', '194916', 25, 5, 20, '2019-05-09', '15:46:12', '48fcf7af2cf6'),
(3, 'Gyamfi Shop', '5bfc7c94ee87d', '524896', 240, 40, 200, '2019-05-09', '15:48:06', '48fcf7af2cf6');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` varchar(20) NOT NULL,
  `FullName` varchar(200) DEFAULT NULL,
  `PhoneNo` varchar(20) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `UserType` enum('Administrator','Sales Personnel','Supplier') DEFAULT NULL,
  `ShopID` varchar(20) NOT NULL,
  `Username` varchar(20) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `Status` enum('Active','Inactive') DEFAULT NULL,
  `DateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `FullName`, `PhoneNo`, `Email`, `UserType`, `ShopID`, `Username`, `Password`, `Status`, `DateTime`) VALUES
('018fd862f440', 'Jonas Aning', '+233875845683', 'jonas@gmail.com', 'Supplier', '5bfc7c9f69310', 'jonas2018', '8a90c335cc9b3d4367f9978953c0fc909e23299c52ab975d693800320a2b5edf', 'Active', '2018-11-29 17:15:16'),
('48fcf7af2cf6', 'Tieku Abofa', '+233554554554', 'tieku@gmail.com', 'Administrator', '5bfc7c9f69310', 'tieku2018', '84971ff768b8a9b4a737445a06f81e29b3edbf7c01bd028655f7369587bc9dd7', 'Active', '2018-12-04 05:23:24'),
('681c0baaa37c', 'Kwarteng Amanfo', '+233240009889', 'kwarteng@gmail.com', 'Sales Personnel', '5bfc7c897738e', 'kamanfo2019', '0ca3936f8a1bc91e8c730d466d0346d6f22789a0590227f87f06ba5dd5a38ff7', 'Active', '2019-02-15 17:03:03'),
('e41a13b0ea3e', 'Felix', '+233240009889', 'felix@gmail.com', 'Administrator', '5bfc7c9f69310', 'felix', '0999f2501dbbe6208f81a13d2cb45813d27276aa8ec08334f971cc128130d5c1', 'Active', '2019-03-04 22:14:17'),
('f7a6c6b34e93', 'Kwaku Nimoh', '+233876887788', 'kwaku@gmail.com', 'Sales Personnel', '5bfc7c94ee87d', 'kwakunimoh2018', 'f816f6947dc1bb978e2cc1c834880fc17ba14d34623400cf2063037652e06126', 'Active', '2018-11-27 07:18:41');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `VendorID` bigint(20) NOT NULL,
  `VendorName` varchar(200) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `vEmail` varchar(20) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Status` enum('Active','Inactive') DEFAULT NULL,
  `UserID` varchar(20) DEFAULT NULL,
  `VendDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`VendorID`, `VendorName`, `Phone`, `vEmail`, `Address`, `Location`, `Status`, `UserID`, `VendDate`) VALUES
(1, 'Jospond Oppong', '+233876887788', 'HsNo. 456', 'HsNo. 456', 'Tabora', 'Active', '48fcf7af2cf6', '2018-11-29 17:52:52'),
(2, 'Larry Joe', '+233343487364', 'HsNo. 457', 'HsNo. 457', 'Teshie Market', 'Active', '48fcf7af2cf6', '2018-11-29 18:20:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`BrandID`);

--
-- Indexes for table `debthistory`
--
ALTER TABLE `debthistory`
  ADD PRIMARY KEY (`DebtorID`);

--
-- Indexes for table `debtpayment`
--
ALTER TABLE `debtpayment`
  ADD PRIMARY KEY (`DeptPayID`);

--
-- Indexes for table `distribute`
--
ALTER TABLE `distribute`
  ADD PRIMARY KEY (`DistributeID`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`ExpensesID`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`InvoiceNo`);

--
-- Indexes for table `invoice_details`
--
ALTER TABLE `invoice_details`
  ADD PRIMARY KEY (`InvDetID`);

--
-- Indexes for table `mainprodcat`
--
ALTER TABLE `mainprodcat`
  ADD PRIMARY KEY (`MainProdcatID`);

--
-- Indexes for table `netincome`
--
ALTER TABLE `netincome`
  ADD PRIMARY KEY (`NetIncomeID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`InvoiceNumber`);

--
-- Indexes for table `purchases_details`
--
ALTER TABLE `purchases_details`
  ADD PRIMARY KEY (`PurchID`);

--
-- Indexes for table `returnproducts`
--
ALTER TABLE `returnproducts`
  ADD PRIMARY KEY (`ReturnID`);

--
-- Indexes for table `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`ShopID`);

--
-- Indexes for table `shop_products_history`
--
ALTER TABLE `shop_products_history`
  ADD PRIMARY KEY (`ShopProID`);

--
-- Indexes for table `transferprod`
--
ALTER TABLE `transferprod`
  ADD PRIMARY KEY (`TransferID`);

--
-- Indexes for table `transfer_product_history`
--
ALTER TABLE `transfer_product_history`
  ADD PRIMARY KEY (`Transfer_ProdID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`VendorID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `debthistory`
--
ALTER TABLE `debthistory`
  MODIFY `DebtorID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `debtpayment`
--
ALTER TABLE `debtpayment`
  MODIFY `DeptPayID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `distribute`
--
ALTER TABLE `distribute`
  MODIFY `DistributeID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `ExpensesID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `invoice_details`
--
ALTER TABLE `invoice_details`
  MODIFY `InvDetID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `netincome`
--
ALTER TABLE `netincome`
  MODIFY `NetIncomeID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purchases_details`
--
ALTER TABLE `purchases_details`
  MODIFY `PurchID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `returnproducts`
--
ALTER TABLE `returnproducts`
  MODIFY `ReturnID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `shop_products_history`
--
ALTER TABLE `shop_products_history`
  MODIFY `ShopProID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transferprod`
--
ALTER TABLE `transferprod`
  MODIFY `TransferID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `transfer_product_history`
--
ALTER TABLE `transfer_product_history`
  MODIFY `Transfer_ProdID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `VendorID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
